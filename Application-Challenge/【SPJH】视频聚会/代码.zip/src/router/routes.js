import Party from '../views/party/index.vue';

export default [
  {
    path: '/party',
    name: 'party',
    component: Party
  }
];
