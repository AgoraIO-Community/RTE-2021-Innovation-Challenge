export default {
    appid: 'e78dc23bf4314d9fb6bc8b600868699a', // 请输入自己的appkey
}
