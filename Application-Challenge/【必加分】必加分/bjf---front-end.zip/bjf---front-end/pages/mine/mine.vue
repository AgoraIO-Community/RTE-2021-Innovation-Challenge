<template>
	<view>
		<navigator url="/pages/profile/profile">
			<view class="u-flex user-box u-p-l-30 u-p-r-20 u-p-30">
				<view class="u-m-r-10">
					<u-avatar :src="iconPath" size="140"></u-avatar>
				</view>
				<view class="u-flex-1">
					<view class="u-font-18 u-p-b-20">{{userData.loginName}}</view>
					<view class="u-font-14 u-tips-color">
						<text class="u-p-r-30">身份：{{userData.type==1?"教师":"家长"}}</text>
						<text class="u-p-l-30">ID: {{userData.id}}</text>
					</view>
				</view>
				<view class="u-m-l-10 u-p-10">
					<u-icon name="arrow-right" color="#969799" size="28"></u-icon>
				</view>
			</view>
		</navigator>
		<view class="u-m-t-20">
			<u-cell-group>
				<u-cell-item   icon="rmb-circle" title="分销中心" @click="$common.jumpurl('/pages/store/index/index')"></u-cell-item>
				
			</u-cell-group>
		</view>
		<view class="u-m-t-20">
			<u-cell-group>
				<template v-if="userData.type==2">
					<u-cell-item icon="rmb-circle" title="支付"></u-cell-item>
					<u-cell-item icon="star" title="收藏" @tap="check"></u-cell-item>
					<u-cell-item icon="heart" title="红包助力"></u-cell-item>
					<u-cell-item icon="coupon" title="优惠券"></u-cell-item>
				</template>
				<template v-if="userData.type==1">
					<u-cell-item icon="rmb-circle" title="钱包"></u-cell-item>
					<navigator url="/pages/teacher/enter/enter">
						<u-cell-item icon="home" title="教师入驻" ></u-cell-item>
					</navigator>
				</template>
			</u-cell-group>
		</view>
		<view class="u-m-t-20">
			<u-cell-group>
				<navigator url="/pages/setting/setting">
					<u-cell-item icon="setting" title="设置"></u-cell-item>
				</navigator>
			</u-cell-group>
			<u-cell-group class="u-m-t-20">
				<u-cell-item icon="account" title="切换身份" @click="changeType('change')"></u-cell-item>
			</u-cell-group>
		</view>
		<u-modal v-model="modal" :show-cancel-button="true" :content="modalContent" @confirm="modalConfirm"></u-modal>
		<u-tabbar :list="list" :mid-button="false" active-color="#00c65d"></u-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				modal: false,
				modalContent: "",
				modalType: null,
				userData: {},
				teacherData: {},
				list: [],
				userType: null,
				iconPath: "/static/logo.png",
				storebool:false
			}
		},
		mounted() {
			var _self = this
			this.userData = this.user();
			this.list = this.userData.type == 1 ? getApp().globalData.teacher : getApp().globalData.parent;
			if (null != this.userData.iconPath)
				this.iconPath = getApp().globalData.baseUrl + "/attach/download/" + this.userData.iconPath
			if (this.userData.type == 1)
				this.teacherData = uni.getStorageSync("teacher");
			this.ajax({
				url: "distribution/findData",
				data: {
					user: this.userData.code
				}
			}).then(res => {
				if(res.data){
					_self.storebool = true
				}else{
					_self.storebool = false
				}
			});
		},
		methods: {
			showModal(type) {
				this.modal = true;
				this.modalType = type;
				switch (type) {
					case "change":
						this.modalContent = "确认要切换到【" + (this.userData.type == 1 ? "家长" : "教师") + "】身份吗？";
						break;
				}
			},
			modalConfirm() {
				this.modal = false;
				switch (this.modalType) {
					case "change":
						this.userData.type = this.userData.type == 1 ? 2 : 1;
						this.ajax({
							url: "user/changeType",
							data: {
								code: this.userData.code,
								type: this.userData.type
							}
						}).then(res => {
							if (this.userData.type == 1)
								uni.setStorageSync("teacher", res.data);
							uni.setStorageSync("user", JSON.stringify(this.userData));
							uni.reLaunch({
								url: "/pages/mine/mine"
							})
						});
						break;
				}
			},
			changeType(){
				this.userData.type = this.userData.type == 1 ? 2 : 1;
				this.ajax({
					url: "user/changeType",
					data: {
						code: this.userData.code,
						type: this.userData.type
					}
				}).then(res => {
					if (this.userData.type == 1)
						uni.setStorageSync("teacher", res.data);
					uni.setStorageSync("user", JSON.stringify(this.userData));
					uni.reLaunch({
						url: "/pages/mine/mine"
					})
				});
			},
			check(){
				uni.navigateTo({
					url:"../collot/collot"
				})
			},
			check_store() {

				


			}

		}
	}
</script>

<style lang="scss">
	page {
		background-color: #ededed;
	}

	.camera {
		width: 54px;
		height: 44px;

		&:active {
			background-color: #ededed;
		}
	}

	.user-box {
		background-color: #fff;
	}
</style>
