<template>
	<view>
		<u-navbar :background="background" :title="navTitle" :is-back="false" title-color="#fff" />
		<!-- 登陆页面组件 --> 
		<login v-show="type === 'login'" @change-login="changeLogin" />
		<!-- 注册页面组件 -->
		<register v-show="type === 'register'" @change-login="changeLogin" />
	</view>
</template>

<script>
	import Login from './components/login.vue'
	import Register from './components/register.vue'
	export default {
		components: {
			'login': Login,
			'register': Register
		},
		data() {
			return {
				// 登陆或注册
				type: 'login',
				background: {
					backgroundColor: '#00c65d'
				},

			}
		},
		computed: {
			navTitle() {
				return this.type === 'login' ? '欢迎登陆' : '欢迎注册'
			}
		},
		methods: {
			// 切换登陆方式
			changeLogin(type) {
				this.type = type
			}
		}
	}
</script>

<style>
</style>
