<template>
	<view class="wrap">
		<view class="content">
			<view class="title">欢迎注册必加分</view>
			<u-form :model="formData" :rules="rules" ref="uForm" :errorType="['toast','border-bottom']">
				<u-form-item :leftIconStyle="{color: '#888', fontSize: '32rpx'}" left-icon="account" label-width="120"
					prop="loginName">
					<u-input placeholder="请输入手机号" v-model="formData.loginName" type="number"></u-input>
				</u-form-item>
				<u-form-item :leftIconStyle="{color: '#888', fontSize: '32rpx'}" left-icon="lock" label-width="120"
					prop="passWord">
					<u-input :password-icon="true" v-model="formData.passWord" type="password" placeholder="请输入密码">
					</u-input>
				</u-form-item>
				<u-form-item :leftIconStyle="{color: '#888', fontSize: '32rpx'}" left-icon="lock" label-width="120"
					prop="passWord2">
					<u-input :password-icon="true" v-model="formData.passWord2" type="password" placeholder="请确认密码">
					</u-input>
				</u-form-item>
				<u-form-item :leftIconStyle="{color: '#888', fontSize: '32rpx'}" left-icon="share" label-width="120">
					<u-input v-model="formData.distribution" type="text" placeholder="请输入邀请码">
					</u-input>
				</u-form-item>
			</u-form>
			<u-button type="success" @click="submit" style="margin-top: 30rpx;">登录</u-button>
			<view class="alternative">
				<view @click="changeType('login')">返回登录</view>
				<view @click="changeType('agreement')">用户协议</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				formData: {
					loginName: "",
					passWord: "",
					passWord2: "",
					distribution: ""
				},
				rules: {
					loginName: [{
						required: true,
						message: "请输入手机号",
						trigger: ["blur", "change"]
					}],
					passWord: [{
						required: true,
						message: "请输入密码",
						trigger: ["blur", "change"]
					}],
					passWord2: [{
						required: true,
						message: "请确认密码",
						trigger: ["blur", "change"]
					}, {
						validator: (rule, value, callback) => {
							return this.formData.passWord == value;
						},
						message: "请确认密码一致",
						trigger: ["blur", "change"]
					}]
				}
			}
		},
		mounted() {
			this.$refs.uForm.setRules(this.rules)
		},
		methods: {
			submit() {
				this.$refs.uForm.validate(valid => {
					if (valid) {
						this.ajax({
							url: "user/insert",
							data: this.formData
						}).then(res => {
							this.tips({
								title: "注册成功，请登录"
							});
							this.changeType("login");
						});
					}
				});
			},
			changeType(type) {
				if ("forgot" == type) {
					this.tips({
						title: "开发中"
					});
					return;
				}
				if ("agreement" == type) {
					uni.navigateTo({
						url: "/pages/agreement/agreement"
					})
					return;
				}
				this.$emit('change-login', type)
			}
		}
	};
</script>

<style lang="scss" scoped>
	.wrap {
		font-size: 28rpx;

		.content {
			width: 600rpx;
			margin: 80rpx auto 0;

			.title {
				text-align: left;
				font-size: 60rpx;
				font-weight: 500;
				margin-bottom: 100rpx;
			}

			.alternative {
				color: $u-tips-color;
				display: flex;
				justify-content: space-between;
				margin-top: 30rpx;
			}
		}
	}
</style>
