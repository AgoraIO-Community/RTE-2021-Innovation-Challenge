<template>
	<view class="wrap">
		<view class="content">
			<view class="title">欢迎登录必加分</view>
			<u-form :model="formData" :rules="rules" ref="uForm" :errorType="['toast','border-bottom']">
				<u-form-item :leftIconStyle="{color: '#888', fontSize: '32rpx'}" left-icon="account" label-width="120" prop="loginName">
					<u-input placeholder="请输入手机号" v-model="formData.loginName" type="number"></u-input>
				</u-form-item>
				<u-form-item :leftIconStyle="{color: '#888', fontSize: '32rpx'}" left-icon="lock" label-width="120" prop="passWord">
					<u-input :password-icon="true" v-model="formData.passWord" type="password" placeholder="请输入密码">
					</u-input>
				</u-form-item>
			</u-form>
			<u-button type="success" @click="submit" style="margin-top: 30rpx;" :loading="loading">登录</u-button>
			<view class="alternative">
				<view @click="changeType('forgot')">忘记密码</view>
				<view @click="changeType('register')">注册账户</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				loading: false,
				formData: {
					loginName: "",
					passWord: ""
				},
				rules: {
					loginName: [{
						required: true,
						message: "请输入手机号",
						trigger: ["blur", "change"]
					}],
					passWord: [{
						required: true,
						message: "请输入密码",
						trigger: ["blur", "change"]
					}]
				}
			}
		},
		mounted() {
			uni.clearStorageSync();
			this.$refs.uForm.setRules(this.rules);
		},
		methods: {
			submit() {
				this.$refs.uForm.validate(valid => {
					if (valid) {
						this.loading = true;
						this.ajax({
							url: "auth/login",
							data: this.formData
						}, () => {
							this.loading = false;
						}).then(res => {
							uni.setStorageSync("user", JSON.stringify(res.data));
							let url = res.data.type == 1 ? "/pages/teacher/accept/accept" : "/pages/parent/teacher/teacher";
							
							this.updateAddress(res.data)
							uni.reLaunch({
								url: url
							})
						});
					}
				});
			},
			changeType(type) {
				if ("forgot" == type) {
					this.tips({
						title: "开发中"
					});
					return;
				}
				this.$emit('change-login', type)
			},
			updateAddress(data) {
				uni.getLocation({
					type: 'gcj02',
					success: (e) => {
						this.latitude = e.latitude,
							this.longitude = e.longitude
							const params = {
								code: data.code,
								latitude: e.latitude,
								longitude: e.longitude,
								type: data.type
							}
							this.ajax({
								url: 'user/location',
								method: 'post',
								data: params
							}).then(res => {
								console.log(res,'address')
							})
					},
					complete(e) {
						console.log(e,'error')
					}
				})
			}
		}
	};
</script>

<style lang="scss" scoped>
	.wrap {
		font-size: 28rpx;

		.content {
			width: 600rpx;
			margin: 80rpx auto 0;

			.title {
				text-align: left;
				font-size: 60rpx;
				font-weight: 500;
				margin-bottom: 100rpx;
			}

			.alternative {
				color: $u-tips-color;
				display: flex;
				justify-content: space-between;
				margin-top: 30rpx;
			}
		}
	}
</style>
