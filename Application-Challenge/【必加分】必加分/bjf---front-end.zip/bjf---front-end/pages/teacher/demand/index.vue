<template>
	 <view class="content">
		 <view class="nav">
			 <view class="nav-item" @click="changeItem" data-id="0">
			 	全部
			 	<view class="sp" v-if="status == 0"></view>
			 </view>
			 <view class="nav-item" @click="changeItem" data-id="1">
			 	待接单
			 	<view class="sp" v-if="status == 1"></view>
			 </view>
		 	<view class="nav-item" @click="changeItem" data-id="2">
		 		待上课
		 		<view class="sp" v-if="status == 2"></view>
		 	</view>
			<view class="nav-item" @click="changeItem" data-id="4">
				待完成
				<view class="sp" v-if="status == 4"></view>
			</view>
		 	<view class="nav-item" @click="changeItem" data-id="6">
				待评价
		 		<view class="sp" v-if="status == 6"></view>
		 	</view>
			
		 </view>
		 <view v-if="!see" style="position:relative;height: 100px;width:100%;">
			<web-view class="agora_web_view" :src="agoraroom" style="width: 100%;height: 100%;"></web-view>
		 </view>
		<view class="list" v-if="status != 1">
			<view class="card" v-for="(item,index) in listData">
				<view class="tc" @click="$common.jumpurl('/pages/teacher/demand/order_detail?code='+item.demand_.code)">
					<view class="txt">
						<view class="p">
							<text>需求科目：{{item.demand_.categoryStr}}</text>
							<text>年级：{{item.demand_.levelStr}}</text>
						</view>
						<view class="p">
							<text>院校经验：{{item.demand_.trainExperienceStr}}</text>
							<text v-if="item.demand_.sex == 0">老师性别：女老师</text>
							<text v-if="item.demand_.sex == 1">老师性别：男老师</text>
							<text v-if="item.demand_.sex == 2">老师性别：不限</text>
						</view>
						<view class="p">期待上课时间：{{item.demand_.classDate}}</view>
						<view class="p">课时数量：{{item.demand_.times}}个课时（每个课时50分钟）</view>
						<view class="p">
							<view>
								<u-icon name="map" color="#333" size="28" class="uicon"></u-icon>
								{{item.demand_.address}}
								<text class="primary" v-if="item.demand_.distance">{{item.demand_.distance/1000 }}km</text>
							</view>
						</view>
						<view class="pos">
							￥{{item.demand_.price}}
						</view>
						
					</view>
				</view>
				<view class="bc">
					<view class="fl" v-if="item.demand_.refund == 2">
						退款{{item.demand_.refundStr}},退款比例{{item.demand_.refundRatio *100}}%
					</view>
					<view class="fl" v-if="item.demand_.refund == 1">
						已确认退款,退款比例{{item.demand_.refundRatio *100}}%
					</view>
					<view class="fr">
						<u-button size="mini" @click="room(item.demand_.code)">AgoraRoom</u-button>
						<u-button size="mini" @click="confuse_refund(item.demand_.code)" v-if="item.demand_.refund == 2">拒绝退款</u-button>
						<u-button size="mini" @click="confirm_refund(item.demand_.code)" v-if="item.demand_.refund == 2">确认退款</u-button>
						<u-button size="mini" @click="recieve(item.demand_.code)" v-if="item.demand_.state == 1">立即接单</u-button>
						<u-button size="mini"  v-if="item.demand_.state == 4 && item.demand_.parentDoneDate == null && item.demand_.teacherDoneDate != null">待家长确认</u-button>
						<u-button size="mini" @click="confirm(item.demand_.code,item.demand_.parentDoneDate)" v-if="item.demand_.state == 4 && !item.demand_.teacherDoneDate">确认完成</u-button>
						<u-button size="mini" @click="start(item.demand_.code)" v-if="item.demand_.state == 2 && item.demand_.refund != 2">开始上课</u-button>
						<u-button size="mini" @click="gophone(item.phone)" v-if="item.demand_.state != 1 && item.demand_.refund != 1">拨打电话</u-button>
						<u-button size="mini" @click="$common.jumpurl('/pages/teacher/demand/order_detail?code='+item.demand_.code)">详情</u-button>
					</view>
				</view>
			</view>
		</view>
		<view class="list" v-if="status == 1">
			<view class="card" v-for="(item,index) in listData">
				<view class="tc" @click="$common.jumpurl('/pages/teacher/accept/order_detail?code='+item.code)">
					<view class="txt">
						<view class="p">
							<text>需求科目：{{item.categoryStr}}</text>
							<text>年级：{{item.levelStr}}</text>
						</view>
						<view class="p">
							<text>院校经验：{{item.trainExperienceStr}}</text>
							<text v-if="item.sex == 0">老师性别：女老师</text>
							<text v-if="item.sex == 1">老师性别：男老师</text>
							<text v-if="item.sex == 2">老师性别：不限</text>
						</view>
						<view class="p">期待上课时间：{{item.classDate}}</view>
						<view class="p">课时数量：{{item.times}}个课时</view>
						<view class="p">
							<view>
								<u-icon name="map" color="#333" size="28" class="uicon"></u-icon>
								{{item.address}}
								<text class="primary">{{item.distance/1000 || '20'}}km</text>
							</view>
						</view>
						<view class="pos">
							￥{{item.price}}
						</view>
						
					</view>
				</view>
				
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				status:0,
				listData:[],
				pageNum:0,
				total:0,
				agoraroom:"https://new.ofcourse.io/home/page/19046ca72dec43aa8926bdde668e658a",
				see: true
				 
			}
		},
		onLoad(option) {
			this.status = option.status?option.status:0
			
			
		},
		onShow(){
			this.listData  = []
			if(this.status == 1){
				this.getDemand()
			}else{
				this.getData()
			}
		},
		onReachBottom() {
			console.log(this.listData.length)
			if(this.total <= this.listData.length) {
				return uni.showToast({
					icon: 'none',
					title:'已经加载全部了'
				})
			}
			this.pageNum = ++ this.pageNum
			if(this.status == 1){
				this.getDemand()
			}else{
				this.getData()
			}
			
		},
		methods:{
			recieve:function(code){
				var _self = this
				        
				this.ajax({
					url: "/demand/accept/accept",
					data:{
						'demand':code
					}
				}).then(res => {
					uni.showToast({
						title: '操作成功',
						success:function(){
							_self.getData()
							
						}
						
					})
				});
				
			},
			confirm_refund:function(code){
				var _self = this
				        
				this.ajax({
					url: "/demand/accept/refundConfirm",
					data:{
						'demand':code,
						'refund':1
					}
				}).then(res => {
					uni.showToast({
						title: '操作成功',
						success:function(){
							_self.listData = []
							_self.getData()
							
						}
						
					})
				});
			},
			confuse_refund:function(code){
				var _self = this
				        
				this.ajax({
					url: "/demand/accept/refundConfirm",
					data:{
						'demand':code,
						'refund':0
					}
				}).then(res => {
					uni.showToast({
						title: '操作成功',
						success:function(){
							_self.listData = []
							_self.getData()
							
						}
						
					})
				});
			},
			gophone(phone){
				uni.makePhoneCall({
				 	
				 	// 手机号
				    phoneNumber: phone, 
					// 成功回调
					success: (res) => {
						console.log('调用成功!')	
					},
				
					// 失败回调
					fail: (res) => {
						console.log('调用失败!')
					}
					
				  });
				
			},
			getData:function(){
				var status = this.status
				var _self = this
				var userData = this.user();
				console.log(userData)
				if(status == 0){
					var obj = {
						'code':userData.code,
						pageNum: this.pageNum,
						pageSize: this.pageSize
						
					}
				}else{
					var obj = {
						'code':userData.code,
						"state":status,
						'states':'',
						pageNum: this.pageNum,
						pageSize: this.pageSize
					}
				}
				this.ajax({
					url: "/demand/accept/pageData",
					data:obj
				}).then(res => {
					_self.listData = this.listData.concat(res.data.records)
					_self.total = res.data.total
				});
			},
			getDemand(){
				var _self = this
				var userData = this.user();
			
				const params = {
					pageNum: this.pageNum,
					pageSize: this.pageSize,
					keyword: this.keyword,
					state:1
				}
				this.ajax({
					url: "/demand/pageData",
					data:params
				}).then(res => {
					var data = res.data
					
					_self.listData = this.listData.concat(res.data.records)
					_self.total = res.data.total
				});
			},
			changeItem:function(e){
				var status = e.currentTarget.dataset.id
				this.status = status
				this.listData = []
				if(status == 1){
					this.getDemand()
				}else{
					this.getData()
				}
				
				
			},
			room(orderid){
				console.log(orderid)
				this.see = false
				this.agoraroom ="https://new.ofcourse.io/home/page/19046ca72dec43aa8926bdde668e658a?agoraroom="+orderid
			},
			start:function(code){
				var _self = this
				this.ajax({
					url: "/demand/stateData",
					data:{
						'code':code,
						'state':4
					}
				}).then(res => {
					uni.showToast({
						'icon':'none',
						'title':'操作成功'
					})
					_self.listData=[];
					_self.getData()
				});
			},
			confirm:function(code,status){
				var _self = this
				if(status){
					var myDate = new Date();
					var dstr = myDate.getFullYear()+"-"+(myDate.getMonth()+1)+"-"+myDate.getDate()+" "+myDate.getHours()+":"+myDate.getMinutes()+":"+myDate.getSeconds()
					this.ajax({
						url: "/demand/update",
						data:{
							'code':code,
							"state":6,
							"teacherDoneDate":dstr
						}
					}).then(res => {
						uni.showToast({
							title: '操作成功',
							
						})
						_self.listData=[];
						_self.getData()
					});
				}else{
					var myDate = new Date();
					var dstr = myDate.getFullYear()+"-"+(myDate.getMonth()+1)+"-"+myDate.getDate()+" "+myDate.getHours()+":"+myDate.getMinutes()+":"+myDate.getSeconds()
					this.ajax({
						url: "/demand/update",
						data:{
							'code':code,
							"state":4,
							"teacherDoneDate":dstr
						}
					}).then(res => {
						uni.showToast({
							title: '操作成功',
							
						})
						_self.listData=[];
						_self.getData()
					});
				}
				console.log(status)
			}
		}
		
	}
</script>

<style>
	body{
		background-color: #f0f0f0;
	}
	.content {
		font-size: 14px;
		color: #333;
		line-height: 1.5;
		height: 100%;
	}
	.fl{float: left;}
	.fr{float: right;}
	.clear{clear:both; overflow: hidden;}
	.header{height:36px; line-height: 36px; border: 1px solid #dcdcdc; border-radius: 8px; width: 98%; margin: 0 auto; font-size: 14px;  background-color: #f1f1f1; text-align: center;}
	.header picker{position: absolute; right: 0px; top: 0px;  height: 46px; width: 100%;}
	.header picker image{width: 20px; height: 20px; position: absolute; right: 10px; top: 10px;}
	.nav{clear: both; overflow: hidden;  background-color: rgb(0, 198, 93); border-top: 1px solid rgb(0, 198, 93);}
	.nav .nav-item{float: left; width: 20%; text-align: center; line-height: 30px; padding-top: 5px;  color: white; padding-bottom: 10px;}
	.nav .nav-item .sp{height: 4px; width: 20%; border-radius: 4px; background-color: white; margin: 0 auto;}
	
	.list .card{background-color: white; position: relative; width: 96%; border-radius: 6px; margin: 0 auto; box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.2); margin-top: 10px;}
	.list .card .tc image{float: left; width: 100rpx; height:100rpx; margin-right: 20rpx;}

	.list .card .tc .txt .h{font-size: 28rpx;}
	.list .card .tc .txt .p{font-size: 24rpx; display: flex; justify-content: space-between; margin-top: 20rpx; color: #999;}
	.list .card .tc{clear: both; overflow: hidden; padding: 12px; border-bottom: 1px solid #f9f9f9;}
	.list .card .tc .txt .p view{color: #333;}
	.list .card .tc .txt{position: relative; }
	.list .card .tc .txt .pos{position: absolute; top:56px; right:3%; font-size: 28px; color: #2B85E4;}
	.list .card .tc .txt .primary{color: #2B85E4;}
	
	.list .card .bc{clear: both; overflow: hidden; padding:8px 12px; line-height: 30px; border-top: 1px solid #f9f9f9;}
	.list .card button{margin-right: 4px; }
	.button-sp-area{height: 30px;}
	.list .card .circle{width: 4px; height: 4px; border-radius: 50%; display: inline-block; background-color: red; position: absolute; right: 8px; top: 8px;}
	
	
	
</style>
