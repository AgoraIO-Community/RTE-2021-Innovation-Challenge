<template>
	<view class="">
		<view class="lesson-box">
			<view class="lesson-item" v-for="(v,i) in lessonList" :key="i" @click="handleToEdit(v.code)">
				<view class="img-box">
					<u-image width="100%" height="170rpx" :src="imgPath + v.iconPath"></u-image>
				</view>
				<view class="item-express">
					<view class="item-title">
						{{v.content}}
					</view>
					<view class="item-desc">
						<view class="item-price">
							¥{{v.price}}
						</view>
						<view class="item-selling">
							已售{{v.sell}}件
						</view>
					</view>
				</view>
		
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// 当前页
				pageNum: 1,
				// 每页显示数量
				pageSize: 10,
				// 课程数据列表
				lessonList: [],
				// 图片前缀
				imgPath: '',
				// 总条数
				total: 0
			}
		},
		created() {
			this.imgPath = getApp().globalData.imgPath
		},
		mounted() {
		},
		onLoad(option) {
			this.getLessonList(option.code)
		},
		onReachBottom() {
			// console.log(1)
			if (this.total === this.lessonList.length) {
				return uni.showToast({
					icon: 'none',
					title: '已经加载全部了'
				})
			}
			this.pageNum = ++this.pageNum
			this.getLessonList()
		},
		methods: {
			// 获取字典数据
			getData(params) {
				return new Promise((resolve, reject) => {
					this.ajax({
						url: '/const/listData',
						data: params
					}).then(res => {
						resolve(res)
					})
				})
			},
			// 获取课程列表
			getLessonList(code) {
				const params = {
					pageNum: this.pageNum,
					pageSize: this.pageSize,
					type: code
				}
				this.ajax({
					url: '/lesson/pageData',
					data: params
				}).then(res => {
					this.lessonList = this.lessonList.concat(res.data.records)
					this.total = res.data.total
				})
			},
			// 去编辑
			handleToEdit(code) {
				uni.navigateTo({
					url: `../editLesson/index?code=${code}`
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.lesson-box {
		margin-bottom: 120rpx;
		background-color: #f2f3f4;
	
		.lesson-item {
			display: flex;
			padding: 27rpx 10rpx;
			background-color: #fff;
	
			&:nth-child(n+2) {
				margin-top: 10rpx;
			}
	
			.img-box {
				margin-right: 20rpx;
				width: 170rpx;
				height: 170rpx;
				background-color: #000000;
	
			}
	
			.item-express {
				display: flex;
				flex-direction: column;
	
				.item-title {
					font-weight: 600;
					font-size: 30rpx;
				}
	
				.item-desc {
					display: flex;
					margin-top: 10rpx;
	
					.item-price {
						width: 170rpx;
						color: red;
						font-size: 28rpx;
					}
	
					.item-selling {
						color: #ccc;
					}
				}
	
				.item-bd {
					display: flex;
					margin-top: 20rpx;
					color: #ccc;
	
					.item-teacher {
						width: 270rpx;
					}
				}
			}
		}
	}
	
</style>
