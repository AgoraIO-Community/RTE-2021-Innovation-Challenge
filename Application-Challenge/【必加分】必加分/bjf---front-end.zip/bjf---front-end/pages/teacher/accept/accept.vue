<template>
	 <view class="teacher">
		<!-- 搜索框 -->
		<u-sticky :enable="stickyEnable">
		
			<!-- 筛选 -->
			<view class="filter-box">
				<view class="filter-content">
					<view class="filter-item dropdown" @click="handleShowFilter('sort')">
						{{ sortStr || '默认排序'}}
					</view>
					<view class="filter-item dropdown" @click="handleShowFilter('grade')">
						{{ gradeStr || '学生年级'}}
					</view>
					<view class="filter-item dropdown" @click="handleShowFilter('education')">
						{{ educationStr || '院校经验'}}
					</view>
					
					<view class="filter-item dropdown text-overflow" @click="handleShowFilter('sex')">
						{{sexStr || '老师性别'}}
					</view>
					
					<view class="filter-item dropdown text-overflow" @click="isShowLesson = true">
						{{categoryStr || '学科'}}
					</view>
				</view>
		
				<!-- 筛选列选择器 -->
				<u-select v-model="isShowFilter" :list="filterList" label-name="name" value-name="code" @confirm="handlerConfirm"></u-select>
				
				<!-- 学科筛选	 -->
				<u-select v-model="isShowLesson" mode="mutil-column-auto" :list="gridList" label-name="name" value-name="code" @confirm="handlerConfirmLesson"></u-select>
				
				<u-select v-model="isShowArea" mode="mutil-column-auto" :list="areaList" label-name="name" value-name="code" @confirm="handlerConfirmArea"></u-select>
		
				<!-- 精准筛选弹窗 -->
				<u-popup v-model="isShowPopup" mode="right" width="560" :safe-area-inset-bottom="true">
					<view class="popup-content">
						<view class="popup-hd">
							<view class="popup-title">筛选</view>
		
							<view class="popup-item" v-for="(v,i) in 3" :key="i">
								<view class="popup-item-title">
									一级类目
								</view>
								<view class="popup-card">
									<view class="card-item card-item-active">
										不限
									</view>
									<view class="card-item" v-for="(v,i) in 7" :key="i">
										语文数学外语
									</view>
								</view>
							</view>
						</view>
						<view class="popup-btn" @click="isShowPopup = false">
							关闭
						</view>
					</view>
		
				</u-popup>
			</view>
		
		</u-sticky>
		
		<view class="list">
			<view class="card" v-for="(item,index) in listData">
				<view class="tc" @click="$common.jumpurl('/pages/teacher/accept/order_detail?code='+item.code)">
					<view class="txt">
						<view class="p">
							<text>需求科目：{{item.categoryStr}}</text>
							<text>年级：{{item.levelStr}}</text>
						</view>
						<view class="p">
							<text>院校经验：{{item.trainExperienceStr}}</text>
							<text v-if="item.sex == 0">老师性别：女老师</text>
							<text v-if="item.sex == 1">老师性别：男老师</text>
							<text v-if="item.sex == 2">老师性别：不限</text>
						</view>
						<view class="p">期待上课时间：{{item.classDate}}</view>
						<view class="p">课时数量：{{item.times}}个课时（每个课时50分钟）</view>
						<view class="p">
							<view>
								<u-icon name="map" color="#333" size="28" class="uicon"></u-icon>
								{{item.address}}
								<text class="primary">{{item.distance/1000 || '20'}}km</text>
							</view>
						</view>
						<view class="pos">
							￥{{item.price}}
						</view>
						
					</view>
				</view>
				
			</view>
		</view>
		<u-tabbar :list="list" :mid-button="false" active-color="#00c65d"></u-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				status:0,
				listData:[],
				list: getApp().globalData.teacher,
				stickyEnable: false,
				educationStr: '',
				sexStr: '',
				nativePlaceStr: '',
				categoryStr: '',
				filterList: [],
				isShowFilter:false,
				gridList: [{
						icon: 'hourglass',
						name: '语文数学外语'
					},
					{
						icon: 'hourglass',
						name: '语文数学外语'
					},
					{
						icon: 'hourglass',
						name: '语文数学外语'
					},
					{
						icon: 'hourglass',
						name: '语文数学外语'
					},
					{
						icon: 'hourglass',
						name: '语文数学外语'
					},
					{
						icon: 'hourglass',
						name: '语文数学外语'
					},
					{
						icon: 'hourglass',
						name: '语文数学外语'
					},
					{
						icon: 'hourglass',
						name: '语文数学外语'
					},
				],
				sortList:[
					{
						name: '距离最近',
						code:'distance:asc'
					},
					{
						name: '价格最高',
						code:'price:desc'
					},
					{
						name: '距离最远',
						code:'distance:desc'
					},
					{
						name: '价格最低',
						code:'distance:desc'
					},
				],
				gradeList:[
					{
						icon: 'hourglass',
						name: '不限',
						code:"不限"
					},
					{
						icon: 'hourglass',
						name: '高三',
						code:"高三"
					},
					{
						icon: 'hourglass',
						name: '高二',
						code:"高二"
					},
					{
						icon: 'hourglass',
						name: '高一',
						code:"高一"
						
					},
					{
						icon: 'hourglass',
						name: '初三',
						code:"初三"
					},
					{
						icon: 'hourglass',
						name: '初二',
						code:"初二"
					},
					{
						icon: 'hourglass',
						name: '初一',
						code:"初一"
					},
					{
						icon: 'hourglass',
						name: '六年级',
						code:"六年级"
					},
					{
						icon: 'hourglass',
						name: '五年级',
						code:"五年级"
					},
					{
						icon: 'hourglass',
						name: '四年级',
						code:"四年级"
					},
					{
						icon: 'hourglass',
						name: '三年级',
						code:"三年级"
					},
					{
						icon: 'hourglass',
						name: '二年级',
						code:"二年级"
					},
					{
						icon: 'hourglass',
						name: '一年级',
						code:"一年级"
					},
				],
				isShowLesson: false,
				isShowArea: false,
				isShowPopup: false,
				areaList: [],
				gradeStr:'',
				sortStr:'',
				form: {
					level: '',
					education: '',
					category: '',
					price:'',
					distance:''
					
				},
				pageNum:1,
				total:0
				 
			}
		},
		onLoad(option) {
			this.status = option.status?option.status:0
			var _self = this
			uni.getLocation({
			    type: 'wgs84',
			    success: function (res) {
					_self.ajax({
						url: "/user/location",
						data:{
							longitude:res.longitude,
							latitude:res.latitude
						}
					}).then(res => {
						
					});
			       
			    }
			});
			
			
		},
		onReachBottom() {
			console.log(this.listData.length)
			if(this.total <= this.listData.length) {
				return uni.showToast({
					icon: 'none',
					title:'已经加载全部了'
				})
			}
			this.pageNum = ++ this.pageNum
			this.getDemand()
		},
		onShow() {
			this.listData = [];
			this.getCate()
			this.getType()
			this.getLevelList()
			this.getAreaList()
			this.getEducationList()
			this.getDemand()
		},
		methods:{
			gophone(phone){
				uni.makePhoneCall({
				 	
				 	// 手机号
				    phoneNumber: phone, 
					// 成功回调
					success: (res) => {
						console.log('调用成功!')	
					},
				
					// 失败回调
					fail: (res) => {
						console.log('调用失败!')
					}
					
				  });
				
			},
			getDemand(){
				var _self = this
				var userData = this.user();
			
				const params = {
					pageNum: this.pageNum,
					pageSize: this.pageSize,
					...this.form,
					keyword: this.keyword,
					state:1
				}
				this.ajax({
					url: "/demand/pageData",
					data:params
				}).then(res => {
					var data = res.data
					
					_self.listData = this.listData.concat(res.data.records)
					_self.total = res.data.total
				});
			},
			changeItem:function(e){
				var status = e.currentTarget.dataset.id
				this.status = status
				
			},
			recieve:function(code){
				var _self = this
				        
				this.ajax({
					url: "/demand/accept/accept",
					data:{
						'demand':code
					}
				}).then(res => {
					uni.showToast({
						title: '操作成功',
						success:function(){
							
							_self.listData = [];
							_self.getDemand()
							
						}
						
					})
				});
			},
			// 展示筛选列选择器
			handleShowFilter(type) {
				console.log(type)
				if (type === 'education') {
					this.filterList = this.$u.deepClone(this.educationList)
					console.log(this.filterList)
				}
				if(type === 'level') {
					this.filterList = this.$u.deepClone(this.levelList)
				}
				
				if(type === 'type') {
					this.filterList = this.$u.deepClone(this.typeList)
				}
				
				if(type === 'nativePlace') {
					this.filterList = this.$u.deepClone(this.areaList)
				}
				if(type === 'sort'){
					this.filterList = this.sortList
					
				}
				if(type === 'grade'){
					this.filterList = this.$u.deepClone(this.gradeList)
				}
				
				if(type === 'sex') {
					this.filterList = [
						{
							name: '不限',
							code: 2
						},
						{
							name: '男',
							code: 1
						},{
							name: '女',
							code: 0
						}
					]
				}
				this.selectType = type
				this.isShowFilter = true
			},
			handlerConfirm(v) {
				switch(this.selectType) {
					case 'level':
							this.form.level = v[0].value
							this.levelStr = v[0].label
							break;
					case 'type': 
							this.form.type =  v[0].value
							this.typeStr = v[0].label
							break;
					case 'nativePlace': 
							this.form.nativePlace = v[0].value
							this.nativePlaceStr = v[0].label
							break;
					case 'education': 
							this.form.education = v[0].value
							this.educationStr = v[0].label
							break;
					case 'sex':
							this.form.sex = v[0].value
							this.sexStr = v[0].label
							break;
					case 'sort':
							
							var val = v[0].value.split(':')
							if(val[0] == 'distance'){
								this.form.distance = val[1]
							}else{
								this.form.price = val[1]
							}
							this.sortStr = v[0].label
							break;
					case 'grade':
							this.form.level = v[0].value
							this.gradeStr = v[0].label
							break;
				}
				this.getDemand()
			},
			// 获取字典数据
			getData(params) {
				return new Promise((resolve, reject) => {
					this.ajax({
						url: '/const/listData',
						data: params
					}).then(res => {
						resolve(res)
					})
				})
			},
			// 教学课程
			getType() {
				this.getData({
					type: 4
				}).then(res => {
					res.data.forEach(e => {
						e.value = e.code
						e.label = e.name
					})
					this.typeList = res.data
				})
			},
			getEducationList() {
				this.getData({type: 0}).then(res => {
					res.data.forEach(e => {
						if(e.name.indexOf('高中') !== -1) {
							e.name = "不限"
							e.code = ''
						}
					})
					this.educationList = this.delChildren(res.data)
				})
			},
			handlerConfirmLesson(v) {
				this.teacherList = []
				this.form.category = v[1].value
				this.categoryStr = v[1].label
				this.getDemand()
			},
			// 年级
			getLevelList() {
				this.getData({type: 5}).then(res => {
					res.data.forEach(e => {
						e.value = e.code
						e.label = e.name
					})
					this.levelList = res.data
				})
			},
			
			// 区域
			getAreaList() {
				this.ajax({
					url: '/area/cityData',
					method: 'post',
					data:{}
				}).then(res => {
					this.areaList = this.delChildren(res.data)
				})
			},
			getCate() {
				const params = {
					type: 1
				}
				this.getData(params).then(res => {
					res.data.forEach(e => {
						e.icon = 'hourglass',
						e.grid = true
					})
					const params = {
						name: '不限',
						code: '',
						grid: false,
						children: [
							{
								name: '不限',
								code: ''
							}
						]
					}
					res.data.push(params)
					this.gridList = this.delChildren(res.data)
					
				})
			},
			delChildren(temp) {
				temp.forEach(e => {
					if (e.children && e.children.length !== 0) {
						this.delChildren(e.children)
					}
					if (e.children && e.children.length === 0) {
						delete e.children
					}
				})
				return temp
			},
			
		}
		
	}
</script>

<style>
	body{
		background-color: #f0f0f0;
	}
	.content {
		font-size: 14px;
		color: #333;
		line-height: 1.5;
		height: 100%;
	}
	.fl{float: left;}
	.fr{float: right;}
	.clear{clear:both; overflow: hidden;}
	.header{height:36px; line-height: 36px; border: 1px solid #dcdcdc; border-radius: 8px; width: 98%; margin: 0 auto; font-size: 14px;  background-color: #f1f1f1; text-align: center;}
	.header picker{position: absolute; right: 0px; top: 0px;  height: 46px; width: 100%;}
	.header picker image{width: 20px; height: 20px; position: absolute; right: 10px; top: 10px;}
	.nav{clear: both; overflow: hidden;  background-color: rgb(0, 198, 93); border-top: 1px solid rgb(0, 198, 93);}
	.nav .nav-item{float: left; width: 20%; text-align: center; line-height: 30px; padding-top: 5px;  color: white; padding-bottom: 10px;}
	.nav .nav-item .sp{height: 4px; width: 20%; border-radius: 4px; background-color: white; margin: 0 auto;}
	
	.list .card{background-color: white; position: relative; width: 96%; border-radius: 6px; margin: 0 auto; box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.2); margin-top: 10px;}
	.list .card .tc image{float: left; width: 100rpx; height:100rpx; margin-right: 20rpx;}

	.list .card .tc .txt .h{font-size: 28rpx;}
	.list .card .tc .txt .p{font-size: 24rpx; display: flex; justify-content: space-between; margin-top: 20rpx; color: #999;}
	.list .card .tc{clear: both; overflow: hidden; padding: 12px; border-bottom: 1px solid #f9f9f9;}
	.list .card .tc .txt .p view{color: #333;}
	.list .card .tc .txt .p text.primary{color: #2979ff; margin-left: 20rpx;}
	.list .card .tc .txt{position: relative; }
	.list .card .tc .txt .pos{position: absolute; bottom: 45px; right:3%; font-size: 28px; color: #2B85E4;}
	
	.list .card .bc{clear: both; overflow: hidden; padding:8px 12px; line-height: 30px; border-top: 1px solid #f9f9f9;}
	.list .card button{margin-right: 4px; }
	.button-sp-area{height: 30px;}
	.list .card .circle{width: 4px; height: 4px; border-radius: 50%; display: inline-block; background-color: red; position: absolute; right: 8px; top: 8px;}
	
	.filter-content{clear: both; overflow: hidden; border-bottom: 1px solid #f1f1f1;}
	.filter-item{float: left; width: 20%; text-align: center; padding: 20rpx 0px; position: relative;}
	.filter-box .filter-content .dropdown::after {
	    position: absolute;
	    top: 40%;
	    display: inline-block;
	    content: '';
	    margin-left: 2px;
	    width: 6px;
	    height: 6px;
	    border-right: 1px solid #ccc;
	    border-bottom: 1px solid #ccc;
	    -webkit-transform: rotate(45deg) translateY(0%);
	    transform: rotate(45deg) translateY(0%);
	}
</style>
