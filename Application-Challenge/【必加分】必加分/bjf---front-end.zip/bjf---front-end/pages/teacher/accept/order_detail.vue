<template>
	<view class="content">
		<view class="pp" @click="$common.jumpurl('/pages/parent/demand/demand_detail?code='+code)">
			<view>{{data.categoryStr }} | {{data.levelStr }} </view>
			<text>{{data.typeStr }} </text>
			<u-icon name="arrow-right"></u-icon>
		</view>
		<view class="pt">
			<text>订单号</text>
			<text>{{data.id}}</text>
		</view>
		<view class="pt">
			<text>支付金额</text>
			<text >￥{{data.price}}</text>
		</view>
		<view class="pt">
			<text>下单时间</text>
			<text >{{data.createTime}}</text>
		</view>
		<!-- <view class="pt">
			<text class="mr10">备注图片</text>
			<u-image class="f1" width="100%" height="300rpx" :src="`${baseURL}${v.code}`" v-for="(v,i) in data.attaches" :key="i"></u-image>
		</view> -->
		<view class="fixbtn">
			<u-button type="success" @click="recieve" v-if="data.state">立即接单</u-button>
		</view>
	
	</view>
</template>

<script>
	export default {
		data() {
			return {
				icons: ['thumb-down-fill', 'thumb-down-fill', 'thumb-up-fill', 'thumb-up-fill'],
				value:0,
				colors: ['#ffc454', '#ffb409', '#ff9500'],
				data:{},
				baseURL: ''
			}
		},
		onLoad(options){
			this.code = options.code
			this.baseURL = getApp().globalData.imgPath
		},
		methods:{
			recieve:function(){
				var _self = this
				var code = this.code
				        
				this.ajax({
					url: "/demand/accept/accept",
					data:{
						'demand':code
					}
				}).then(res => {
					uni.showToast({
						title: '操作成功',
						success:function(){
							uni.reLaunch({
								"url":"/pages/teacher/accept/accept"
							})
							
						}
						
					})
				});
			}
		},
		
		mounted() {
			var _self = this
			this.userData = this.user();
			this.ajax({
				url: "/demand/findData",
				data:{
					code:this.code
				}
			}).then(res => {
				_self.data = res.data
				console.log(res.data)
			});
		}
	}
</script>
<style>
	.tc image{float: left; width: 100rpx; height:100rpx; margin-right: 20rpx;}
	.tc .txt{ float: left; width: calc(100% - 100px);}
	.tc .txt .h{font-size: 28rpx;}
	.tc .txt .p{font-size: 24rpx; display: flex; justify-content: space-between; margin-top: 20rpx; color: #999;}
	.tc{clear: both; overflow: hidden; padding: 12px; border-bottom: 1px solid #f9f9f9;}
	.space{height: 8rpx; background-color: #f1f1f1;}

	.pt{display: flex; justify-content: space-between; font-size: 24rpx; padding: 28rpx 3%; border-bottom: 1rpx solid #f1f1f1; color: #999;}
	.pp{ font-size: 24rpx; padding: 28rpx 3%; border-bottom: 1rpx solid #f1f1f1; color: #999; position: relative;}
	.pp text{display: block;}
	.pp view{font-size: 16px; color: #333; margin-bottom: 4px;}
	.pp .u-icon{ position: absolute; right: 3%; top:28px; }
	.c{color: #19BE6B;}
	.b{color: #999;}
	.fixbtn{position: fixed; bottom: 0px; width: 100%; left:0px; background-color: white;}
	.content{padding-bottom: 50px;}
</style>
