<template>
	<view>
		<text>老师-在线课堂</text>
		<!-- <u-back-top :scroll-top="scrollTop"></u-back-top> -->
		<u-tabbar :list="list" :mid-button="false" active-color="#00c65d"></u-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: getApp().globalData.teacher
			}
		},
	}
</script>
<style>
</style>
