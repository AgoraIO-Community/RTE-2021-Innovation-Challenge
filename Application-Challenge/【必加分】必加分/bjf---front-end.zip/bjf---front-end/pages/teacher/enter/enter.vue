<template>
	<view class="u-p-30">
		<u-form :model="form" ref="formRef">
			<u-form-item label="您的名称" label-width="150" prop="name" required>
				<u-input placeholder="请输入名称" type="text" v-model="form.name"></u-input>
			</u-form-item>
			<u-form-item label="您的性别" label-width="150" prop="sex" required>
				<u-input placeholder="请选择您的性别" v-model="sexStr" type='select' @click="isShowSelectSex = true"></u-input>
				<u-select v-model="isShowSelectSex" :list="sexList" @confirm="handleSelectSex"></u-select>
			</u-form-item>
			<u-form-item label="联系电话" label-width="150" prop="phone" required>
				<u-input placeholder="请输入您的联系电话" type="text" v-model="form.phone"></u-input>
			</u-form-item>
			<u-form-item label="服务分类" label-width="150" prop="category" required>
				<u-input placeholder="请选择您的服务分类" type="select" v-model="categoryStr" @click="isShowSelectCate = true">
				</u-input>
				<u-select v-model="isShowSelectCate" :list="categoryList" mode="mutil-column-auto" label-name="name"
					value-name="code" @confirm="handleSelectCate"></u-select>
			</u-form-item>
			<u-form-item label="地址" label-width="150">
				<!-- <u-input placeholder="请选择地址" type="text" v-model="form.address"></u-input> -->
				<view class="" @click="handleClickAddress">
					{{addressStr || '请选择地址'}}
				</view>
			</u-form-item>
			<u-form-item label="最高学历" label-width="150" prop="education" required>
				<u-input placeholder="请选择您的最高学历" type="select" v-model="educationStr" @click="isShowSelectEdu = true">
				</u-input>
				<u-select v-model="isShowSelectEdu" :list="eduList" mode="mutil-column-auto" label-name="name"
					value-name="code" @confirm="handleSelectEdu"></u-select>
			</u-form-item>
			<u-form-item label="老师头像" label-width="150" prop="iconPath" required>
				<u-upload width="160" height="160" max-count='1' :action="action" ref="iconPathRef"
					@on-success="handleSuccessIconPath" @on-remove="handleRemoveIconPath" :file-list="iconPathList">
				</u-upload>
			</u-form-item>
			<u-form-item label="自我介绍" label-position="top" prop="summary">
				<u-input type="textarea" placeholder="请填写简介" v-model="form.summary"></u-input>
			</u-form-item>
			<u-form-item label-position="top" label="风采展示">
				<u-upload width="160" height="160" :action="action" ref="attachesRef"
					@on-success="handleSuccessAttaches" :file-list="AttachesFilrList" @on-remove="handleRemoveAttaches">
				</u-upload>
			</u-form-item>
			<u-form-item label-position="top" label="入驻时间" required>
				<u-radio-group v-model="form.contractRange" @change="radioGroupChange" width="auto" :wrap="true">
					<u-radio shape="circle" v-for="(item, index) in radioList" :key="index" :name="item.code">
						{{ item.name }}
					</u-radio>
				</u-radio-group>
			</u-form-item>
		</u-form>
		<view class="agreement">
			<u-checkbox v-model="isRead"></u-checkbox>
			<view class="agreement-text">我已阅读并同意<text style="color:#fa3534" @click="toAgreement">《必加分培训老师入驻须知》</text>
			</view>
		</view>
		<view class="flex safe-area-inset-bottom">
			<u-button v-if="isFirst" type="primary" @click="submit" :loading="loading" size="medium">提交资料</u-button>
			<u-button v-if="!isFirst" type="primary" @click="update" :loading="loading" size="medium">修改资料</u-button>
			<u-button v-if="changeBtn" @click="toVerify" type="success" size="medium">实名认证</u-button>
		</view>
		
		<!-- 弹层 -->
		<u-popup v-model="isShowPop" mode="bottom" height="95%" border-radius="15">
			<my-map @save-address="saveAddress"/>
		</u-popup>
	</view>
</template>

<script>
	import Map from '../../../components/Map/index.vue'
	export default {
		components: {
			'my-map': Map
		},
		data() {
			return {
				loading: false,
				radioList: [{
					name: "三年（0元入驻，免费体验）",
					code: '0'
				}, {
					name: "半年（8元）",
					code: '1'
				}, {
					name: "一年（18元）",
					code: '2'
				}, {
					name: "二年（28元）",
					code: '3'
				}, {
					name: "三年（38元）",
					code: '4'
				}, ],
				form: {
					// 名称
					name: '',
					// 性别
					sex: '',
					// 联系电话
					phone: '',
					// 服务分类
					category: '',
					// 地址
					address: '',
					// 最高学历
					education: '',
					// 自我介绍
					summary: '',
					// 头像
					iconPath: '',
					// 入驻时间
					contractRange: '',
					// 附件集合，风采展示
					attaches: [],
					latitude: '',
					longitude: ''
				},
				// 校验规则
				formRules: {
					name: [{
						required: true,
						message: '请填写您的姓名',
						trigger: ['blur', 'change']
					}],
					sex: [{
						required: true,
						message: '请选择您的性别',
						trigger: ['blur']
					}],
					phone: [{
						required: true,
						message: '请填写您的电话',
						trigger: ['blur', 'change']
					}, {
						// 自定义验证函数，见上说明
						validator: (rule, value, callback) => {
							// 上面有说，返回true表示校验通过，返回false表示不通过
							// this.$u.test.mobile()就是返回true或者false的
							return this.$u.test.mobile(value);
						},
						message: '手机号码不正确',
						// 触发器可以同时用blur和change
						trigger: ['change', 'blur'],
					}],
					// category: [{
					// 	required: true,
					// 	message: '请选择您教的科目',
					// 	trigger: ['blur', 'change']
					// }],
					address: [{
						required: true,
						message: '请填写您的地址',
						trigger: ['blur', 'change']
					}],
					education: [{
						required: true,
						message: '请选择您的最高学历',
						trigger: ['blur', 'change']
					}],
					iconPath: [{
						required: true,
						message: '请上传您的头像',
						trigger: ['blur', 'change']
					}],
					contractRange: [{
						required: true,
						message: '请选择您的入驻时间',
						trigger: ['blur', 'change']
					}],
				},
				// 是否展示选择性别
				isShowSelectSex: false,
				// 性别数据列表
				sexList: [{
						label: '女',
						value: '0'
					},
					{
						label: '男',
						value: '1'
					}
				],
				// 选中的性别展示用
				sexStr: '',
				// 图片上传地址
				action: '',
				// 分类数据列表
				categoryList: [],
				// 是否展示显示分类
				isShowSelectCate: false,
				// 选中的分类，展示用
				categoryStr: '',
				// 最高学历列表数据
				eduList: [],
				// 是否展示最高学历
				isShowSelectEdu: false,
				// 选中的最高学历，展示用
				educationStr: '',
				// 默认风采展示图片列表
				AttachesFilrList: [],
				// 已读须知
				isRead: false,
				// 
				iconPathList: [],
				// 是否有进行实名认证
				isVerify: false,
				// 是否是第一次提交
				isFirst: true,
				changeBtn: false,
				code: '',
				latitude: '',
				longitude: '',
				addressStr: '',
				isShowPop: false
			}
		},
		computed: {

		},
		created() {

		},
		onLoad(options) {
			
		},
		// onShow() {
			
		// 	const tempForm = uni.getStorageSync('enterData') || ''
		// 	const tempStrData = uni.getStorageSync('enterStrData') || ''
		// 	if(tempForm) {
		// 		this.form = Object.assign(this.form, tempForm)
		// 		this.sexStr = tempStrData.sexStr
		// 		this.categoryStr = tempStrData.categoryStr
		// 		this.educationStr = tempStrData.educationStr
		// 	}
		// 	const tempAddress = uni.getStorageSync('address') || ''
		// 	if(tempAddress) {
		// 		this.form.longitude = tempAddress.longitude
		// 		this.longitude = tempAddress.longitude
		// 		this.form.latitude = tempAddress.latitude
		// 		this.latitude = tempAddress.latitude
		// 		this.addressStr = tempAddress.address
		// 	}
		// },
		// onHide() {
		// 	const temp = {
		// 		sexStr: this.sexStr,
		// 		categoryStr: this.categoryStr,
		// 		educationStr: this.educationStr,
		// 	}
		// 	console.log(this.form,'hide')
		// 	uni.setStorageSync('enterStrData', temp)
		// 	uni.setStorageSync('enterData', this.form)
		// },
		// onUnload() {
		// 	uni.removeStorageSync('enterStrData')
		// 	uni.removeStorageSync('enterData')
		// 	uni.removeStorageSync('address')
		// },
		onReady() {
			this.getCategroyList()
			this.getEduList()
			this.getRadioList()
			this.$refs.formRef.setRules(this.formRules)
			this.action = getApp().globalData.baseUrl + 'attach/upload'
			this.getUserData()
			this.getTeachVerify()
			// this.getLocation()
		},
		methods: {
			submit() {
				this.$refs.formRef.validate((valid) => {
					console.log(valid)
					if (!valid) return
					if (!this.form.latitude) return uni.showToast({
						icon: 'none',
						title: '请选择地址'
					})
					if (!this.isRead) return uni.showToast({
						icon: 'none',
						title: '请先阅读入驻须知'
					})
					this.loading = true
					this.ajax({
						url: '/teacher/insert',
						data: {
							...this.form,
							user: JSON.parse(uni.getStorageSync('user')).code,
							address: this.addressStr
						}
					}).then(res => {
						console.log(res)
						this.loading = false
						uni.showToast({
							icon: 'none',
							title: '教师入驻成功'
						})
						uni.navigateBack();
					}).catch(() => {
						this.loading = false
					})
				})
			},
			update() {
				this.$refs.formRef.validate((valid) => {
					console.log(valid)
					if (!valid) return
					if (!this.isRead) return uni.showToast({
						icon: 'none',
						title: '请先阅读入驻须知'
					})
					this.loading = true
					this.ajax({
						url: '/teacher/update',
						data: {
							...this.form,
							user: JSON.parse(uni.getStorageSync('user')).code,
							code: this.code,
							address: this.addressStr
						}
					}).then(res => {
						console.log(res)
						this.loading = false
						uni.showToast({
							icon: 'none',
							title: '编辑成功'
						})
						uni.navigateBack();
					}).catch(() => {
						this.loading = false
					})
				})
			},
			toAgreement() {
				uni.navigateTo({
					url: "/pages/agreement/agreement"
				})
			},
			// 选择性别
			handleSelectSex(value) {
				// console.log(value)
				this.form.sex = value[0].value
				this.sexStr = value[0].label
			},
			// 获取服务分类列表数据
			getCategroyList() {
				const params = {
					type: 1
				}
				this.getData(params).then(res => {

					this.categoryList = this.delChildren(res.data)
					this.categoryList.forEach(e => {
						if (e.children) {
							e.children.forEach(v => {
								if (v.code === this.form.category) {
									this.categoryStr = e.name + '/' + v.name
								}
							})
						}
						if (!e.children) {
							e.children = []
						}
					})
				})

			},
			// 删除空的children
			delChildren(temp) {
				temp.forEach(e => {
					if (e.children && e.children.length !== 0) {
						this.delChildren(e.children)
					}
					if (e.children.length === 0) {
						delete e.children
					}
				})
				return temp
			},
			// 选择分类
			handleSelectCate(value) {
				console.log(value)
				this.form.category = value[value.length - 1].value
				this.categoryStr = value.map(e => e.label).join('/')
			},
			// 获取字典数据
			getData(params) {
				return new Promise((resolve, reject) => {
					this.ajax({
						url: '/const/listData',
						data: params
					}).then(res => {
						resolve(res)
					})
				})
			},
			// 获取最高学历
			getEduList() {
				const params = {
					type: 0
				}
				this.getData(params).then(res => {
					this.eduList = this.delChildren(res.data)
					// this.eduList.find(e => console.log(e.code, this.form.education, '123'))
					const temp = this.eduList.find(e => e.code == this.form.education)
					if (temp) {

						this.educationStr = temp.name
					}
				})
			},
			// 选中最高学历
			handleSelectEdu(value) {
				console.log(value)
				this.form.education = value[0].value
				this.educationStr = value[0].label
			},
			// 点击入驻时间
			radioGroupChange(value) {
				console.log(value)
				this.form
			},
			// 头像上传成功后
			handleSuccessIconPath(data, index, lists, name) {
				console.log(data, index, lists, name)
				// const temp = getApp().globalData.baseUrl + 'attach/download/'
				this.form.iconPath = data.data.code
			},
			// 风采展示上传成功
			handleSuccessAttaches(data, index, lists, name) {
				console.log(lists)
				this.form.attaches = []
				lists.forEach(e => {
					this.form.attaches.push({
						code: e.response ? e.response.data.code : e.url.split('download/')[1]
					})
					
				})
			},
			// 获取入驻时间
			getRadioList() {
				const params = {
					type: 2
				}
				this.getData(params).then((res) => {
					this.radioList = res.data
				})
			},
			// 风采移除图片
			handleRemoveAttaches(index, lists, name) {
				console.log(index, lists, name)
				// if (lists.length === 0) {
				// }
				this.form.attaches = []
				lists.forEach(e => {
					console.log(e)

					this.form.attaches.push({
						code: e.response ? e.response.data.code : e.url.split('download/')[1]
					})
					
					
				})
			},
			// 移除教师头像
			handleRemoveIconPath(index, lists, name) {
				this.form.iconPath = ''
			},
			// 获取入驻资料
			getUserData() {
				this.ajax({
					url: '/teacher/findData',
					data: {
						user: JSON.parse(uni.getStorageSync('user')).code
					}
				}).then(res => {
					console.log(res, 'info ')
					if (!res.data) {
						this.changeBtn = false
						return this.isFirst = true
					} else {
						this.changeBtn = true
						this.isFirst = false
					}
					const {
						name,
						sex,
						phone,
						category,
						education,
						iconPath,
						summary,
						attaches,
						contractRange,
						code,
						latitude,
						longitude,
						address
					} = res.data
					this.form = {
						...this.form,
						name,
						sex: sex.toString(),
						phone,
						category,
						education,
						iconPath,
						summary,
						attaches,
						contractRange,
						latitude,
						longitude
					}
					this.code = code
					this.latitude = latitude
					this.longitude = longitude
					this.addressStr = address
					this.form.attaches = attaches.map(e => {
						const params = {
							code: e.code
						}
						return params
					})
					this.sexStr = this.sexList.find(e => e.value == sex).label
					const tempEdu = this.eduList.find(e => e.code == this.form.education)
					if (tempEdu) {
						this.educationStr = tempEdu.name
					}
					this.categoryList.forEach(e => {
						if (e.children) {
							e.children.forEach(v => {
								if (v.code === this.form.category) {
									this.categoryStr = e.name + '/' + v.name
								}
							})
						}
					})
					this.AttachesFilrList = attaches.map(e => {
						const params = {
							url: getApp().globalData.baseUrl + 'attach/download/' + e.code
						}
						return params
					})

					this.iconPathList = [{
						url: iconPath
					}]
				})


			},

			// 查询教师实名认证
			getTeachVerify() {
				this.ajax({
					url: '/verify/findData',
					data: {
						user: JSON.parse(uni.getStorageSync('user')).code
					}
				}).then(res => {
					console.log(res)
					if (res.data) {
						this.isVerify = true
					}
				})

			},
			// 去实名认证
			toVerify() {
				uni.navigateTo({
					url: '../realname/realname'
				})
			},

			// getLocation() {
			// 	uni.getLocation({
			// 		type: 'gcj02',
			// 		success: (e) => {
			// 			this.latitude = e.latitude,
			// 				this.longitude = e.longitude
			// 		}
			// 	})
			// },
			// handleClickAddress() {
			// 	console.log(1)
				
			// 	const _this = this
			// 	uni.chooseLocation({
			// 		latitude: this.latitude,
			// 		longitude: this.longitude,
			// 		success: (res) => {
			// 			console.log('位置名称：' + res.name);
			// 			console.log('详细地址：' + res.address);
			// 			console.log('纬度：' + res.latitude);
			// 			console.log('经度：' + res.longitude);
			// 			_this.form.latitude = res.latitude
			// 			_this.form.longitude = res.longitude
			// 			_this.addressStr = res.address
			// 		}
			// 	});
			// }
			
			handleClickAddress() {
				// uni.navigateTo({
				// 	url: '../../common/map'
				// })
				this.isShowPop = true
			},
			saveAddress(data) {
				console.log(data,'p')
				this.form.longitude = data.longitude
				this.form.latitude = data.latitude
				this.longitude = data.longitude
				this.latitude = data.latitude
				this.addressStr = data.address
				this.isShowPop = false
			}
		}
	}
</script>

<style lang="scss" scoped>
	.agreement {
		display: flex;
		align-items: center;
		margin: 40rpx 0;
		padding-bottom: 60rpx;

		.agreement-text {
			padding-left: 8rpx;
			color: $u-tips-color;
		}
	}

	.flex {
		position: fixed;
		bottom: 0rpx;
		left: 0;
		right: 0;
		display: flex;
		justify-content: center;
		align-items: center;
		margin-top: 30rpx;
		padding: 15rpx;
		background-color: #f8f8f8;
		border-top: 1rpx solid #f1f1f1;
		z-index: 20;
		u-button {
			&:nth-child(2) {
				margin-left: 50rpx;
			}
		}
	}
</style>
