<template>
	<view class="order">
		<u-gap height="10" bg-color="#eee"></u-gap>
		<!-- 我购买的订单，发布需求订单 -->
		<view class="cell-box">
			<view class="cell-item" >
				<view class="cell-header">
					<view class="cell-title">
						<!-- {{item.name}}	 -->
						课程订单
					</view>
					
					
				</view>
				<view class="cell-content">
					<view class="cell-grid"  @click="$common.jumpurl('/pages/parent/order/index?status=0')">
						<u-icon name="list" size="40"></u-icon>
						<text>全部</text>
					</view>
					<view class="cell-grid"  @click="$common.jumpurl('/pages/parent/order/index?status=1')">
						<u-icon name="red-packet" size="40"></u-icon>
						<text>待付款</text>
					</view>
					<view class="cell-grid"  @click="$common.jumpurl('/pages/parent/order/index?status=2')">
						<u-icon name="edit-pen" size="40"></u-icon>
						<text>待上课</text>
					</view>
					
					<view class="cell-grid"  @click="$common.jumpurl('/pages/parent/order/index?status=4')">
						<u-icon name="bag" size="40"></u-icon>
						<text>待完成</text>
					</view>
					<view class="cell-grid"  @click="$common.jumpurl('/pages/parent/order/index?status=3')">
						<u-icon name="heart" size="40"></u-icon>
						<text>待评价</text>
					</view>
				</view>
			</view>
			<view class="cell-item" >
				<view class="cell-header">
					<view class="cell-title">
						需求订单	
					</view>
					
				</view>
				<view class="cell-content">
					<view class="cell-grid" @click="$common.jumpurl('/pages/teacher/demand/index?status=0')">
						<u-icon name="list" size="40"></u-icon>
						<u-badge size="mini" type="success" :count="allnum"></u-badge>
						<text>全部</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/teacher/demand/index?status=1')">
						<u-icon name="edit-pen" size="40"></u-icon>
						<u-badge size="mini" type="success" :count="demandNum[1]"></u-badge>
						<text>待接单</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/teacher/demand/index?status=2')">
						<u-icon name="edit-pen" size="40"></u-icon>
						<u-badge size="mini" type="success" :count="demandNum[2]"></u-badge>
						<text>待上课</text>
					</view>
					
					<view class="cell-grid" @click="$common.jumpurl('/pages/teacher/demand/index?status=4')">
						<u-icon name="bag" size="40"></u-icon>
						<u-badge size="mini" type="success" :count="demandNum[4]"></u-badge>
						<text>待完成</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/teacher/demand/index?status=6')">
						<u-icon name="heart" size="40"></u-icon>
						<u-badge size="mini" type="success" :count="demandNum[6]"></u-badge>
						<text>待评价</text>
					</view>
				</view>
			</view>
			<view class="cell-item" >
				<view class="cell-header">
					<view class="cell-title">
						商品服务	
					</view>
					
				</view>
				<view class="cell-content">
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=0')">
						<u-icon name="list" size="40"></u-icon>
						<text>全部</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=1')">
						<u-icon name="red-packet" size="40"></u-icon>
						<text>待付款</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=2')">
						<u-icon name="map" size="40"></u-icon>
						<text>待发货</text>
					</view>
					
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=4')">
						<u-icon name="fingerprint" size="40"></u-icon>
						<text>待收货</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=3')">
						<u-icon name="heart" size="40"></u-icon>
						<text>待评价</text>
					</view>
				</view>
			</view>
			<view class="cell-item" >
				<view class="cell-header">
					<view class="cell-title">
						电子订单	
					</view>
					
				</view>
				<view class="cell-content">
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=0')">
						<u-icon name="list" size="40"></u-icon>
						<text>全部</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=1')">
						<u-icon name="red-packet" size="40"></u-icon>
						<text>待付款</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=2')">
						<u-icon name="clock" size="40"></u-icon>
						<text>待下载</text>
					</view>
					
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=4')">
						<u-icon name="download" size="40"></u-icon>
						<text>已下载</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=3')">
						<u-icon name="heart" size="40"></u-icon>
						<text>待评价</text>
					</view>
				</view>
			</view>
		</view>
		<u-tabbar :list="list" :mid-button="false" active-color="#00c65d"></u-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: getApp().globalData.teacher,
				tabList: [],
				demandList:{},
				demandNum:{
					0:0,
					1:0,
					2:0,
					4:0,
					6:0
				},
				allnum:0
			}
		},
		onShow() {
			this.demandNum={
					0:0,
					1:0,
					2:0,
					4:0,
					6:0
				}
			this.getTabList()
			this.getOrder()
			this.getOrder_1()
		},
		methods: {
			getTabList() {
				const temp = [
					{
						name: '在线课堂',
						children: [
							{
								icon: 'daifukuan',
								text: '待付款'
							},{
								icon: 'daishiyong',
								text: '待上课'
							},{
								icon: 'daipingjia',
								text: '待完成'
							},{
								icon: 'tuikuan2',
								text: '评价'
							}
						]
					},
					{
						name: '商品服务',
						children: [
							{
								icon: 'daifukuan',
								text: '待付款'
							},{
								icon: 'daishiyong',
								text: '待发货'
							},{
								icon: 'daipingjia',
								text: '待收货'
							},{
								icon: 'tuikuan2',
								text: '评价'
							}
						]
					},
					{
						name: '电子订单',
						children: [
							{
								icon: 'daifukuan',
								text: '待付款'
							},{
								icon: 'daishiyong',
								text: '待下载'
							},{
								icon: 'daipingjia',
								text: '已下载'
							},{
								icon: 'tuikuan2',
								text: '评价'
							}
						]
					}
				]
				this.tabList = temp
			},
			
			getOrder:function(){
				var _self = this
				var userData = this.user();
				this.ajax({
					url: "/demand/accept/listData",
					data:{
						'code':userData.code
					}
				}).then(res => {
					var data = res.data
					for(var i in data){
						var state = data[i].demand_.state
						_self.demandNum[state] ++
					}
					_self.allnum += data.length
					console.log(_self.demandNum)
					
				});
			},
			getOrder_1:function(){
				var _self = this
				var userData = this.user();
				this.ajax({
					url: "/demand/listData",
					data:{
						state:1
					}
				}).then(res => {
					var data = res.data
					for(var i in data){
						var state = data[i].state
						_self.demandNum[state] ++
						if(_self.demandNum[state] > 99){
							_self.demandNum[state] = "99+"
						}
					}
				});
			},
		}
	}
</script>

<style lang="scss" scoped>
	.icon-image {
		width: 50rpx;
		height: 50rpx;
	}
	
	.cell-box {
		padding-bottom: 15rpx;
		background-color: #eee;
		
	}
	.cell-item {
		&:nth-child(n+1) {
			margin-top: 15rpx;
		}
		background-color: #fff;
		.cell-header {
			display: flex;
			justify-content: space-between;
			padding: 20rpx;
			height: 80rpx;
			border-bottom: 2rpx solid #f2f3f4;
			font-size: 26rpx;
			
			.cell-right {
				color: #888;
				&::after {
					content: '';
					display: inline-block;
					width: 16rpx;
					height: 16rpx;
					border-top: 2rpx solid #888;
					border-right: 2rpx solid #888;
					transform: rotate(45deg);
				}
			}
		}
	
		.cell-content {
			display: flex;
			justify-content: space-around;
			height: 180rpx;
			background-color: #fff;
			
			.cell-grid {
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				font-size: 30rpx;
			}
		}
	}
	.list .card{background-color: white; position: relative; width: 96%; border-radius: 6px; margin: 0 auto; box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.2); margin-top: 10px;}
	.list .card .tc image{float: left; width: 100rpx; height:100rpx; margin-right: 20rpx;}
	.list .card .tc .txt{ float: left; width: calc(100% - 100px);}
	.list .card .tc .txt .h{font-size: 28rpx;}
	.list .card .tc .txt .p{font-size: 24rpx; display: flex; justify-content: space-between; margin-top: 20rpx; color: #999;}
	.list .card .tc{clear: both; overflow: hidden; padding: 12px; border-bottom: 1px solid #f9f9f9;}
	.list .card .tc .txt .p view{color: #333;}
	
	.list .card .bc{clear: both; overflow: hidden; padding:8px 12px; line-height: 30px; border-top: 1px solid #f9f9f9;}
	.list .card button{margin-right: 4px; }
	.button-sp-area{height: 30px;}
	.list .card .circle{width: 4px; height: 4px; border-radius: 50%; display: inline-block; background-color: red; position: absolute; right: 8px; top: 8px;}
	.cell-grid{position: relative;}
	.cell-grid .u-badge{position: absolute; right:0px!important; top:20px!important}
</style>
