<template>
	<view class="u-p-30">
		<u-form :model="formData" :rules="rules" ref="uForm" :errorType="['toast','border-bottom']">
			<u-form-item label="真实姓名" label-width="150" prop="name" required>
				<u-input placeholder="请输入姓名" type="text" v-model="formData.name"></u-input>
			</u-form-item>
			<u-form-item label="身份证号码" label-width="150" prop="name" required>
				<u-input placeholder="请输入身份证" type="text" v-model="formData.identity"></u-input>
			</u-form-item>
			<u-form-item label="籍贯" label-width="150" prop="name" required>
				<u-input placeholder="请选择籍贯" type="select" v-model="formData.nativePlace" @click="nativePlace=true">
				</u-input>
				<u-picker v-model="nativePlace" mode="region" @confirm="nativePlaceChoose"></u-picker>
			</u-form-item>
			<u-form-item label="最高学历" label-width="150" prop="name" required>
				<u-input placeholder="请选择学历" type="select" v-model="formData.educationStr" @click="education=true">
				</u-input>
				<u-select v-model="education" :list="educationList" @confirm="educationChoose"></u-select>
			</u-form-item>
			<u-form-item label="学校全称" label-width="150" prop="name">
				<u-input placeholder="请输入学校全称" type="text" v-model="formData.school"></u-input>
			</u-form-item>
			<u-form-item label="专业全称" label-width="150" prop="name">
				<u-input placeholder="请输入专业全称" type="text" v-model="formData.major"></u-input>
			</u-form-item>
			<u-form-item label="学校类型" label-width="150" prop="name" required>
				<u-input placeholder="请输入学校类型" type="select" v-model="formData.schoolTypeStr" @click="schoolType=true">
				</u-input>
				<u-select v-model="schoolType" :list="schoolTypeList" @confirm="schoolTypeChoose"></u-select>
			</u-form-item>
			<u-form-item label="入学年份" label-width="150" prop="name" required>
				<u-input placeholder="请选择入学年份" type="select" v-model="formData.schoolDate" @click="schoolDate=true">
				</u-input>
				<u-picker v-model="schoolDate" mode="time" :params="schoolDateParams" @confirm="schoolDateChoose">
				</u-picker>
			</u-form-item>
			<u-form-item label="培训经验" label-width="150" prop="name" required>
				<u-number-box v-model="formData.trainExperience"></u-number-box>
				<text>年</text>
			</u-form-item>
			<u-form-item label="是否有教师资格证" label-width="250" prop="name" required>
				<u-switch slot="right" v-model="teacherCertificate"></u-switch>
			</u-form-item>
			<u-form-item label-position="top" label="教师资格证" required v-if="teacherCertificate">
				<u-upload ref="teacherCertificate" max-count="1" width="160" height="160" :action="upLoadAction"
					:fileList="teacherCertificateList" upload-text="教师资格证" :show-progress="false"
					@on-remove="teacherCertificateRemove"></u-upload>
			</u-form-item>
			<u-form-item label-position="top" label="身份证" required>
				<u-upload ref="identityFront" max-count="1" width="160" height="160" :action="upLoadAction"
					:fileList="identityFrontList" upload-text="身份证正面" :show-progress="false"
					@on-remove="identityFrontRemove"></u-upload>
				<u-upload ref="identityBack" max-count="1" width="160" height="160" :action="upLoadAction"
					:fileList="identityBackList" upload-text="身份证反面" :show-progress="false"
					@on-remove="identityBackRemove"></u-upload>
				<u-upload ref="identityHand" max-count="1" width="160" height="160" :action="upLoadAction"
					:fileList="identityHandList" upload-text="手持身份证" :show-progress="false"
					@on-remove="identityHandRemove"></u-upload>
			</u-form-item>
			<u-form-item label-position="top" label="学历/学位证书" required>
				<u-upload ref="record" max-count="1" width="160" height="160" :action="upLoadAction"
					:fileList="recordList" upload-text="学历证书" :show-progress="false" @on-remove="recordRemove">
				</u-upload>
				<u-upload ref="degree" max-count="1" width="160" height="160" :action="upLoadAction"
					:fileList="degreeList" upload-text="学位证书" :show-progress="false" @on-remove="degreeRemove">
				</u-upload>
			</u-form-item>
		</u-form>
		<u-button type="success" @click="submit" style="margin-top: 30rpx;" :loading="loading">提交</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				loading: false,
				userData: {},
				formData: {
					name: "",
					trainExperience: 1,
					attaches: []
				},
				education: false,
				educationList: [],
				schoolDate: false,
				schoolDateParams: {
					year: true,
					month: true,
					day: false,
					hour: false,
					minute: false,
					second: false
				},
				schoolType: false,
				schoolTypeList: [],
				nativePlace: false,
				teacherCertificate: false,
				upLoadAction: "",
				teacherCertificateList: [],
				identityFrontList: [],
				identityBackList: [],
				identityHandList: [],
				recordList: [],
				degreeList: [],
				rules: []
			}
		},
		onReady() {
			this.$refs.uForm.setRules(this.rules);
			this.userData = this.user();
			this.listConst(0);
			this.listConst(3);
			this.ajax({
				url: "verify/findData",
				data: {
					user: this.userData.code
				}
			}).then(res => {
				let rootPath = getApp().globalData.baseUrl;
				if (null != res.data)
					this.formData = res.data;
				this.formData.attaches.forEach(i => {
					if (i.type == "teacherCertificate") {
						this.teacherCertificate = true;
						this.teacherCertificateList.push({
							url: rootPath + "attach/download/" + i.code
						});
					} else if (i.type == "identityFront") {
						this.identityFrontList.push({
							url: rootPath + "attach/download/" + i.code
						});
					} else if (i.type == "identityBack") {
						this.identityBackList.push({
							url: rootPath + "attach/download/" + i.code
						});
					} else if (i.type == "identityHand") {
						this.identityHandList.push({
							url: rootPath + "attach/download/" + i.code
						});
					} else if (i.type == "record") {
						this.recordList.push({
							url: rootPath + "attach/download/" + i.code
						});
					} else if (i.type == "degree") {
						this.degreeList.push({
							url: rootPath + "attach/download/" + i.code
						});
					}
				});
			});
			this.upLoadAction = getApp().globalData.baseUrl + "/attach/upload";
		},
		methods: {
			teacherCertificateRemove() {
				let idx = this.formData.attaches.findIndex(i => {
					return i.type == "teacherCertificate";
				});
				this.formData.attaches.splice(idx, 1);
			},
			identityFrontRemove() {
				let idx = this.formData.attaches.findIndex(i => {
					return i.type == "identityFront";
				});
				this.formData.attaches.splice(idx, 1);
			},
			identityBackRemove() {
				let idx = this.formData.attaches.findIndex(i => {
					return i.type == "identityBack";
				});
				this.formData.attaches.splice(idx, 1);
			},
			identityHandRemove() {
				let idx = this.formData.attaches.findIndex(i => {
					return i.type == "identityHand";
				});
				this.formData.attaches.splice(idx, 1);
			},
			recordRemove() {
				let idx = this.formData.attaches.findIndex(i => {
					return i.type == "record";
				});
				this.formData.attaches.splice(idx, 1);
			},
			degreeRemove() {
				let idx = this.formData.attaches.findIndex(i => {
					return i.type == "degree";
				});
				this.formData.attaches.splice(idx, 1);
			},
			listConst(type) {
				this.ajax({
					url: "const/listData",
					data: {
						type: type
					}
				}).then(res => {
					let data = [];
					res.data.forEach(i => {
						data.push({
							value: i.code,
							label: i.name
						});
					});
					switch (type) {
						case 0:
							this.educationList = data;
							break;
						case 3:
							this.schoolTypeList = data;
							break;
					}
				});
			},
			nativePlaceChoose(e) {
				let value = e.province.label + "-" + e.city.label + "-" + e.area.label;
				this.formData.nativePlace = value;
			},
			educationChoose(e) {
				this.formData.education = e[0].value;
				this.formData.educationStr = e[0].label;
			},
			schoolTypeChoose(e) {
				this.formData.schoolType = e[0].value;
				this.formData.schoolTypeStr = e[0].label;
			},
			schoolDateChoose(e) {
				let value = e.year + "-" + e.month;
				this.formData.schoolDate = value;
			},
			submit() {
				//校验附件
				let attaches = this.formData.attaches;
				if (this.teacherCertificate) {
					this.$refs.teacherCertificate.lists.forEach(i => {
						if (null != i.response && i.progress == 100) {
							attaches.push({
								type: "teacherCertificate",
								code: i.response.data.code
							});
						}
					});
				}
				this.$refs.identityFront.lists.forEach(i => {
					if (null != i.response && i.progress == 100) {
						attaches.push({
							type: "identityFront",
							code: i.response.data.code
						});
					}
				});
				this.$refs.identityBack.lists.forEach(i => {
					if (null != i.response && i.progress == 100) {
						attaches.push({
							type: "identityBack",
							code: i.response.data.code
						});
					}
				});
				this.$refs.identityHand.lists.forEach(i => {
					if (null != i.response && i.progress == 100) {
						attaches.push({
							type: "identityHand",
							code: i.response.data.code
						});
					}
				});
				this.$refs.record.lists.forEach(i => {
					if (null != i.response && i.progress == 100) {
						attaches.push({
							type: "record",
							code: i.response.data.code
						});
					}
				});
				this.$refs.degree.lists.forEach(i => {
					if (null != i.response && i.progress == 100) {
						attaches.push({
							type: "degree",
							code: i.response.data.code
						});
					}
				});
				this.formData.attaches = attaches;
				this.formData.user = this.userData.code;
				this.$refs.uForm.validate(valid => {
					if (valid) {
						this.ajax({
							url: "verify/" + (this.formData.id == null ? "insert" : "update"),
							data: this.formData
						}).then(res => {
							uni.navigateBack();
						});
					}
				});
			}
		}
	}
</script>

<style>
</style>
