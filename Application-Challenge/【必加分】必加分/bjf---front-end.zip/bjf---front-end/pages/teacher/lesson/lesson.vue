<template>
	<view class="lesson">
		<view class="">
			<!-- 宫格区域 -->
			<view class="grid">
				<u-grid :col="4" :border="false">
					<u-grid-item v-for="(v,i) in gridList" :key="i" @click="handleTo(v.code)">
						<u-icon :name="v.icon" :size="46"></u-icon>
						<view class="grid-text">{{v.name}}</view>
					</u-grid-item>
				</u-grid>
			</view>
			
			<!-- 搜索框 -->
			<!-- <u-sticky :enable="stickyEnable"> -->
			
				<!-- 筛选 -->
				<!-- <view class="filter-box">
					<view class="filter-content">
						<view class="filter-item dropdown" @click="handleShowFilter('distance')">
							距离最近
						</view>
						<view class="filter-item">
							精选老师
						</view>
						<view class="filter-item dropdown">
							老师籍贯
						</view>
						<view class="filter-item dropdown">
							院校筛选
						</view>
						<view class="filter-item" @click="isShowPopup = true">
							精准筛选
						</view>
					</view> -->
			
					<!-- 筛选列选择器 -->
					<!-- <u-select v-model="isShowFilter" :list="filterList"></u-select> -->
			
					<!-- 精准筛选弹窗 -->
					<u-popup v-model="isShowPopup" mode="right" width="560" :safe-area-inset-bottom="true">
						<view class="popup-content">
							<view class="popup-hd">
								<view class="popup-title">筛选</view>
			
								<view class="popup-item" v-for="(v,i) in 3" :key="i">
									<view class="popup-item-title">
										一级类目
									</view>
									<view class="popup-card">
										<view class="card-item card-item-active">
											不限
										</view>
										<view class="card-item" v-for="(v,i) in 7" :key="i">
											语文数学外语
										</view>
									</view>
								</view>
							</view>
							<view class="popup-btn" @click="isShowPopup = false">
								关闭
							</view>
						</view>
			
					</u-popup>
				<!-- </view> -->
			
			<!-- </u-sticky> -->
			
			<!-- <view class="fixed-btn">
				<u-button type="success" @click="handleTo('')">发布课程</u-button>
			</view> -->
			
			
			<u-gap height="10" bg-color="#f2f2f2"></u-gap>
			<view class="lesson-box">
				<u-cell-group>
						<u-cell-item :title="v.name" v-for="(v,i) in typeList" :key="i" @click="handleToList(v)"></u-cell-item>
					</u-cell-group>
			</view>
		</view>

		<view class="fixed-btn">
			<u-button type="success" @click="handleTo('')">发布课程</u-button>
		</view>

		<u-tabbar :list="list" :mid-button="false" active-color="#00c65d"></u-tabbar>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				gridList: [],
				stickyEnable: false,
				// 列选择器数据
				filterList: [],
				distanceList: [],
				isShowFilter: false,
				isShowPopup: false,
				list: getApp().globalData.teacher,
				// 图片前缀
				imgPath: '',
				typeList: []
			}
		},
		created() {
			this.imgPath = getApp().globalData.imgPath
		},
		mounted() {
			this.getCate()
			this.stickyEnable = true
			this.getTypeList()
		},
		onShow() {
			
		},
		onHide() {
			this.stickyEnable = false
		},
		
		methods: {
			// 获取字典数据
			getData(params) {
				return new Promise((resolve, reject) => {
					this.ajax({
						url: '/const/listData',
						data: params
					}).then(res => {
						resolve(res)
					})
				})
			},
			
			getTypeList() {
				const params = {
					type: 4
				}
				this.getData(params).then(res => {
					this.typeList = res.data
				})
			},
			
			// 获取学科分类
			getCate() {
				const params = {
					type: 1
				}
				this.getData(params).then(res => {
					res.data.forEach(e => {
						e.icon = 'hourglass'
					})
					this.gridList = res.data

				})
			},
			// 展示筛选列选择器
			handleShowFilter(type) {
				console.log(type)
				if (type === 'distance') {
					this.filterList = this.distanceList
				}

				this.isShowFilter = true
			},

			handleTo(code) {
				console.log(code, 'code')
				uni.navigateTo({
					url: `../submitLesson/index?code=${code}`
				})
			},
			
			handleToList(v) {
				uni.navigateTo({
					url: `../lessonList/index?code=${v.code}`
				})
			}
			
			
		}
	}
</script>

<style lang="scss" scoped>
	@import url(../../../assets/css/index.css);
	.lesson {
		::v-deep.u-mask,
		::v-deep.u-drawer {
			bottom: 100rpx;
		}
	}
	
	.grid {
		width: 95%;
		margin: 10px auto 0;
	}

	.search {
		padding: 30rpx 10rpx;
		// padding: 10rpx;
		background-color: #00c65d;
	}

	.filter-box {
		height: 70rpx;
		line-height: 70rpx;
		font-size: 26rpx;

		.filter-content {
			display: flex;
			justify-content: space-between;
			padding: 0 10rpx;
			background-color: #fff;
			border-bottom: 2rpx solid #F1F1F1;

			.dropdown {
				&::after {
					display: inline-block;
					content: '';
					margin-left: 10rpx;
					width: 18rpx;
					height: 18rpx;
					border-right: 2rpx solid #ccc;
					border-bottom: 2rpx solid #ccc;
					transform: rotate(45deg) translateY(-4rpx);
				}
			}
		}
	}


	.lesson-box {
		margin-bottom: 120rpx;
		background-color: #f2f3f4;

		.lesson-item {
			display: flex;
			padding: 27rpx 10rpx;
			background-color: #fff;

			&:nth-child(n+2) {
				margin-top: 10rpx;
			}

			.img-box {
				margin-right: 20rpx;
				width: 170rpx;
				height: 170rpx;
				background-color: #000000;

			}

			.item-express {
				display: flex;
				flex-direction: column;

				.item-title {
					font-weight: 600;
					font-size: 30rpx;
				}

				.item-desc {
					display: flex;
					margin-top: 10rpx;

					.item-price {
						width: 170rpx;
						color: red;
						font-size: 28rpx;
					}

					.item-selling {
						color: #ccc;
					}
				}

				.item-bd {
					display: flex;
					margin-top: 20rpx;
					color: #ccc;

					.item-teacher {
						width: 270rpx;
					}
				}
			}
		}
	}


	.fixed-btn {
		padding-top: 10rpx;
		bottom: 100rpx;
		left: 10rpx;
		right: 10rpx;
		background-color: #fff;
	}
	
	.popup-content {
		display: flex;
		flex-direction: column;
		height: 100%;
	
		.popup-hd {
			flex: 1;
		}
	
		.popup-btn {
			height: 70rpx;
			line-height: 70rpx;
			text-align: center;
			color: #999;
			background-color: #eee;
		}
	}
	.popup-title {
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		border-bottom: 1rpx solid #f2f3f4;
	}
	
	.popup-item {
		padding: 0 10rpx;
		min-height: 322rpx;
	}
	
	.popup-item-title {
		height: 70rpx;
		line-height: 70rpx;
		color: #000;
		font-size: 30rpx;
		font-weight: 600;
	}
	
	.popup-card {
		display: flex;
		flex-wrap: wrap;
	}
	
	.card-item {
		margin-right: 12rpx;
		margin-bottom: 20rpx;
		width: 160rpx;
		height: 64rpx;
		line-height: 64rpx;
		text-align: center;
		background-color: #f6f6f6;
		border: 1rpx solid #f6f6f6;
		border-radius: 10rpx;
	}
	
	.card-item-active {
		border: 1rpx solid #00c65d;
		background-color: #cff4e0;
	}
</style>
