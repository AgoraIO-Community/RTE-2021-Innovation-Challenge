<template>
	<view class="lesson">
		<!-- <text>老师-发布课程</text> -->
		<u-form :model="form" ref="formRef">

			<u-form-item label="学科分类" label-width="150" prop="category" required>
				<u-input placeholder="请选择您的学科分类" type="select" v-model="categoryStr" @click="isShowSelectCate = true">
				</u-input>
				<u-select v-model="isShowSelectCate" :list="categoryList" mode="mutil-column-auto" label-name="name"
					value-name="code" @confirm="handleSelectCate" :default-value="cateDefault"></u-select>
			</u-form-item>

			<u-form-item label="课程年级" label-width="150" prop="category" required>
				<u-input placeholder="请选择年级" type="select" v-model="levelStr" @click="isShowSelectGrade = true">
				</u-input>
				<u-select v-model="isShowSelectGrade" :list="tempGradeList" label-name="name" value-name="code"
					@confirm="handleSelectGrade"></u-select>
			</u-form-item>

			<u-form-item label="教学分类" label-width="150" prop="type" required>
				<u-input placeholder="请选择您的教学分类" type="select" v-model="typeStr" @click="isShowSelectType = true">
				</u-input>
				<u-select v-model="isShowSelectType" :list="typeList" label-name="name" value-name="code"
					@confirm="handleSelectType"></u-select>
			</u-form-item>

			<u-form-item label="课程形式" label-width="150" required>
				<u-input v-model="styleStr" placeholder="请选择课程形式" type="select" @click="isShowSelectStyle = true">
				</u-input>
				<u-select v-model="isShowSelectStyle" :list="styleList" @confirm="handleSelectStyle"></u-select>
			</u-form-item>

			<u-form-item label="地址" label-width="150" prop="address" required>
				<!-- <u-input placeholder="请选择地址" type="text" v-model="form.address"></u-input> -->
				<view class="" @click="handleClickAddress">
					{{addressStr || '请选择地址'}}
				</view>
			</u-form-item>

			<u-form-item label="面向省份" label-width="150" required prop="provide">
				<u-input placeholder="请选择面向省份" type="select" v-model="form.provide" @click="isShowSelectProvide = true">
				</u-input>
				<u-select v-model="isShowSelectProvide" :list="provideList" label-name="name" value-name="code"
					@confirm="handleSelectProvide"></u-select>
			</u-form-item>

			<u-form-item label="课程价格" label-width="150" prop="price" required>
				<u-input placeholder="请输入价格" v-model="form.price" type="number"></u-input>
			</u-form-item>

			<!-- <u-form-item label="课程介绍" label-width="150" prop="content" required>
				<u-input placeholder="请输入课程介绍" v-model="form.content" type="textarea"></u-input>
			</u-form-item> -->

			<u-form-item label="课程名称或简介" label-position="top" prop="content" required>
				<u-input placeholder="请输入名称" type="textarea" v-model="form.content"></u-input>
			</u-form-item>

			<u-form-item label="课程关键字" label-position="top">
				<u-input placeholder="请输入课程关键字" type="text" v-model="form.keyword"></u-input>
			</u-form-item>

			<u-form-item label-position="top" label="图片展示">
				<u-upload width="160" height="160" max-count='9' :action="action" ref="iconPathRef"
					@on-success="handleSuccessIconPath" @on-remove="handleRemoveIconPath" :file-list="iconPathList">
				</u-upload>
			</u-form-item>

		</u-form>

		<view class="fixed-btn">
			<u-button type="success" @click="handleSubmit" :loading="loading">立即发布</u-button>
		</view>
		<!-- <u-back-top :scroll-top="scrollTop"></u-back-top> -->
		<!-- <u-tabbar :list="list" :mid-button="false" active-color="#00c65d"></u-tabbar> -->
		
		<!-- 弹层 -->
		<u-popup v-model="isShowPop" mode="bottom" height="95%" border-radius="15">
			<my-map @save-address="saveAddress"/>
		</u-popup>
	</view>
</template>

<script>
	import Map from '../../../components/Map/index.vue'
	
	export default {
		components: {
			'my-map': Map
		},
		data() {
			return {
				list: getApp().globalData.teacher,
				form: {
					keyword: '',
					price: '',
					content: '',
					category: '',
					level: '',
					type: '',
					iconPath: '',
					latitude: '',
					longitude: ''
				},
				formRules: {
					// title: [{
					// 	required: true,
					// 	message: '请填写课程标题',
					// 	trigger: ['blur', 'change']
					// }],
					price: [{
						required: true,
						message: '请填写课程价格',
						trigger: ['blur', 'change']
					}],
					content: [{
						required: true,
						message: '请填写课程内容',
						trigger: ['blur', 'change']
					}],
					category: [{
						required: true,
						message: '请选择课程分类',
						trigger: ['blur', 'change']
					}],
					level: [{
						required: true,
						message: '请选择年级',
						trigger: ['blur', 'change']
					}],
					type: [{
						required: true,
						message: '请选择课程类型',
						trigger: ['blur', 'change']
					}],
					iconPath: [{
						required: true,
						message: '请上传课程图片',
						trigger: ['blur', 'change']
					}],
				},
				categoryStr: '',
				isShowSelectCate: false,
				categoryList: [],
				levelStr: '',
				isShowSelectGrade: false,
				GradeList: [],
				AttachesFilrList: [],
				// 图片上传地址
				action: '',
				typeStr: '',
				isShowSelectType: false,
				typeList: [],
				iconPathList: [],
				loading: false,
				cateDefault: [],
				disabledLevel: false,
				styleList: [{
					value: '0',
					label: '一对一'
				}],
				isShowSelectStyle: false,
				styleStr: '一对一',
				provideStr: '',
				provideList: [],
				isShowSelectProvide: false,
				addressStr: '',
				latitude: '',
				longitude: '',
				isShowPop: false
			}
		},
		watch: {
			form: {
				handler() {
					const tempCate = this.categoryList.filter(e => !e.mark1)

					let flag = false
					tempCate.forEach(e => {
						e.children.forEach(v => {
							if (v.code === this.form.category) {
								return flag = true
							}
						})
					})

					if (flag) {
						const tempGrade = this.GradeList.find(e => !e.mark1)
						if (tempGrade) {
							this.levelStr = tempGrade.name
							this.form.level = tempGrade.code
							this.disabledLevel = true
						}
					} else {

						this.disabledLevel = false
					}

				},
				deep: true
			}
		},
		computed: {
			tempGradeList() {
				if (this.disabledLevel) {
					return this.GradeList.filter(e => !e.mark1)
				} else {

					return this.GradeList
				}
			}
		},
		created() {
			this.action = getApp().globalData.baseUrl + 'attach/upload'
		},
		mounted() {
			this.getCategroyList()
			this.getGradeList()
			this.getTypeList()
			this.getAreaList()
			// this.getLocation()
		},
		onReady() {
			this.$refs.formRef.setRules(this.formRules)
		},
		onLoad(option) {
			console.log(option)
			if (option.code) {
				this.getLesson(option.code)
			}
		},
		// onShow() {

		// 	const tempForm = uni.getStorageSync('enterData') || ''
		// 	const tempStrData = uni.getStorageSync('enterStrData') || ''
		// 	if (tempForm) {
		// 		this.form = Object.assign(this.form, tempForm)
		// 		this.categoryStr = tempStrData.categoryStr
		// 		this.levelStr = tempStrData.levelStr
		// 		this.typeStr = tempStrData.typeStr
		// 		this.styleStr = tempStrData.styleStr
		// 	}
		// 	const tempAddress = uni.getStorageSync('address') || ''
		// 	if (tempAddress) {
		// 		this.form.longitude = tempAddress.longitude
		// 		this.longitude = tempAddress.longitude
		// 		this.form.latitude = tempAddress.latitude
		// 		this.latitude = tempAddress.latitude
		// 		this.addressStr = tempAddress.address
		// 	}
		// },
		// onHide() {
		// 	const temp = {
		// 		categoryStr: this.categoryStr,
		// 		levelStr: this.levelStr,
		// 		typeStr: this.typeStr,
		// 		styleStr: this.styleStr
		// 	}
		// 	console.log(this.form, 'hide')
		// 	uni.setStorageSync('enterStrData', temp)
		// 	uni.setStorageSync('enterData', this.form)
		// },
		// onUnload() {
		// 	uni.removeStorageSync('enterStrData')
		// 	uni.removeStorageSync('enterData')
		// 	uni.removeStorageSync('address')
		// },
		methods: {
			// 选择分类
			handleSelectCate(value) {
				console.log(value)
				this.form.category = value[value.length - 1].value
				this.categoryStr = value.map(e => e.label).join('/')
				// const temp = ['竞赛及计算机','大学分类课程','考研考证考公','出生成长生活']

			},
			// 选择年级
			handleSelectGrade(value) {
				this.form.level = value[0].value
				this.levelStr = value[0].label
			},

			// 选择类型
			handleSelectType(value) {
				this.form.type = value[0].value
				this.typeStr = value[0].label
			},
			// 获取字典数据
			getData(params) {
				return new Promise((resolve, reject) => {
					this.ajax({
						url: '/const/listData',
						data: params
					}).then(res => {
						resolve(res)
					})
				})
			},
			// 删除空的children
			delChildren(temp) {
				temp.forEach(e => {
					if (e && e.children && e.children.length !== 0) {
						this.delChildren(e.children)
					}
					if (e.children.length === 0) {
						delete e.children
					}
				})
				return temp
			},
			// 获取服务分类列表数据
			getCategroyList() {
				const params = {
					type: 1
				}
				this.getData(params).then(res => {
					this.categoryList = this.delChildren(res.data)
					this.categoryList.forEach(e => {

						if (!e.children) {
							e.children = []
						}
					})
					const index = this.categoryList.findIndex(e => e.code === this.defaultCode)
					if (index === -1) return
					this.cateDefault = [index, 0]
					const temp = this.categoryList[index]
					console.log(temp, 'temp')
					try {
						this.isShowSelectCate = true
						this.categoryStr =
							`${temp && temp.name}/${temp.children.length !== 0 ? temp.children[0].name : ''}`
						this.form.category = temp && temp.children.length !== 0 ? temp.children[0].code : ''
					} catch (e) {
						console.log(e)
					}

				})
			},

			// 获取年级
			getGradeList() {
				const params = {
					type: 5
				}
				this.getData(params).then(res => {
					console.log(res)
					this.GradeList = this.delChildren(res.data)
				})
			},

			// 获取类型
			getTypeList() {
				const params = {
					type: 4
				}

				this.getData(params).then(res => {
					this.typeList = this.delChildren(res.data)
				})

			},

			// 图片上传成功后
			handleSuccessIconPath(data, index, lists, name) {
				console.log(data, index, lists, name)
				// const temp = getApp().globalData.baseUrl + 'attach/download/'
				this.form.iconPath = data.data.code
			},
			// 移除图片
			handleRemoveIconPath(index, lists, name) {
				this.form.iconPath = ''
			},
			handleSelectStyle(v) {
				this.form.style = v[0].value
				this.styleList = v[0].label
			},
			handleSelectProvide(v) {
				this.form.provide = v[0].label
				this.provideStr = v[0].label
			},
			// 获取区域
			getAreaList() {
				this.ajax({
					url: '/area/listData',
					data: {
						parent: 0
					}
				}).then(res => {
					this.provideList = res.data
				})
			},

			// 提交
			handleSubmit() {
				this.$refs.formRef.validate(valid => {
					if (!valid) return
					this.loading = true

					this.ajax({
						url: '/lesson/update',
						data: {
							...this.form,
							code: this.code
						}
					}).then(res => {
						console.log(res)
						this.loading = false
						uni.showToast({
							icon: 'none',
							title: '发布课程成功'
						})
						uni.navigateBack();

					}).catch(() => {
						this.loading = false
					})
				})
			},
			// 查询课程
			getLesson(code) {
				this.ajax({
					url: '/lesson/findData',
					data: {
						code
					}
				}).then(res => {
					console.log(res)
					const {
						keyword,
						price,
						category,
						categoryStr,
						type,
						typeStr,
						content,
						iconPath,
						code,
						level,
						levelStr,
						provide,
						latitude,
						longitude,
						address
					} = res.data
					this.form = {
						...this.form,
						keyword,
						price,
						category,
						type,
						content,
						iconPath,
						level,
						provide,
						longitude,
						latitude
					}
					this.latitude = latitude
					this.longitude = longitude
					this.addressStr = address
					this.categoryStr = categoryStr
					this.levelStr = levelStr
					this.typeStr = typeStr
					this.iconPathList = [{
						url: this.imgPath + iconPath
					}]
					this.code = code
				})
			},
			// getLocation() {
			// 	uni.getLocation({
			// 		type: 'gcj02',
			// 		success: (e) => {
			// 			this.latitude = e.latitude,
			// 				this.longitude = e.longitude
			// 		}
			// 	})
			// },

			// handleClickAddress() {
			// 	const _this = this
			// 	uni.chooseLocation({
			// 		latitude: this.latitude,
			// 		longitude: this.longitude,
			// 		success: (res) => {
			// 			console.log('位置名称：' + res.name);
			// 			console.log('详细地址：' + res.address);
			// 			console.log('纬度：' + res.latitude);
			// 			console.log('经度：' + res.longitude);
			// 			_this.form.latitude = res.latitude
			// 			_this.form.longitude = res.longitude
			// 			_this.addressStr = res.address
			// 		}
			// 	});
			// }

			handleClickAddress() {
				// uni.navigateTo({
				// 	url: '../../common/map'
				// })
				this.isShowPop = true
			},
			
			saveAddress(data) {
				console.log(data,'p')
				this.form.longitude = data.longitude
				this.form.latitude = data.latitude
				this.longitude = data.longitude
				this.latitude = data.latitude
				this.addressStr = data.address
				this.isShowPop = false
			}
		}
	}
</script>

<style lang="scss" scoped>
	.lesson {
		padding: 0 30rpx;
		padding-bottom: 108rpx;
	}

	.fixed-btn {
		padding-top: 10rpx;
		// bottom: 120rpx;
		left: 10rpx;
		right: 10rpx;
		background-color: #fff;
	}
</style>
