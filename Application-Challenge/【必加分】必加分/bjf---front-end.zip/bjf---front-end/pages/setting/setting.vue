<template>
	<view>
		<view>
			<u-cell-group>
				<navigator url="/pages/profile/profile">
					<u-cell-item icon="account" title="我的资料"></u-cell-item>
				</navigator>
				<u-cell-item icon="photo" title="联系我们"></u-cell-item>
				<u-cell-item icon="photo" title="清除缓存"></u-cell-item>
			</u-cell-group>
			<u-cell-group class="u-m-t-20">
				<navigator url="/pages/agreement/agreement">
					<u-cell-item icon="coupon" title="用户协议"></u-cell-item>
				</navigator>
				<u-cell-item icon="zhuanfa" title="退出登录" @click="showModal('logout')"></u-cell-item>
			</u-cell-group>
		</view>
		<u-modal v-model="modal" :show-cancel-button="true" :content="modalContent" @confirm="modalConfirm"></u-modal>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				modal: false,
				modalContent: "",
				modalType: null,
				userData: null
			}
		},
		mounted() {
			this.userData = this.user();
		},
		methods: {
			showModal(type) {
				this.modal = true;
				this.modalType = type;
				switch (type) {
					case "logout":
						this.modalContent = "确认要退出吗？";
						break;
				}
			},
			modalConfirm() {
				this.modal = false;
				switch (this.modalType) {
					case "logout":
						uni.clearStorageSync();
						uni.reLaunch({
							url: "/pages/login/login"
						});
						break;
				}
			}
		}
	}
</script>

<style>
	page {
		background-color: #ededed;
	}
</style>
