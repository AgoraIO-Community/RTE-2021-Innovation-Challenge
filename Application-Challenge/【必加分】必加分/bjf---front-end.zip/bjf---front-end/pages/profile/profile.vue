<template>
	<view class="u-p-30">
		<u-form :model="formData" :rules="rules" ref="uForm" :errorType="['toast','border-bottom']">
			<u-form-item label="您的名称" label-width="150" prop="name" required>
				<u-input placeholder="请输入名称" type="text" v-model="formData.name"></u-input>
			</u-form-item>
			<u-form-item label="您的性别" label-width="150" prop="sexStr" required>
				<u-input placeholder="请选择性别" type="select" v-model="formData.sexStr" @click="sexFlag=true"></u-input>
				<u-select v-model="sexFlag" :list="sexList" @confirm="sexChoose"></u-select>
			</u-form-item>
			<u-form-item label="您的生日" label-width="150" prop="birthday" required>
				<u-input placeholder="请选择生日" type="select" v-model="formData.birthday" @click="birthdayFlag=true">
				</u-input>
				<u-picker v-model="birthdayFlag" mode="time" @confirm="birthdayChoose"></u-picker>
			</u-form-item>
			<u-form-item label="所在地区" label-width="150" prop="place">
				<u-input placeholder="请选择地区" type="select" v-model="formData.place" @click="placeFlag=true"></u-input>
				<u-picker v-model="placeFlag" mode="region" @confirm="placeChoose"></u-picker>
			</u-form-item>
			<u-form-item label="自我介绍" label-position="top" prop="summary">
				<u-input type="textarea" placeholder="请输入简介" v-model="formData.summary"></u-input>
			</u-form-item>
			<u-form-item label-position="top" label="头像">
				<u-upload ref="uUpload" max-count="1" width="160" height="160" :action="upLoadAction" :fileList="upLoadFileList"
				 :show-progress="false" @on-remove="fileRemove">
				</u-upload>
			</u-form-item>
		</u-form>
		<u-button type="success" @click="submit" style="margin-top: 30rpx;" :loading="loading">保存</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				loading: false,
				upLoadAction: "",
				upLoadFileList: [],
				sexFlag: false,
				sexList: [{
					value: 0,
					label: "女"
				}, {
					value: 1,
					label: "男"
				}],
				birthdayFlag: false,
				placeFlag: false,
				formData: {},
				rules: {
					name: [{
						required: true,
						message: "请输入名称",
						trigger: ["blur", "change"]
					}],
					sexStr: [{
						required: true,
						message: "请选择性别",
						trigger: ["blur", "change"]
					}],
					birthday: [{
						required: true,
						message: "请选择生日",
						trigger: ["blur", "change"]
					}]
				}
			}
		},
		onReady() {
			this.$refs.uForm.setRules(this.rules);
			this.formData = {
				...this.formData,
				...this.user()
			};
			if (null == this.formData.sex)
				this.formData.sex = this.formData.sexStr = "";
			else
				this.formData.sexStr = this.formData.sex == 0 ? "女" : "男";
			if (null == this.formData.birthday)
				this.formData.birthday = "";
			if (null == this.formData.place)
				this.formData.place = "";
			if (null != this.formData.iconPath)
				this.upLoadFileList.push({
					url: getApp().globalData.baseUrl + "/attach/download/" + this.formData.iconPath
				});
			this.upLoadAction = getApp().globalData.baseUrl + "/attach/upload";
		},
		methods: {
			fileRemove() {
				this.formData.iconPath = "";
			},
			sexChoose(e) {
				this.formData.sex = e[0].value;
				this.formData.sexStr = e[0].label;
			},
			birthdayChoose(e) {
				let birthday = e.year + "-" + e.month + "-" + e.day;
				this.formData.birthday = birthday;
			},
			placeChoose(e) {
				let place = e.province.label + "-" + e.city.label + "-" + e.area.label;
				this.formData.place = place;
			},
			submit() {
				this.$refs.uUpload.lists.forEach(i => {
					if (null != i.response)
						this.formData.iconPath = i.response.data.code;
				});
				this.$refs.uForm.validate(valid => {
					if (valid) {
						this.ajax({
							url: "user/update",
							data: this.formData
						}).then(res => {
							uni.setStorageSync("user", JSON.stringify(this.formData));
							uni.navigateBack();
						});
					}
				});
			}
		}
	}
</script>

<style>
</style>
