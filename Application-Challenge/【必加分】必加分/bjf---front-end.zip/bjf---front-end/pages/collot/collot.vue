<template>
	<view>
		<view class="top">
			<view class="list" :class="checkIndex==index ?'listCheck':''" v-for="(item,index) in list" :key="index" @tap="check(index)">
				{{item}}
			</view>
		</view>
		<view style="background: #F3F3F3;height: 20rpx;"></view>
		<view class="content">
			<view v-if="checkIndex==0">
				<view class="wrap" @tap="navTo(item)" v-for="(item,index) in lists" :key="index">
					<image :src="item.teacher_.iconPath || '/static/1.png'" mode="aspectFill" class="imgs"></image>
					<view class="right">
						<view class="title" style="text-align: left;">{{item.teacher_.name}}</view>
						<view class="title" style="text-align: left;">{{item.teacher_.summary}}</view>
						<view class="bto">
							<view class="nums">{{item.teacher_.educationStr}}</view>
						</view>
					</view>
				</view>
			</view>
			<block v-if="checkIndex==1">
				<view class="wrap" @tap="navTos(item)" v-for="(item,index) in list1" :key="index">
					<image :src="url+item.lesson_.iconPath" mode="aspectFill" class="imgs"></image>
					<view class="right">
						<view class="title" style="text-align: left;">{{item.lesson_.content}}</view>
						<view class="bto">
							<view class="price">￥{{item.lesson_.price}}</view>
							<view class="nums">已售{{item.lesson_.sell}}件</view>
						</view>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list:['老师','课程'],
				checkIndex:0,
				url:'',
				lists:[],
				list1:[]
			}
		},
		onLoad() {
			this.url=getApp().globalData.imgPath;
			this.getinfo()
		},
		methods: {
			check(e){
				this.checkIndex=e;
				this.getinfo();
			},
			getinfo(){
				const params = {
					type:this.checkIndex,
					user:JSON.parse(uni.getStorageSync('user')).code
				}
				this.ajax({
					url: '/collect/pageData',
					data: params
				}).then(res => {
					console.log(res)
					if(this.checkIndex==0){
						this.lists=res.data.records
						console.log(this.lists)
					}else{
						this.list1=res.data.records
					}
				})
			},
			navTos(e){
				uni.navigateTo({
					url:"/pages/parent/info/info?id="+e.id+'&code='+e.code
				})
			}
		}
	}
</script>

<style scoped lang="scss">
	.top{
		height: 90rpx;
		line-height: 90rpx;
		display: flex;
		flex-wrap: nowrap;
		width: 100%;
		box-sizing: border-box;
		padding: 0 15%;
		.list{
			flex: 1;
			text-align: center;
			font-size: 28rpx;
			color: #666;
			letter-spacing: 5rpx;
		}
		.listCheck{
			font-size: 32rpx;
			color: #333;
			font-weight: bold;
		}
	}
	.content{
		.wrap{
			box-sizing: border-box;
			padding: 20rpx;
			border-bottom: 1rpx solid #eee;
			display: flex;
			flex-wrap: nowrap;
			.imgs{
				width: 200rpx;
				height: 200rpx;
				border-radius: 10rpx;
				display: block;
			}
			.right{
				flex: 1;
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				padding-left: 20rpx;
				.title{
					font-size: 28rpx;
					color: #333;
					font-weight: bold;
					letter-spacing: 3rpx;
					line-height: 40rpx;
					padding: 20rpx 0;
				}
				.bto{
					display: flex;
					flex-wrap: nowrap;
					align-items: center;
					justify-content: space-between;
					line-height: 50rpx;
					.price{
						font-size: 30rpx;
						color: red;
						font-weight: bold;
						line-height: 50rpx;
					}
					.nums{
						font-size: 25rpx;
						color: #888;
						text-align: right;
						line-height: 50rpx;
					}	
				}
			}
		}
		
	}
</style>
