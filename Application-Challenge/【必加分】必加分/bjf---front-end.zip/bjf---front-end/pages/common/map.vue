<template>
	<view class="map">
		<view class="map-content">

			<map style="width: 750rpx; height: 500rpx;" :latitude="latitude" :longitude="longitude" id="myMap"
				:markers="markers" show-location  @tap.prevent="mapTap" show-location @poitap="poitap"></map>
		</view>

		<!-- 搜索输入框 -->
		<view class="input-box">
			<u-input v-model.trim="keywords" clearable @input="handleInput"></u-input>
		</view>

		<!-- 搜索结果 -->
		<scroll-view scroll-y="true" class="scroll-view" v-if="resultLIst.length !== 0">
			<u-cell-group>
				<u-cell-item v-for="(v,i) in resultLIst" :keys="i" :title="`${v.cityname} ${v.address}`" :arrow="true" @click="handleClickCell(v)"></u-cell-item>
			</u-cell-group>
		</scroll-view>
		
		<view class="empty-box" v-else>
			<u-empty :text="emptyTxt" mode="list" ></u-empty>
		</view>
		
		<!-- 确定 -->
		<view class="submit-btn safe-area-inset-bottom">
			<view class="btn-box">
				<u-button type="success" @click="hanldeSubmit">确定</u-button>
			</view>
		</view>
	</view>
</template>

<script>
	let mapCtx
	import {
		mapAPI,
		mapKeyWord
	} from '../../api/map.js'
	export default {
		data() {
			return {
				latitude: 39.909,
				longitude: 116.39742,
				markers: [{
					id: 1,
					latitude: 39.909,
					longitude: 116.39742,
					iconPath: '../../static/icon.png'
				}],
				keywords: '',
				inputTimer: null,
				resultLIst: []
			}
		},
		onShow() {

		},
		onLoad() {
			mapCtx = uni.createMapContext('myMap')
			this.getLocal() 
		},
		computed: {
			emptyTxt() {
				if(this.resultLIst.length === 0 && this.keywords) {
					return '没有匹配地点'
				}
				return '请输入关键词搜索'
			}
		},
		methods: {
			getLocal() {
				uni.getLocation({
					type: 'gcj02',
					success:(e)=> {
						// console.log(e, '123')
						this.longitude = e.longitude
						this.latitude = e.latitude
						const params = {
							longitude: e.longitude,
							latitude: e.latitude
						}
						this.toLocation(params)
					},

				})
			},

			toLocation(obj) {
				console.log(obj, 'tolocal')
				
				// 改变地图中心位置
				mapCtx.moveToLocation(obj)
				if(!obj.longitude) return
				// 移动标记点并添加动画效果
				mapCtx.translateMarker({
					markerId: 1,
					duration: 100,
					destination: {
						latitude: obj.latitude.toFixed(2),
						longitude: obj.longitude.toFixed(2),
					},
				})
			},

			mapTap(e) {
				console.log(e)
				console.log(e.detail, 'maptap')
				this.toLocation(e.detail)
				this.latitude = e.detail.latitude
				this.longitude = e.detail.longitude
				
			},
			
			poitap(e) {
				console.log(e, 'poitap')
			},

			handleInput() {
				if (!this.keywords) return
				clearTimeout(this.inputTimer)
				this.inputTimer = setTimeout(() => {
					mapKeyWord(this.keywords).then(res => {
						console.log(res)
						res.data.pois.forEach(e => {
							e.temp = e.cityName + e.address
						})
						this.resultLIst = res.data.pois
					})
				}, 1000)
			},
			
			handleClickCell(e) {
				console.log(e)
				const temp = e.location.split(',').reverse()
				const poi = {
					latitude: parseFloat(temp[0]),
					longitude: parseFloat(temp[1])
				}
				this.keywords = e.cityname + e.address
				this.latitude = parseFloat(temp[0])
				this.longitude = parseFloat(temp[1])
				this.toLocation(poi)
			},
			
			hanldeSubmit() {
				const ad = [this.longitude, this.latitude]
				console.log(ad)
				const temp = ad.map(e => e.toFixed(3))
				mapAPI(temp.join(',')).then(res => {
					console.log(res.data.regeocode)
					const params = {
						longitude: this.longitude,
						latitude: this.latitude,
						address: res.data.regeocode.formatted_address
					}
					uni.setStorageSync('address', params)
					setTimeout(() => {
						uni.navigateBack()
					})
				})
			}

		}
	}
</script>

<style lang="scss" scoped>
	.map {
		overflow: hidden;
		width: 100vw;
		height: 100vh;
	}
	
	.map-content {
		position: fixed;
		top: 0;
	}

	.input-box {
		margin: 520rpx auto 10rpx;
		padding: 0 20rpx;
		width: 700rpx;
		border: 2rpx solid #e6e6e6;
		border-radius: 20rpx;
	}
	
	.scroll-view,
	.empty-box{
		height: calc(100vh - 700rpx);
	}
	
	.submit-btn {
		position: relative;
		margin-bottom: 20rpx;
		width: 100%;
		height: 100rpx;
		line-height: 100rpx;
		.btn-box {
			position: absolute;
			top: 0;
			bottom: 0;
			left: 0;
			right: 0;
			text-align: center;
			line-height: inherit;
		}
	}
</style>
