<template>
	<view class="content">
		<view class="tc" >
			<image src="../../../static/logo.png"></image>
			<view class="txt">
				<view class="h">编程-java基础</view>
				<view class="p">
					<text>￥1000</text>
					<text>距离33.33km</text>
					<text>王老师</text>
				</view>
			</view>
		</view>
		<view class="space"></view>
		<view class="pt">
			<text>上课地址</text>
			<text >长沙徐汇区三西路888号</text>
		</view>
		<view class="pt">
			<text>上课时间</text>
			<text>2021-12-21 12:12:21</text>
		</view>
		<view class="pt">
			<text>订单号</text>
			<text>4324234242424</text>
		</view>
		<view class="pt">
			<text>订单生成时间</text>
			<text>2021-12-21 12:12:21</text>
		</view>
		<view class="space"></view>
		<view class="pt">
			<text>老师性格</text>
			<u-rate v-model="value" size="36" :colors="colors" :icons="icons" inactive-icon="thumb-up"></u-rate>
		</view>
		<view class="pt">
			<text>教学质量</text>
			<u-rate v-model="value" size="36" :colors="colors" :icons="icons" inactive-icon="thumb-up"></u-rate>
		</view>
		<view class="pt">
			<text>老师是否准时</text>
			<u-rate v-model="value" size="36" :colors="colors" :icons="icons" inactive-icon="thumb-up"></u-rate>
		</view>
		<view class="pt">
			<text>评价</text>
			<text>评价</text>
		</view>
		

	</view>
</template>

<script>
	export default {
		data() {
			return {
				icons: ['thumb-down-fill', 'thumb-down-fill', 'thumb-up-fill', 'thumb-up-fill'],
				value:0,
				colors: ['#ffc454', '#ffb409', '#ff9500'],
			}
		},
		methods:{
			
		}
		
	}
</script>
<style>
	.tc image{float: left; width: 100rpx; height:100rpx; margin-right: 20rpx;}
	.tc .txt{ float: left; width: calc(100% - 100px);}
	.tc .txt .h{font-size: 28rpx;}
	.tc .txt .p{font-size: 24rpx; display: flex; justify-content: space-between; margin-top: 20rpx; color: #999;}
	.tc{clear: both; overflow: hidden; padding: 12px; border-bottom: 1px solid #f9f9f9;}
	.space{height: 8rpx; background-color: #f1f1f1;}

	.pt{display: flex; justify-content: space-between; font-size: 24rpx; padding: 28rpx 3%; border-bottom: 1rpx solid #f1f1f1; color: #999;}
	.c{color: #19BE6B;}
	.b{color: #999;}
</style>
