<template>
	<view class="content">
		
		<view class="pack">
			<view class="t">
				<view class="p">
					请选择退款比例
				</view>
				<view class="n">
					<view class="btn">
						10%
					</view>
					<view class="btn">
						20%
					</view>
					<view class="btn">
						30%
					</view>
					<view class="btn">
						40%
					</view>
				</view>
			</view>
		</view>
		<view class="space"></view>
		<view class="pack">
			<view class="t">
				<view class="p">
					注意事项
				</view>
				<view class="tn">
					申请退款后，老师接到通知后，与您协商具体金额
				</view>
			</view>
		</view>
		
		<view class="fixbtn">
			<u-button type="success" >确认退款</u-button>
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods:{
			
		}
		
	}
</script>
<style>
	.space{height: 16rpx; background-color: #f1f1f1;}
	.pack{ background-color: white;  border-radius: 10rpx; padding: 20rpx 3%; }
	.pack .t .p{font-size: 28rpx; padding-left: 20rpx; border-left:4rpx solid #18B566}
	.pack .t .e{font-size: 40rpx; color: #18B566; margin-top:18rpx;}
	.pack .t{position: relative;}
	.pack button{position: absolute; right: 0px; top: 26rpx;}
	.pack .n .btn{float: left; width: 45%; margin: 0 2.5%; margin-bottom: 20rpx; border-radius: 8rpx; border:1rpx solid #999; text-align: center; padding: 20rpx 0px; font-size: 30rpx;}
	.pack .n .btn .u-icon{margin-right: 10rpx;}
	.pack .n{clear: both; overflow: hidden; margin-top: 28rpx;}
	.pack .tn{font-size: 26rpx; line-height: 1.5; margin-top: 18rpx;}
	.fixbtn{position: fixed; bottom: 0; left: 0; width: 100%; border-radius: 0; padding: 20rpx 3%; border-top: 1px solid #f1f1f1;}
	.content{padding-bottom: 44px;}
</style>
