<template>
	<view class="u-p-30">
		<u-form :model="formData" :rules="rules" ref="uForm" :errorType="['toast','border-bottom']">
			<u-form-item label="老师性格"  prop="name" label-width="200"  label-position="left">
				<u-rate v-model="value" size="48" :colors="colors" :icons="icons" inactive-icon="thumb-up"></u-rate>
			</u-form-item>
			<u-form-item label="教学质量"  prop="position"  label-width="200" label-position="left">
				<u-rate v-model="value" size="48" :colors="colors" :icons="icons" inactive-icon="thumb-up"></u-rate>
			</u-form-item>
			<u-form-item label="老师是否准时" prop="phone" label-width="200"  label-position="left">
				<u-rate v-model="value" size="48" :colors="colors" :icons="icons" inactive-icon="thumb-up"></u-rate>
			</u-form-item>
			<u-form-item label="评价" prop="intro" label-width="200"  label-position="left">
				<u-input v-model="formData.intro"/>
			</u-form-item>
			
		</u-form>
		<u-button type="success" @click="submit" style="margin-top: 30rpx;" :loading="loading">保存</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				loading: false,
				formData: {},
				icons: ['thumb-down-fill', 'thumb-down-fill', 'thumb-up-fill', 'thumb-up-fill'],
				value:0,
				colors: ['#ffc454', '#ffb409', '#ff9500'],
				rules: {
					intro: [
						{
							min: 5, 
							message: '说说的的学习感受吧！！！', 
							trigger: 'change'
						}
					]
					
				}
			}
		},
		onReady() {
			this.$refs.uForm.setRules(this.rules);
			this.formData = {
				...this.formData
			};
			
		},
		methods: {
			
			submit() {
				this.$refs.uUpload.lists.forEach(i => {
					if (null != i.response)
						this.formData.iconPath = i.response.data.code;
				});
				console.log(this.formData)
				this.$refs.uForm.validate(valid => {
					if (valid) {
						this.ajax({
							url: "user/update",
							data: this.formData
						}).then(res => {
							uni.setStorageSync("user", JSON.stringify(this.formData));
							uni.navigateBack();
						});
					}
				});
			}
		}
	}
</script>

<style>
</style>
