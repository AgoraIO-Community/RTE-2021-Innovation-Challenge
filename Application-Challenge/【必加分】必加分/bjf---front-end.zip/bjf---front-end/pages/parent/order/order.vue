<template>
	<view class="order">
		<u-gap height="10" bg-color="#eee"></u-gap>
		<!-- 我购买的订单，发布需求订单 -->
		<view class="cell-box">
			<view class="cell-item" >
				<view class="cell-header">
					<view class="cell-title">
						<!-- {{item.name}}	 -->
						课程订单
					</view>
					<view class="cell-right" @click="$common.jumpurl('/pages/parent/demand/index?status=0')">
						全部
					</view>
					
				</view>
				<view class="cell-content">
					<view class="cell-grid"  @click="$common.jumpurl('/pages/parent/order/index?status=0')">
						<u-icon name="list" size="40"></u-icon>
						<text>全部</text>
					</view>
					<view class="cell-grid"  @click="$common.jumpurl('/pages/parent/order/index?status=1')">
						<u-icon name="red-packet" size="40"></u-icon>
						<text>待付款</text>
					</view>
					<view class="cell-grid"  @click="$common.jumpurl('/pages/parent/order/index?status=2')">
						<u-icon name="edit-pen" size="40"></u-icon>
						<text>待上课</text>
					</view>
					
					<view class="cell-grid"  @click="$common.jumpurl('/pages/parent/order/index?status=4')">
						<u-icon name="bag" size="40"></u-icon>
						<text>待完成</text>
					</view>
					<view class="cell-grid"  @click="$common.jumpurl('/pages/parent/order/index?status=3')">
						<u-icon name="heart" size="40"></u-icon>
						<text>待评价</text>
					</view>
				</view>
			</view>
			<view class="cell-item" >
				<view class="cell-header">
					<view class="cell-title">
						需求订单	
					</view>
					<view class="cell-right" @click="$common.jumpurl('/pages/parent/demand/index?status=0')">
						全部
					</view>
				</view>
				<view class="cell-content">
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=0')">
						<u-icon name="list" size="40"></u-icon>
						<u-badge size="mini" type="success" :count="allNum"></u-badge>
						<text>全部</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=1')">
						<u-icon name="calendar" size="40"></u-icon>
						<u-badge size="mini" type="success" :count="demandNum[1]"></u-badge>
						<text>待接单</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=2')">
						<u-icon name="edit-pen" size="40"></u-icon>
						<u-badge size="mini" type="success" :count="demandNum[2]"></u-badge>
						<text>待上课</text>
					</view>
					
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=4')">
						<u-icon name="bag" size="40"></u-icon>
						<u-badge size="mini" type="success" :count="demandNum[4]"></u-badge>
						<text>待完成</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=6')">
						<u-icon name="heart" size="40"></u-icon>
						<u-badge size="mini" type="success" :count="demandNum[6]"></u-badge>
						<text>待评价</text>
					</view>
				</view>
			</view>
			<view class="cell-item" >
				<view class="cell-header">
					<view class="cell-title">
						商品服务	
					</view>
					<view class="cell-right" @click="$common.jumpurl('/pages/parent/demand/index?status=0')">
						全部
					</view>
				</view>
				<view class="cell-content">
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=0')">
						<u-icon name="list" size="40"></u-icon>
						<text>全部</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=1')">
						<u-icon name="red-packet" size="40"></u-icon>
						<text>待付款</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=2')">
						<u-icon name="map" size="40"></u-icon>
						<text>待发货</text>
					</view>
					
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=4')">
						<u-icon name="fingerprint" size="40"></u-icon>
						<text>待收货</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=3')">
						<u-icon name="heart" size="40"></u-icon>
						<text>待评价</text>
					</view>
				</view>
			</view>
			<view class="cell-item" >
				<view class="cell-header">
					<view class="cell-title">
						电子订单	
					</view>
					<view class="cell-right" @click="$common.jumpurl('/pages/parent/demand/index?status=0')">
						全部
					</view>
				</view>
				<view class="cell-content">
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=0')">
						<u-icon name="list" size="40"></u-icon>
						<text>全部</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=1')">
						<u-icon name="red-packet" size="40"></u-icon>
						<text>待付款</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=2')">
						<u-icon name="clock" size="40"></u-icon>
						<text>待下载</text>
					</view>
					
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=4')">
						<u-icon name="download" size="40"></u-icon>
						<text>已下载</text>
					</view>
					<view class="cell-grid" @click="$common.jumpurl('/pages/parent/demand/index?status=3')">
						<u-icon name="heart" size="40"></u-icon>
						<text>待评价</text>
					</view>
				</view>
			</view>
		</view>
		
		<!-- <u-cell-group>
				<u-cell-item title="个人设置" v-for="(v,i) in 7" :key="i"></u-cell-item>
		</u-cell-group> -->
		
		<!-- 发布需求 -->
		<u-gap height="15" bg-color="#eee"></u-gap>
		<!-- <u-cell-group >
				<u-cell-item title="发布需求" @click="$common.jumpurl('/pages/parent/submitDemand/index')"></u-cell-item>
		</u-cell-group> -->
		<view class="fixed-btn">
			<u-button type="success" @click="$common.jumpurl('/pages/parent/submitDemand/index')">发布需求</u-button>
		</view>
		
		<!-- <u-back-top :scroll-top="scrollTop"></u-back-top> -->
		<u-tabbar :list="list" :mid-button="false" active-color="#00c65d"></u-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: getApp().globalData.parent,
				tabList: [],
				demandNum:{
					0:0,
					1:0,
					2:0,
					4:0,
					6:0,
					7:0
				},
				allNum:0
			}
		},
		onShow() {
			this.demandNum={
					0:0,
					1:0,
					2:0,
					4:0,
					6:0,
					7:0
				}
				this.allNum =0
			this.getOrder()
		},
		methods: {
			getOrder(){
				var _self = this
				var userData = this.user();
				this.ajax({
					url: "/demand/listData",
					data:{
						'user':userData.code
					}
				}).then(res => {
					var data = res.data
					for(var i in data){
						var state = data[i].state
						_self.demandNum[state] ++
					}
					_self.allNum += data.length
					console.log(_self.demandNum)
					
				});
			}
			
		}
	}
</script>

<style lang="scss" scoped>
	.icon-image {
		width: 50rpx;
		height: 50rpx;
	}
	
	.cell-box {
		padding-bottom: 105rpx;
		background-color: #eee;
		
	}
	.fixed-btn {
		bottom: 90rpx;
		background-color: #FFFFFF;
		border-top: unset;
	}
	.cell-item {
		&:nth-child(n+1) {
			margin-top: 15rpx;
		}
		background-color: #fff;
		.cell-header {
			display: flex;
			justify-content: space-between;
			padding: 20rpx;
			height: 80rpx;
			border-bottom: 2rpx solid #f2f3f4;
			font-size: 26rpx;
			
			.cell-right {
				color: #888;
				&::after {
					content: '';
					display: inline-block;
					width: 16rpx;
					height: 16rpx;
					border-top: 2rpx solid #888;
					border-right: 2rpx solid #888;
					transform: rotate(45deg);
				}
			}
		}
	
		.cell-content {
			display: flex;
			justify-content: space-around;
			height: 180rpx;
			background-color: #fff;
			
			.cell-grid {
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				font-size: 30rpx;
			}
		}
	}
	.cell-grid{position: relative;}
	.cell-grid .u-badge{position: absolute; right:0px!important; top:20px!important}
</style>
