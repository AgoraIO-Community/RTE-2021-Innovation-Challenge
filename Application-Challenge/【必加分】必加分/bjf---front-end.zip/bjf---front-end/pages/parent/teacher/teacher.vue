<template>
	<view class="teacher">
		<!-- <text>家长-优选老师</text> -->

		<view class="search">
			<u-search placeholder="输入老师编号或院校名称查找老师" v-model="keyword" :action-style="actionStyle" @search="search"></u-search>
		</view>

		<!-- 轮播图区域 -->
		<view class="swiper">
			<u-swiper :list="swiperList" height="360"></u-swiper>
		</view>

		<!-- 宫格区域 -->
		<view class="grid">
			<u-grid :col="4" :border="false">
				<u-grid-item v-for="(v,i) in gridList.filter(e => e.grid)" :key="i" @click="handlerClickGrid(v)">
					<u-icon :name="v.icon" :size="46"></u-icon>
					<view class="grid-text">{{v.name}}</view>
				</u-grid-item>
			</u-grid>
		</view>

		<!-- 公告 -->
		<view class="notice">
			<view class="notice-content">
				<view class="notice-icon">
					<u-icon name="volume-up-fill" size="40"></u-icon>
				</view>
				<view class="notice-text">
					服务至上，免费三年！保护隐私，强烈推荐服务至上，免费三年！保护隐私，强烈推荐服务至上，免费三年！保护隐私，强烈推荐
				</view>
				<view class="notice-btn-box">
					<view class="notice-btn">
						更多
					</view>
				</view>
			</view>
		</view>

		<!-- 搜索框 -->
		<u-sticky :enable="stickyEnable">

			<!-- 筛选 -->
			<view class="filter-box">
				
				
				<view class="filter-content">
					
					<view class="filter-item dropdown" @click="handleShowFilter('sort')">
						{{ sortStr || '默认排序'}}
					</view>
					
					
					<view class="">
							精选老师
					</view>
					<!-- <view class="filter-item dropdown" @click="handleShowFilter('level')">
						{{levelStr || '学生年级'}}
					</view> -->
					<!-- <view class="filter-item dropdown text-overflow" @click="handleShowFilter('sex')">
						{{sexStr || '教师性别'}}
					</view> -->
					<view class="filter-item dropdown" @click="isShowArea = true">
						{{nativePlaceStr || '教师籍贯'}}
					</view>
					
					<view class="filter-item dropdown" @click="handleShowFilter('education')">
						{{ educationStr || '院校经验'}}
					</view>
					<!-- <view class="filter-item dropdown text-overflow" @click="isShowLesson = true">
						{{categoryStr || '学科'}}
					</view> -->
					<view class="filter-item text-overflow" @click="isShowPopup = true">
						精准筛选
					</view>
				</view>

				<!-- 筛选列选择器 -->
				<u-select v-model="isShowFilter" :list="filterList" label-name="name" value-name="code" @confirm="handlerConfirm"></u-select>
				
				<!-- 学科筛选	 -->
				<u-select v-model="isShowLesson" mode="mutil-column-auto" :list="gridList" label-name="name" value-name="code" @confirm="handlerConfirmLesson"></u-select>
				
				<u-select v-model="isShowArea" :list="areaList" label-name="name" value-name="code" @confirm="handlerConfirmArea"></u-select>

				<!-- 精准筛选弹窗 -->
				<u-popup v-model="isShowPopup" mode="right" width="560" :safe-area-inset-bottom="true" @close="handlerClosePop">
					<view class="popup-content">
						<view class="popup-hd">
							<view class="popup-title">筛选</view>

							<view class="popup-item">
								<view class="popup-item-title">
									一级类目
								</view>
								<view class="popup-card">
									<view class="card-item" :class="{'card-item-active': i === tempIndex}" v-for="(v,i) in gridList" :key="i" @click="tempIndex = i">
										{{v.name}}
									</view>
									<!-- <view class="card-item" v-for="(v,i) in 7" :key="i">
										语文数学外语
									</view> -->
								</view>
							</view>
							
							<view class="popup-item">
								<view class="popup-item-title">
									二级类目
								</view>
								<view class="popup-card">
									<view class="card-item" :class="{'card-item-active': form.category === v.code}" @click="form.category = v.code" v-for="(v,i) in tempChildren" :key="i">
										{{v.name}}
									</view>
									<!-- <view class="card-item" v-for="(v,i) in 7" :key="i">
										语文数学外语
									</view> -->
								</view>
							</view>
							
							<view class="popup-item">
								<view class="popup-item-title">
									性别
								</view>
								<view class="popup-card">
									<view class="card-item" :class="{'card-item-active': form.sex === v.code}" @click="form.sex = v.code" v-for="(v,i) in sexlist" :key="i">
										{{v.name}}
									</view>
									<!-- <view class="card-item" v-for="(v,i) in 7" :key="i">
										语文数学外语
									</view> -->
								</view>
							</view>
							
						</view>
						<view class="popup-btn" @click="isShowPopup = false">
							关闭
						</view>
					</view>

				</u-popup>
			</view>

		</u-sticky>

		<!-- 老师列表数据 -->
		<view class="teacher-box">
			<view class="teacher-item" v-for="(v,i) in teacherList" :key="i" @click="handleToTeacher(v.code)">
				<view class="hd">
					<view class="hd-avatar">
						<u-image width="100%" height="170rpx" :src="v.iconPath"></u-image>
					</view>
					<view class="hd-express">
						<view class="hd-from">
							{{v.verify ? v.verify.scholl || '暂无' : '暂无' }}
						</view>
						<view class="hd-desc">
							<view class="hd-cate">
								{{v.tempCategory || '暂无'}}
							</view>
							<view class="hd-address">
								{{ v.distance ? `距离${v.distance}km` : '暂无'}}
							</view>
							
						</view>
						<view class="c-c" v-if="v.trainExperience">
							{{v.trainExperience}}年培训经验
						</view>
						<view class="c-c" v-if="v.school">
							毕业于{{v.school}}
						</view>
					</view>
				</view>
				<view class="bd">
					<u-icon name="map" size="40"></u-icon>
					<text>{{v.address || '暂无'}}</text>
				</view>
			</view>
		</view>

		<!-- <u-back-top :scroll-top="scrollTop"></u-back-top> -->
		<u-tabbar :list="list" :mid-button="false" active-color="#00c65d"></u-tabbar>
	</view>
</template>

<script>
	const BASICICON = '/static/'
	export default {
		data() {
			return {
				list: getApp().globalData.parent,
				// 轮播图列表
				swiperList: [{
					image: 'https://cdn.uviewui.com/uview/swiper/1.jpg',
					title: '昨夜星辰昨夜风，画楼西畔桂堂东'
				}],
				// 宫格列表
				gridList: [{
						icon: 'hourglass',
						name: '语文数学外语'
					},
					{
						icon: 'hourglass',
						name: '语文数学外语'
					},
					{
						icon: 'hourglass',
						name: '语文数学外语'
					},
					{
						icon: 'hourglass',
						name: '语文数学外语'
					},
					{
						icon: 'hourglass',
						name: '语文数学外语'
					},
					{
						icon: 'hourglass',
						name: '语文数学外语'
					},
					{
						icon: 'hourglass',
						name: '语文数学外语'
					},
					{
						icon: 'hourglass',
						name: '语文数学外语'
					},
				],
				// 搜索关键词
				keyword: '',
				form: {
					level: '',
					type: '',
					nativePlace: '',
					lesson: '',
					education: '',
					sex: '',
					category: '',
					sort: ''
				},
				// 搜索框右侧样式
				actionStyle: {
					width: '143rpx',
					height: '56rpx',
					lineHeight: '56rpx',
					border: '1rpx solid #fff',
					color: '#fff',
					borderRadius: '20rpx'
				},
				// 是否显示筛选列选择器
				isShowFilter: false,
				// 列选择器数据
				filterList: [],
				// 距离筛选数据
				distanceList: [{
					label: '距离优先'
				}, ],
				// 是否展示精选筛选弹窗
				isShowPopup: false,
				// 教师列表
				teacherList: [],
				// 当前页
				pageNum: 1,
				// 每页显示数量
				pageSize: 10,
				// 总条数
				total: 0,
				stickyEnable: false,
				selectType: '',
				typeList: [],
				levelList: [],
				areaList: [],
				levelStr: '',
				typeStr: '',
				nativePlaceStr: '',
				isShowLesson: false,
				lessonStr: '',
				educationStr: '',
				educationList: [],
				sexStr: '',
				isShowArea: false,
				categoryStr: '',
				sortStr: '',
				sortList:[
					{
						name:'默认排序',
						code: ''
					},
					{
						name: '距离最近',
						code: 'distance desc'
					},
					{
						name: '距离最远',
						code: 'distance asc'
					},
					{
						name: '价格最高',
						code: 'price desc'
					},
					{
						name: '价格最低',
						code: 'price asc'
					},
				],
				tempIndex: 0,
				sexlist: [
					{
						name: '不限',
						code:''
					},
					{
						name: '男',
						code: 1
					},{
						name: '女',
						code: 0
					}
				],
				
			}
		},
		computed: {
			tempChildren() {
				if(this.tempIndex !== '') {
					return this.gridList[this.tempIndex].children
				}
				return []
			}
		},
		mounted() {
			this.getCate()
			this.getTeacherList()
			this.getType()
			this.getLevelList()
			this.getAreaList()
			this.getEducationList()
		},
		onHide() {
			this.stickyEnable = false
		},
		onShow() {
			this.stickyEnable = true
		},
		onReachBottom() {
			// console.log(1)
			if(this.total === this.teacherList.length) {
				return uni.showToast({
					icon: 'none',
					title:'已经加载全部了'
				})
			}
			this.pageNum = ++this.pageNum
			this.getTeacherList()
		},
		methods: {
			// 展示筛选列选择器
			handleShowFilter(type) {
				console.log(type)
				if (type === 'education') {
					this.filterList = this.$u.deepClone(this.educationList)
				}
				if(type === 'level') {
					this.filterList = this.$u.deepClone(this.levelList)
				}
				
				if(type === 'type') {
					this.filterList = this.$u.deepClone(this.typeList)
				}
				
				if(type === 'nativePlace') {
					this.filterList = this.$u.deepClone(this.areaList)
				}
				
				if(type === 'sort') {
					this.filterList = this.$u.deepClone(this.sortList)
				}
				
				if(type === 'sex') {
					this.filterList = [
						{
							name: '男',
							code: 1
						},{
							name: '女',
							code: 0
						}
					]
				}
				this.selectType = type
				this.isShowFilter = true
			},
			// 获取字典数据
			getData(params) {
				return new Promise((resolve, reject) => {
					this.ajax({
						url: '/const/listData',
						data: params
					}).then(res => {
						resolve(res)
					})
				})
			},
			
			// 教学课程
			getType() {
				this.getData({
					type: 4
				}).then(res => {
					res.data.forEach(e => {
						e.value = e.code
						e.label = e.name
					})
					this.typeList = res.data
				})
			},
			
			getEducationList() {
				this.getData({type: 3}).then(res => {
					this.educationList = this.delChildren(res.data)
				})
			},
			
			// 年级
			getLevelList() {
				this.getData({type: 5}).then(res => {
					res.data.forEach(e => {
						e.value = e.code
						e.label = e.name
					})
					this.levelList = res.data
				})
			},
			
			// 区域
			getAreaList() {
				this.ajax({
					url: '/area/cityData',
					method: 'post',
					data:{}
				}).then(res => {
					this.areaList = this.delChildren(res.data)
				})
			},
			
			// 获取学科分类
			getCate() {
				const params = {
					type: 1
				}
				this.getData(params).then(res => {
					res.data.forEach(e => {
						e.icon = BASICICON + e.icon,
						e.grid = true
					})
					const params = {
						name: '不限',
						code: '',
						grid: false,
						children: [
							{
								name: '不限',
								code: ''
							}
						]
					}
					res.data.unshift(params)
					this.gridList = this.delChildren(res.data)
					
				})
			},
			
			// 删除空的children
			delChildren(temp) {
				temp.forEach(e => {
					if (e.children && e.children.length !== 0) {
						this.delChildren(e.children)
					}
					if (e.children && e.children.length === 0) {
						delete e.children
					}
				})
				return temp
			},
			
			handlerConfirm(v) {
				switch(this.selectType) {
					case 'sort': 
							this.form.order = v[0].value
							this.orderStr = v[0].label
							break;
					case 'level':
							this.form.level = v[0].value
							this.levelStr = v[0].label
							break;
					case 'type': 
							this.form.type =  v[0].value
							this.typeStr = v[0].label
							break;
					case 'nativePlace': 
							this.form.nativePlace = v[0].value
							this.nativePlaceStr = v[0].label
							break;
					case 'education': 
							this.form.education = v[0].value
							this.educationStr = v[0].label
							break;
					case 'sex':
							this.form.sex = v[0].value
							this.sexStr = v[0].label
							break;
				}
				this.teacherList = []
				this.getTeacherList()
			},
			
			handlerConfirmLesson(v) {
				this.teacherList = []
				this.form.category = v[1].value
				this.categoryStr = v[1].label
				this.getTeacherList()
			},
			
			// 获取老师列表
			getTeacherList() {
				const params = {
					pageNum: this.pageNum,
					pageSize: this.pageSize,
					...this.form,
					keyword: this.keyword
				}
				this.ajax({
					url: '/teacher/pageData',
					data: params
				}).then(res => {
					console.log(res)
					res.data.records.forEach(e => {
						e.tempCategory = e.categoryStr.split('-')[1] ? e.categoryStr.split('-')[1] : e.categoryStr.split('-')[0]
					})
					this.teacherList = this.teacherList.concat(res.data.records)
					this.total = res.data.total
				})
			},
			// 跳转教师详情
			handleToTeacher(code) {
				uni.navigateTo({
					url:`../teacherDetail/index?code=${code}`
				})
			},
			handlerClickGrid(v) {
				this.teacherList = []
				this.form.type = v.code
				this.typeStr = v.name
				this.getTeacherList()
			},
			search() {
				if(!this.keyword) return uni.showToast({
					icon: 'none',
					title: '请输入搜索内容'
				})
				this.teacherList = []
				this.getTeacherList()
			},
			handlerConfirmArea(v) {
				this.teacherList = []
				this.form.nativePlace = v[0].label == '不限' ? '' : v[0].label
				this.nativePlaceStr = v[v.length-1].label
				this.getTeacherList()
			},
			handlerClosePop() {
				this.teacherList = []
				this.getTeacherList()
			}
		}
	}
</script>

<style lang="scss" scoped>
	.teacher {
		padding-bottom: 100rpx;

		::v-deep.u-mask,
		::v-deep.u-drawer {
			bottom: 100rpx;
		}
	}

	.swiper {
		height: 360rpx;
	}

	.grid {
		width: 95%;
		margin: 10px auto 0;
	}

	.notice {
		padding: 6rpx 0;
		height: 80rpx;
		background-color: #f3f3f3;

		.notice-content {
			display: flex;
			padding: 0 10rpx;
			height: 68rpx;
			line-height: 68rpx;
			background-color: #fff;
			color: #d43030;

			.notice-icon {
				width: 70rpx;
				line-height: 76rpx;
			}

			.notice-text {
				flex: 1;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
			}

			.notice-btn-box {
				display: flex;
				align-items: center;
				width: 102rpx;
				text-align: center;

				.notice-btn {
					width: 70rpx;
					height: 38rpx;
					line-height: 38rpx;
					font-size: 22rpx;
					border-radius: 10rpx;
					background-color: #d43030;
					color: #fff;
				}
			}
		}
	}

	.search {
		padding: 30rpx 10rpx;
		// padding: 10rpx;
		background-color: #00c65d;
	}
	
	.filter-item {
		flex: 1;
		text-align: center;
		// max-width: 120rpx;
	}
	
	.text-overflow {
			overflow: hidden;
			text-overflow: ellipsis;
			white-space: nowrap;
	}

	.filter-box {
		height: 70rpx;
		line-height: 70rpx;
		font-size: 28rpx;

		.filter-content {
			display: flex;
			justify-content: space-between;
			padding: 0 10rpx;
			height: 100%;
			background-color: #fff;
			border-bottom: 2rpx solid #F1F1F1;

			.dropdown {
				position: relative;
				&::after {
					position: absolute;
					top: 40%;
					display: inline-block;
					content: '';
					margin-left: 5rpx;
					width: 12rpx;
					height: 12rpx;
					border-right: 2rpx solid #ccc;
					border-bottom: 2rpx solid #ccc;
					transform: rotate(45deg) translateY(0%);
				}
			}
		}
	}

	.teacher-box {
		padding: 0 10rpx;

	}

	.teacher-item {
		padding-top: 20rpx;
		height: 246rpx;

		&:nth-child(n+2) {
			margin-top: 20rpx;
		}

		.hd {
			display: flex;

			.hd-avatar {

				margin-right: 20rpx;
				width: 170rpx;
				height: 170rpx;
				background-color: #000;
			}

			.hd-express {
				.hd-form {
					height: 48rpx;
					line-height: 48rpx;
				}

				.hd-desc {
					display: flex;
					height: 42rpx;
					line-height: 42rpx;
					font-size: 28rpx;
					color: #00c65d;

					.hd-cate {
						width: 280rpx;
					}
					
					
				}
				.c-c {
					color: #ccc;
				}
			}

		}

		.bd {
			padding: 10rpx 0 20rpx;
			border-bottom: 1rpx solid #f2f3f4;

		}
	}

	.popup-content {
		display: flex;
		flex-direction: column;
		height: 100%;

		.popup-hd {
			flex: 1;
		}

		.popup-btn {
			height: 70rpx;
			line-height: 70rpx;
			text-align: center;
			color: #999;
			background-color: #eee;
		}
	}

	.popup-title {
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		border-bottom: 1rpx solid #f2f3f4;
	}

	.popup-item {
		padding: 0 10rpx;
		min-height: 322rpx;
	}

	.popup-item-title {
		height: 70rpx;
		line-height: 70rpx;
		color: #000;
		font-size: 30rpx;
		font-weight: 600;
	}

	.popup-card {
		display: flex;
		flex-wrap: wrap;
	}

	.card-item {
		margin-right: 12rpx;
		margin-bottom: 20rpx;
		width: 160rpx;
		height: 64rpx;
		line-height: 64rpx;
		font-size: 26rpx;
		text-align: center;
		background-color: #f6f6f6;
		border: 1rpx solid #f6f6f6;
		border-radius: 10rpx;
	}

	.card-item-active {
		border: 1rpx solid #00c65d;
		background-color: #cff4e0;
	}
	
</style>
