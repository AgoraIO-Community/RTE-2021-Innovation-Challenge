<template>
	<view class="lesson">
		<!-- <text>老师-发布课程</text> -->
		<u-form :model="form" ref="formRef">

			<u-form-item label="学科分类" label-width="150" prop="category" required>
				<u-input placeholder="请选择您的学科分类" type="select" v-model="categoryStr" @click="isShowSelectCate = true">
				</u-input>
				<u-select v-model="isShowSelectCate" :list="categoryList" mode="mutil-column-auto" label-name="name" value-name="code"
				 @confirm="handleSelectCate" :default-value="cateDefault"></u-select>
			</u-form-item>

			<u-form-item label="课程年级" label-width="150" prop="level" required>
				<u-input placeholder="请选择年级" type="select" v-model="GradeStr" @click="isShowSelectGrade = true">
				</u-input>
				<u-select v-model="isShowSelectGrade" :list="tempGradeList" label-name="name" value-name="code" @confirm="handleSelectGrade"></u-select>
			</u-form-item>
			<u-form-item label="当前成绩" label-width="150" prop="score" required>
				<u-input placeholder="当前成绩" type="select"  v-model="form.score" @click="isShowSelectScore= true"></u-input>
				<u-select v-model="isShowSelectScore" :list="ScoreList"  @confirm="handleSelectScore"></u-select>
			</u-form-item>
			<u-form-item label="老师性别" label-width="150" prop="sex" required>
				<u-input placeholder="老师性别" type="select" v-model="SexStr" @click="isShowSelectSex= true">
				</u-input>
				<u-select v-model="isShowSelectSex" :list="SexList"  @confirm="handleSelectSex"></u-select>
			</u-form-item>
			<u-form-item label="授课方式" label-width="150" prop="type" required>
				<u-input placeholder="授课方式" type="select" v-model="TypeStr"  @click="isShowSelectType= true">
				</u-input>
				<u-select v-model="isShowSelectType" :list="typeList" label-name="name" value-name="code"  @confirm="handleSelectType"></u-select>
			</u-form-item>
			<u-form-item label="院校经验" label-width="150" prop="trainExperience" required>
				<u-input placeholder="院校经验" type="select" v-model="trainExperience"  @click="isShowSelectexperience= true">
				</u-input>
				<u-select v-model="isShowSelectexperience" :list="experienceList" label-name="name" value-name="code" @confirm="handleSelectexperience"></u-select>
			</u-form-item>
			
			<u-form-item label="课时数量" label-width="150" prop="times" required v-if="isAutoPrice">
				<u-input placeholder="课时数量" type="select"  v-model="timesStr" @click=" isShowSelecthour= true ">
				</u-input>
				<u-select v-model="isShowSelecthour"  :list="hourList"  @confirm="handleSelecthour"></u-select>
			</u-form-item>
			<u-form-item label="一口价" label-width="150" prop="price" required v-if="isAutoPrice">
				<u-input placeholder="一口价" type="input" disabled=""  v-model="form.price"></u-input>
			</u-form-item>
			<u-form-item label="订单总价" label-width="150" prop="priceAll" required v-if="isAutoPrice">
				<u-input placeholder="订单总价" type="input" disabled="" v-model="priceAll"></u-input>
			</u-form-item>
			<u-form-item label="定位地址" label-width="150" prop="address" required>
				<!-- <u-input placeholder="请选择地址" type="text" v-model="form.address"></u-input> -->
				<view class="" @click="handleClickAddress">
					{{this.form.address || '请选择地址'}}
				</view>
			</u-form-item>
			<u-form-item label="上课时间" label-width="150" prop="classDate" required>
				<u-input placeholder="请选择上课时间" type="select" v-model="timeDateStr" @click="timeShow = true">
				</u-input>
				<u-select v-model="timeShow" :list="WeekList"  @confirm="handleSelectWeek"></u-select>
				
			</u-form-item>
			<u-form-item label="请输入需要讲课的内容或其它备注" label-position="top" prop="content">
				<u-input placeholder="请输入需要讲课的内容或其它备注" type="text" v-model="form.content"></u-input>
			</u-form-item>
			
			<u-form-item label-position="top" label="讲课的内容拍照上传">
				<u-upload width="160" height="160" max-count='9' :action="action" ref="iconPathRef"
					@on-success="handleSuccessIconPath" @on-remove="handleRemoveIconPath" :file-list="iconPathList">
				</u-upload>
			</u-form-item>
		</u-form>

		<view class="fixed-btn">
			<u-button type="success" @click="handleSubmit" :loading="loading">立即发布</u-button>
		</view>
		<!-- <u-back-top :scroll-top="scrollTop"></u-back-top> -->
		<!-- <u-tabbar :list="list" :mid-button="false" active-color="#00c65d"></u-tabbar> -->
		
		<!-- 弹层 -->
		<u-popup v-model="isShowPop" mode="bottom" height="95%" border-radius="15">
			<my-map @save-address="saveAddress"/>
		</u-popup>
	</view>
</template>

<script>
	import Map from '../../../components/Map/index.vue'
	
	export default {
		components: {
			'my-map': Map
		},
		data() {
			return {
				list: getApp().globalData.teacher,
				form: {
					price: 0,
					content: '',
					category: '',
					level: '',
					type: '',
					sex:0,
					trainExperience:"",
					times:0,
					score:'',
					classDate:'',
					latitude:'',
					longitude:'',
					address:'',
					iconPath:''
				},
				isAutoPrice:true,
				formRules: {
					
					category: [{
						required: true,
						message: '请填写选择学科分类',
						trigger: ['blur', 'change']
					}],
					level: [{
						required: true,
						message: '请填写选择年级',
						trigger: ['blur', 'change']
					}],
					score: [{
						required: true,
						message: '请填写当前分数',
						trigger: ['blur', 'change']
					}],
					type: [{
						required: true,
						message: '请填写授课方式',
						trigger: ['blur', 'change']
					}],
					trainExperience: [{
						required: true,
						message: '请填写院校经验',
						trigger: ['blur', 'change']
					}],
					
					classDate: [{
						required: true,
						message: '请填写上课时间',
						trigger: ['blur', 'change']
					}]
					
				},
				categoryStr: '',
				isShowSelectCate: false,
				categoryList: [],
				GradeStr: '',
				isShowSelectGrade: false,
				GradeList: [],
				experienceList:[],
				isShowSelectexperience:false,
				trainExperience:"",
				AttachesFilrList: [],
				// 图片上传地址
				action: '',
				typeStr: '',
				isShowSelectType: false,
				typeList: [],
				iconPathList: [],
				loading: false,
				cateDefault: [],
				defaultCode: '',
				disabledLevel: false,
				disabledExperience:false,
				styleList: [{
					value: '0',
					label: '一对一'
				}],
				isShowSelectStyle: false,
				styleStr: '一对一',
				provideStr: '',
				provideList: [],
				isShowSelectProvide: false,
				
				// 新的
				isShowSelectScore:false,
				ScoreList:[
					{
						'value':"优",
						"label":"优"
					},
					{
						'value':"中",
						"label":"中"
					},
					{
						'value':"良",
						"label":"良"
					},
					{
						'value':"不及格",
						"label":"不及格"
					}
					
				],
				
				WeekList:[
					{
						'value':"周一",
						"label":"周一"
					},
					{
						'value':"周二",
						"label":"周二"
					},
					{
						'value':"周三",
						"label":"周三"
					},
					{
						'value':"周四",
						"label":"周四"
					},
					{
						'value':"周五",
						"label":"周五"
					},
					{
						'value':"周六",
						"label":"周六"
					},
					{
						'value':"周日",
						"label":"周日"
					}
					
				],
				
				SexList:[
					{
						'value':"2",
						"label":"不限"
					},
					{
						'value':"0",
						"label":"女老师"
					},
					{
						'value':"1",
						"label":"男老师"
					}
					
				],
				isShowSelectSex:false,
				SexStr:"",
				
				isShowSelectType:false,
				TypeStr:"",
				
				hourList:[
					{
						'value':"1",
						"label":"1课时（每个课时50分钟）"
					},
					{
						'value':"2",
						"label":"2课时（每个课时50分钟）"
					},
					{
						'value':"3",
						"label":"3课时（每个课时50分钟）"
					},
					{
						'value':"4",
						"label":"4课时（每个课时50分钟）"
					}
				],
				isShowSelecthour:false,
				timesStr:"",
				timeShow:false,
				timeDateStr:'',
				priceAll:0,
				priceList:{
					'不限':{
						"一年级":50,
						"二年级":50,
						"三年级":50,
						"四年级":60,
						"五年级":60,
						"六年级":60,
						"七年级":70,
						"八年级":70,
						"九年级":80,
						"高一":90,
						"高二":90,
						"高三":100
					},
					'普通院校':{
						"一年级":50,
						"二年级":50,
						"三年级":50,
						"四年级":60,
						"五年级":60,
						"六年级":60,
						"七年级":70,
						"八年级":70,
						"九年级":80,
						"高一":90,
						"高二":90,
						"高三":100
					},
					'重点院校':{
						"一年级":60,
						"二年级":60,
						"三年级":60,
						"四年级":70,
						"五年级":70,
						"六年级":70,
						"七年级":80,
						"八年级":80,
						"九年级":90,
						"高一":100,
						"高二":100,
						"高三":120
					},
					'211院校':{
						"一年级":70,
						"二年级":70,
						"三年级":70,
						"四年级":80,
						"五年级":80,
						"六年级":80,
						"七年级":90,
						"八年级":90,
						"九年级":100,
						"高一":120,
						"高二":120,
						"高三":150
					},
					'985院校':{
						"一年级":80,
						"二年级":80,
						"三年级":80,
						"四年级":90,
						"五年级":90,
						"六年级":90,
						"七年级":100,
						"八年级":100,
						"九年级":110,
						"高一":150,
						"高二":150,
						"高三":180
					},
					'硕博学历':{
						"一年级":80,
						"二年级":80,
						"三年级":80,
						"四年级":90,
						"五年级":90,
						"六年级":90,
						"七年级":100,
						"八年级":100,
						"九年级":110,
						"高一":150,
						"高二":150,
						"高三":180
					},
					'2-5年经验':{
						"一年级":60,
						"二年级":60,
						"三年级":60,
						"四年级":70,
						"五年级":70,
						"六年级":70,
						"七年级":80,
						"八年级":80,
						"九年级":90,
						"高一":100,
						"高二":100,
						"高三":120
					},
					'6-10年经验':{
						"一年级":70,
						"二年级":70,
						"三年级":70,
						"四年级":80,
						"五年级":80,
						"六年级":80,
						"七年级":90,
						"八年级":90,
						"九年级":100,
						"高一":120,
						"高二":120,
						"高三":150
					},
					'11-15年经验':{
						"一年级":80,
						"二年级":80,
						"三年级":80,
						"四年级":90,
						"五年级":90,
						"六年级":90,
						"七年级":100,
						"八年级":100,
						"九年级":110,
						"高一":150,
						"高二":150,
						"高三":180
					},
					'15年以上经验':{
						"一年级":90,
						"二年级":90,
						"三年级":90,
						"四年级":100,
						"五年级":100,
						"六年级":100,
						"七年级":110,
						"八年级":110,
						"九年级":120,
						"高一":180,
						"高二":180,
						"高三":200
					},
				},
				
				isShowPop: false
			
			}
		},
		watch: {
			form: {
				handler() {
					const tempCate = this.categoryList.filter(e => !e.mark1)

					let flag = false
					tempCate.forEach(e => {
						e.children.forEach(v => {
							if (v.code === this.form.category) {
								return flag = true
							}
						})
					})
					
					if (flag) {
						const tempGrade = this.GradeList.find(e => !e.mark1)
						if (tempGrade) {
							this.GradeStr = tempGrade.name
							this.form.level = tempGrade.code
							this.disabledLevel = true
						}
					} else {

						this.disabledLevel = false
					}

				},
				deep: true
			}
		},
		computed: {
			
			tempGradeList() {
				console.log(this.GradeList)
				if (this.disabledLevel) {
					console.log(this.GradeList.filter(e => !e.mark1))
					return this.GradeList.filter(e => !e.mark1)
				} else {

					return this.GradeList
				}
			},
			
			tempExperienceList() {
				
				if (this.disabledExperience) {
					return this.experienceList.filter(e => !e.mark1)
				} else {
			
					return this.experienceList
				}
				console.log(this.experienceList)
			}
			
		},
		created() {
			this.action = getApp().globalData.baseUrl + 'attach/upload'
		},
		mounted() {
			this.getCategroyList()
			this.getGradeList()
			this.getTypeList()
			this.getAreaList()
			this.getExperienceList()
			
			// this.pay()
			
		},
		
		onReady() {
			this.$refs.formRef.setRules(this.formRules)
		},
		onLoad(option) {
			if (option.code) {
				this.defaultCode = option.code

			}
			
		},
		// onHide() {
		// 	const temp = {
		// 		categoryStr: this.categoryStr,
		// 		GradeStr: this.GradeStr,
		// 		SexStr: this.SexStr,
		// 		TypeStr: this.TypeStr,
		// 		trainExperience: this.trainExperience,
		// 		timesStr: this.timesStr,
		// 		priceAll: this.priceAll,
		// 		timeDateStr: this.timeDateStr,
		// 	}
		// 	console.log(this.form,'hide')
		// 	uni.setStorageSync('enterStrData', temp)
		// 	uni.setStorageSync('enterData', this.form)
		// },
		// onUnload() {
		// 	uni.removeStorageSync('enterStrData')
		// 	uni.removeStorageSync('enterData')
		// 	uni.removeStorageSync('address')
		// },		
		// onShow() {
			
		// 	const tempForm = uni.getStorageSync('enterData') || ''
		// 	const tempStrData = uni.getStorageSync('enterStrData') || ''
		// 	if(tempForm) {
		// 		this.form = Object.assign(this.form, tempForm)
		// 		this.categoryStr = tempStrData.categoryStr
		// 		this.GradeStr = tempStrData.GradeStr
		// 		this.SexStr = tempStrData.SexStr
		// 		this.TypeStr = tempStrData.TypeStr
		// 		this.trainExperience = tempStrData.trainExperience
		// 		this.timesStr = tempStrData.timesStr
		// 		this.priceAll = tempStrData.priceAll
		// 		this.timeDateStr = tempStrData.timeDateStr
		// 	}
		// 	const tempAddress = uni.getStorageSync('address') || ''
		// 	if(tempAddress) {
		// 		this.form.longitude = tempAddress.longitude
		// 		this.longitude = tempAddress.longitude
		// 		this.form.latitude = tempAddress.latitude
		// 		this.latitude = tempAddress.latitude
		// 		this.form.address = tempAddress.address
		// 	}
		// },
		methods: {
			// 选择分类
			handleSelectCate(value) {
				this.form.category = value[value.length - 1].value
				this.categoryStr = value.map(e => e.label).join('/')
				// const temp = ['竞赛及计算机','大学分类课程','考研考证考公','出生成长生活']

			},
			// 选择年级
			handleSelectGrade(value) {
				this.form.level = value[0].value
				this.GradeStr = value[0].label
				this.countPrice()
				console.log(value)
			},
			countPrice(){
				
				if(this.GradeStr && this.trainExperience){
					this.form.price = this.priceList[this.trainExperience][this.GradeStr]
					
				}
				
				if(this.form.price && this.form.times){
					this.priceAll = this.form.price * this.form.times
				}
				
			},
			// 选择类型
			handleSelectType(value) {
				this.form.type = value[0].value
				this.typeStr = value[0].label
			},
			// 获取字典数据
			getData(params) {
				return new Promise((resolve, reject) => {
					this.ajax({
						url: '/const/listData',
						data: params
					}).then(res => {
						resolve(res)
						
					})
				})
			},
			// 删除空的children
			delChildren(temp) {
				temp.forEach(e => {
					if (e && e.children && e.children.length !== 0) {
						this.delChildren(e.children)
					}
					if (e.children.length === 0) {
						delete e.children
					}
				})
				return temp
			},
			// 获取服务分类列表数据
			getCategroyList() {
				const params = {
					type: 1
				}
				this.getData(params).then(res => {
					this.categoryList = this.delChildren(res.data)
					this.categoryList.forEach(e => {

						if (!e.children) {
							e.children = []
						}
					})
					const index = this.categoryList.findIndex(e => e.code === this.defaultCode)
					if (index === -1) return
					this.cateDefault = [index, 0]
					const temp = this.categoryList[index]
					try {
						this.isShowSelectCate = true
						this.categoryStr = `${temp && temp.name}/${temp.children.length !== 0 ? temp.children[0].name : ''}`
						this.form.category = temp && temp.children.length !== 0 ? temp.children[0].code : ''
					} catch (e) {
					}

				})
			},

			// 获取年级
			getGradeList() {
				const params = {
					type: 5
				}
				this.getData(params).then(res => {
					this.GradeList = this.delChildren(res.data)
				})
			},
			// 获取院校经验
			getExperienceList() {
				const params = {
					type: 6
				}
				this.getData(params).then(res => {
					this.experienceList = this.delChildren(res.data)
					console.log(this.experienceList)
				})
			},

			// 获取类型
			getTypeList() {
				const params = {
					type: 4
				}

				this.getData(params).then(res => {
					this.typeList = this.delChildren(res.data)
					
				})

			},

			// 图片上传成功后
			handleSuccessIconPath(data, index, lists, name) {
				console.log(data, index, lists, name)
				// const temp = getApp().globalData.baseUrl + 'attach/download/'
				var obj = {
					'code':data.data.code,
					'type':data.data.contentType
				}
				console.log(obj)
				this.AttachesFilrList.push(obj)
			},
			// 移除图片
			handleRemoveIconPath(index, lists, name) {
				this.form.iconPath = ''
			},
			handleSelectStyle(v) {
				this.form.style = v[0].value
				this.styleStr = v[0].label
			},
			// handleClickAddress() {
			// 	const _this = this
			// 	uni.chooseLocation({
			// 		latitude: this.latitude,
			// 		longitude: this.longitude,
			// 		success: (res) => {
			// 			console.log('位置名称：' + res.name);
			// 			console.log('详细地址：' + res.address);
			// 			console.log('纬度：' + res.latitude);
			// 			console.log('经度：' + res.longitude);
			// 			_this.form.latitude = res.latitude
			// 			_this.form.longitude = res.longitude
			// 			_this.form.address = res.address
			// 		}
			// 	});
			// },
			
			handleClickAddress() {
				// uni.navigateTo({
				// 	url: '../../common/map'
				// })
				this.isShowPop = true
			},
			
				saveAddress(data) {
				console.log(data,'p')
				this.form.longitude = data.longitude
				this.form.latitude = data.latitude
				this.longitude = data.longitude
				this.latitude = data.latitude
				this.form.address = data.address
				this.isShowPop = false
			},
			
			// 获取区域
			getAreaList() {
				this.ajax({
					url: '/area/listData',
					data: {
						parent: 0
					}
				}).then(res => {
					this.provideList = res.data
				})
			},
			handleSelectProvide(v) {
				this.form.provide = v[0].label
				this.provideStr = v[0].label
			},
			
			//老师性别
			handleSelectSex(v) {
				this.form.sex = v[0].value
				this.SexStr = v[0].label
			},
			//当前成绩
			handleSelectScore(v) {
				this.form.score = v[0].value
				
			},
			//老师性别
			handleSelectWeek(v) {
				this.form.classDate = v[0].value
				this.timeDateStr = v[0].value
				
			},
			//授课方式
			handleSelectType(v) {
				console.log(v)
				if(v[0].label != '教学课程（在线课堂）'){
					this.isAutoPrice = false
				}
				this.form.type = v[0].value
				this.TypeStr = v[0].label
			},
			handleSelectexperience(v) {
				console.log(v)
				this.form.trainExperience = v[0].value
				this.trainExperience = v[0].label
				this.countPrice()
			},
			handleSelecthour(v) {
				this.form.times = v[0].value
				this.timesStr = v[0].label
				this.countPrice()
			},
			// handleSelectorTime(v) {
			// 	this.form.classDate = this.timeDateStr = v.year +"-"+v.month+"-"+v.day 
			// },
			pay(orderid){
				
				this.ajax({
					url: '/pay/prepay',
					data: { 
						code:orderid,
						totalFee:100,
						body:'ces'
					}
				}).then(res => {
					var orderInfo=res.data;
					console.log( {
							"appid": orderInfo.appId,  // 微信开放平台 - 应用 - AppId，注意和微信小程序、公众号 AppId 可能不一致
							"noncestr":orderInfo.nonceStr, // 随机字符串
							"package": "Sign=WXPay",        // 固定值
							"partnerid": orderInfo.partnerId,      // 微信支付商户号
							"prepayid": orderInfo.prepayId, // 统一下单订单号 
							"timestamp": orderInfo.timeStamp,        // 时间戳（单位：秒）
							"sign": orderInfo.sign // 签名，这里用的 MD5 签名
						})
					
					uni.requestPayment({
						"provider": "wxpay", 
						"orderInfo": {
								"appid": orderInfo.appId,  // 微信开放平台 - 应用 - AppId，注意和微信小程序、公众号 AppId 可能不一致
								"noncestr":orderInfo.nonceStr, // 随机字符串
								"package": "Sign=WXPay",        // 固定值
								"partnerid": orderInfo.partnerId,      // 微信支付商户号
								"prepayid": orderInfo.prepayId, // 统一下单订单号 
								"timestamp": orderInfo.timeStamp,        // 时间戳（单位：秒）
								"sign": orderInfo.sign // 签名，这里用的 MD5 签名
							},
						success: (res) => {
							uni.showToast({
								title: "支付成功!",
								success:function(){
									uni.redirectTo({
										url:"/pages/parent/demand/index?status=0"
									})
								}
							})
						},
						fail: (res) => {
							uni.showToast({
								title: "支付失败!",
								success:function(){
									uni.redirectTo({
										url:"/pages/parent/demand/index?status=0"
									})
								}
							})
							
						},
						complete: () => {
							this.loading = false;
						}
					})
				})
			},
			
			
			// 提交
			handleSubmit() {
				console.log(this.form); 
				this.form.state = 0
				this.$refs.formRef.validate(valid => {
					if (!valid) return
					const temp = this.typeList.find(e => !e.mark1)
					if (temp) {
						if (temp.code === this.form.type) {
							if (this.form.price < 50) return uni.showToast({
								icon: 'none',
								title: '直播课程价格请不要低于五十元'
							})
						}
					}
					this.loading = true
					this.form.attaches = this.AttachesFilrList
					this.ajax({
						url: '/demand/insert',
						data: { ...this.form,
							user: JSON.parse(uni.getStorageSync('user')).code
						}
					}).then(res => {
						console.log(res)
						this.pay(res.data.code)

					}).catch(() => {
						this.loading = false
					})
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.lesson {
		padding: 0 30rpx;
		padding-bottom: 108rpx;
	}

	.fixed-btn {
		padding-top: 10rpx;
		// bottom: 120rpx;
		left: 10rpx;
		right: 10rpx;
		background-color: #fff;
	}
</style>
