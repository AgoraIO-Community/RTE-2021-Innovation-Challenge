<template>
	<view class="teacher-detail">
		<view class="">
			<view class="header-box">
				<view class="img-box">
					<u-image width="100%" height="176rpx" :src="imgPath + lessonInfo.iconPath"></u-image>
				</view>
				<view class="header-express">
					<view class="header-from">
						{{lessonInfo.title || '暂无'}}
					</view>
					<view class="header-cate">
						<view>
							{{lessonInfo.content || '暂无'}}
						</view>
					</view>
					<view class="header-start">
						评级: <u-rate :count="5" v-model="rate" size="40" disabled></u-rate>
					</view>
				</view>
			</view>
				
			<view class="address-box">
				<view class="address-left">
					<u-icon name="map" size="36"></u-icon>
					{{lessonInfo.address || '暂无'}}
				</view>
				<view class="address-right">
						距您20.86km
				</view>
			</view>
				
			<u-tabs :list="tabList" :is-scroll="false" :current="activeTab" bar-height="4" bar-width="150" active-color="#00c65d" @change="handleChangeTab"></u-tabs>
			
			<view class="content">
				<lesson-desc v-if="activeTab === 0 && teacher_" :item="teacher_"></lesson-desc>
				
				<view class="judge-box" v-if="activeTab === 1">
					暂无评价信息
				</view>
			</view>
		</view>
		
		<view class="fixed-btn">
			<view class="btn-box">
				<view class="btn-collect" @tap="addCollect1(isCollect)">
					<u-icon name="heart" size="50" :color="isCollect?'#D54C29':'#707070'" ></u-icon>
					<text>{{isCollect?'已收藏':'收藏'}}</text>
				</view>
				<view class="btn" role="button" @tap="getFindData">
					购买课程
				</view>
			</view>
		</view>
	
	</view>
</template>

<script>
	import Desc from '../../../components/lessonDetail/index.vue'
	export default {
		components: {
			'lesson-desc': Desc
		},
		data() {
			return {
				// 
				rate: 5,
				activeTab: 0,
				tabList: [
					{
						name: '介绍'
					},
					{
						name: '评价'
					}
				],
				// 
				lessonInfo: {},
				imgPath: '',
				code:'',
				checkStatus:false,
				isCollect:false,
				teacher_:[]
			}
		},
		created() {
			this.imgPath = getApp().globalData.imgPath
		},
		onLoad(option) {
			console.log(option)
			this.code=option.code
			this.getTeacherDetail(option.code)
		},
		methods: {
			// 获取教师详情
			getTeacherDetail(code) {
				const params = {
					code
				}
				this.ajax({
					url: '/lesson/findData',
					data: params
				}).then(res => {
					console.log(res)
					this.lessonInfo = res.data
					this.teacher_= res.data.teacher_
					if(res.data.collect){
						this.isCollect=true
					}else{
						this.isCollect=false
					}
				})
			},
			addCollect1(e){
				if(e){
					this.delCollect();
				}else{
					this.addCollect();
				}
			},
			addCollect(e){
				const params = {
					target:this.code,
					type:1,
					user:JSON.parse(uni.getStorageSync('user')).code
				}
				this.ajax({
					url: '/collect/insert',
					data: params
				}).then(res => {
					uni.showToast({
						title:"收藏成功",
						icon:"none"
					})
					console.log(res)
					this.getTeacherDetail(this.code)
				})
			},
			delCollect(e){
				const params = {
					code:this.lessonInfo.collect.code,
					type:1,
					user:JSON.parse(uni.getStorageSync('user')).code
				}
				this.ajax({
					url: '/collect/remove',
					data: params
				}).then(res => {
					uni.showToast({
						title:"取消收藏",
						icon:"none"
					})
					console.log(res)
					this.getTeacherDetail(this.code)
				})
			},
			pay(code){
				const params = {
					code
				}
				this.ajax({
					url: '/pay/prepay',
					data: params
				}).then(res => {
					var orderInfo = res.data
					uni.requestPayment({
						"provider": "wxpay", 
						"orderInfo": {
						        "appid": orderInfo.appId,  // 微信开放平台 - 应用 - AppId，注意和微信小程序、公众号 AppId 可能不一致
						        "noncestr":orderInfo.nonceStr, // 随机字符串
						        "package": "Sign=WXPay",        // 固定值
						        "partnerid": orderInfo.partnerId,      // 微信支付商户号
						        "prepayid": orderInfo.prepayId, // 统一下单订单号 
						        "timestamp": orderInfo.timeStamp,        // 时间戳（单位：秒）
						        "sign": orderInfo.sign // 签名，这里用的 MD5 签名
						    },
						success: (res) => {
							uni.showToast({
								title: "购买成功！",
								"icon":"none",
								success:function(){
									setTimeout(function(){
										uni.navigateTo({
											url:"/pages/parent/order/index?status=0"
										})
									},1000)
								}
							})
						},
						fail: (res) => {
							uni.showToast({
								title: "支付失败!",
								success:function(){
									uni.redirectTo({
										url:"/pages/parent/demand/index?status=0"
									})
								}
							})
						},
						complete: () => {
							this.loading = false;
						}
					})
					
				})
			},
			// tab改变
			handleChangeTab(v) {
				this.activeTab = v
			},
			getFindData(){
				console.log(this.lessonInfo)
				const params = {
					teacher:this.lessonInfo.teacher,
					code:this.code,
					user:JSON.parse(uni.getStorageSync('user')).code
				}
				this.ajax({
					url: '/teacher/phone/insert',
					data: params
				}).then(res => {
					console.log(res)
					this.pay(res.data.code)
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.teacher-detail {
		// display: flex;
		// flex-direction: column;
		// justify-content: space-between;
		padding: 0 10rpx;
		padding-bottom: 100rpx;
		// height: 100vh;
		.header-box {
			display: flex;
			padding: 10rpx 0;
			.img-box {
				margin-right: 16rpx;
				width: 200rpx;
				height: 176rpx;
				background-color: #000000;
			}
			
			.header-express {
				flex: 1;
				display: flex;
				flex-direction: column;
				.header-from {
					height: 60rpx;
					line-height: 60rpx;
					font-size: 32rpx;
				}
				
				.header-cate {
					margin-top: 10rpx;
					overflow: hidden;
					height: 60rpx;
					line-height: 60rpx;
					view {
						padding: 0 16rpx;
						// width: 128rpx;
						min-width: 128rpx;
						max-width: 290rpx;
						height: 50rpx;
						line-height: 50rpx;
						border-radius: 10rpx;
						font-size: 24rpx;
						color: #fff;
						background-color: #00c65d;
						text-align: center;
					}
				}
				
				.header-start {
					height: 70rpx;
					line-height: 70rpx;
					font-size: 24rpx;
				}
			}
		}
	
		.address-box {
			display: flex;
			justify-content: space-between;
			padding: 0 15rpx;
			height: 60rpx;
			line-height: 60rox;
			font-size: 24rpx;
			
			.address-left {
				color: #999;
			}
			
			.address-right {
				color: #ff3c4a;
			}
		}
		
		.content {
			margin-top: 20rpx;
			padding: 0 15rpx;
		}
		
		.cate-box,
		.judge-box{
			height: 180rpx;
			line-height: 360rpx;
			text-align: center;
			font-size: 24rpx;
			color: #666;
		}
		
		.btn-box {
			display: flex;
			justify-content: space-around;
			.btn-collect {
				display: flex;
				flex-direction: column;
				align-items: center;
				// justify-content: center;
				width: 108rpx;
				height: 96rpx;
				line-height: 96rpx;
				text-align: center;
				text {
					height: 56rpx;
					line-height: 56rpx;
					font-size: 24rpx;
					color: #707070;
				}
			}
			.btn {
				box-sizing: border-box;
				padding: 0 20rpx;
				width: 540rpx;
				height: 80rpx;
				line-height: 80rpx;
				border-radius: 40rpx;
				text-align: center;
				background-color: #00c65d;
				color: #fff;
			}
		}
	
	}
</style>
