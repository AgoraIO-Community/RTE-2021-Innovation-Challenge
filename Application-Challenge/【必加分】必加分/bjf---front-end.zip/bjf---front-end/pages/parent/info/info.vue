<template>
	<view>
		<view class="top">
			<view class="title">{{list.categoryStr}}</view>
			<view class="bto">
				<view class="price">￥{{list.price}}</view>
				<view class="num">{{list.sell}}人已订</view>
			</view>
			<view class="wrap">
				<image :src="url+list.iconPath" mode="aspectFill" class="imgs" @tap="seeImgs"></image>
			</view>
		</view>
		<view style="background: #F3F3F3;height: 20rpx;"></view>
		<view class="content">
			<view class="title">课程详情</view>
			<view class="des">{{list.content}}</view>
		</view>
		<view class="foot">
			<view class="left">
				<view class="fList" @click="jumpindex">
					<image src="/static/index.png" mode="aspectFill" class="icon"></image>
					<view class="ftoName">首页</view>
				</view>
				<view class="fList" @tap="getFindData1">
					<image src="/static/phone.png" mode="aspectFill" class="icon"></image>
					<view class="ftoName">电话</view>
				</view>
			</view>
			<view class="right">
				<view class="btn" @tap="getFindData1" v-if="!payStatus">立即购买</view>
				<view class="btn"  v-if="payStatus">已购买</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				id:'',
				code:'',
				list:[],
				url:'',
				payStatus:false
			}
		},
		onLoad(e) {
			this.id=e.id;
			this.code=e.code;
			this.url=getApp().globalData.imgPath;
			this.getinfo()
		},
		methods: {
			getinfo(){
				const params = {
					id:this.id,
					code:this.code
				}
				this.ajax({
					url: '/lesson/findData',
					data: params
				}).then(res => {
					console.log(res)
					this.list=res.data;
					this.getinfox(res.data.code)
				})
			},
			getinfox(code){
				const params = {
					lesson:code,
					user:JSON.parse(uni.getStorageSync('user')).code
				}
				this.ajax({
					url: '/lesson/findData',
					data: params
				}).then(res => {
					console.log(res.data)
					if(res.data){
						this.payStatus=true
					}else{
						this.payStatus=false
					}
				})
			},
			jumpindex(){
				uni.switchTab({
					url:"/pages/parent/teacher/teacher"
				})
			},
			seeImgs(){
				uni.previewImage({
				       urls: this.url+this.list.iconPath
				    });
			},
			getFindData1(){
				const params = {
					teacher:this.list.teacher_.code,
					code:this.code,
					user:JSON.parse(uni.getStorageSync('user')).code
				}
				this.ajax({
					url: '/teacher/phone/insert',
					data: params
				}).then(res => {
					console.log(res)
					this.pay1(res.data.code)
				})
			},
			getFindData(){
				const params = {
					lesson:this.list.code,
					user:JSON.parse(uni.getStorageSync('user')).code
				}
				this.ajax({
					url: '/lesson/user/insert',
					data: params
				}).then(res => {
					console.log(res)
					this.pay(res.data.code)
				})
			},
			pay1(code){
				const params = {
					code
				}
				this.ajax({
					url: '/pay/prepay',
					data: params
				}).then(res => {
					var orderInfo = res.data
					uni.requestPayment({
						"provider": "wxpay", 
						"orderInfo": {
						        "appid": orderInfo.appId,  // 微信开放平台 - 应用 - AppId，注意和微信小程序、公众号 AppId 可能不一致
						        "noncestr":orderInfo.nonceStr, // 随机字符串
						        "package": "Sign=WXPay",        // 固定值
						        "partnerid": orderInfo.partnerId,      // 微信支付商户号
						        "prepayid": orderInfo.prepayId, // 统一下单订单号 
						        "timestamp": orderInfo.timeStamp,        // 时间戳（单位：秒）
						        "sign": orderInfo.sign // 签名，这里用的 MD5 签名
						    },
						success: (res) => {
							uni.showToast({
								title: "感谢您的赞助!"
							})
							uni.makePhoneCall({
							    phoneNumber: this.list.phone
							});
						},
						fail: (res) => {
							console.log(res)
						},
						complete: () => {
							this.loading = false;
						}
					})
					
				})
			},
			pay(code){
				const params = {
					code
				}
				this.ajax({
					url: '/pay/prepay',
					data: params
				}).then(res => {
					var orderInfo = res.data
					uni.requestPayment({
						"provider": "wxpay", 
						"orderInfo": {
						        "appid": orderInfo.appId,  // 微信开放平台 - 应用 - AppId，注意和微信小程序、公众号 AppId 可能不一致
						        "noncestr":orderInfo.nonceStr, // 随机字符串
						        "package": "Sign=WXPay",        // 固定值
						        "partnerid": orderInfo.partnerId,      // 微信支付商户号
						        "prepayid": orderInfo.prepayId, // 统一下单订单号 
						        "timestamp": orderInfo.timeStamp,        // 时间戳（单位：秒）
						        "sign": orderInfo.sign // 签名，这里用的 MD5 签名
						    },
						success: (res) => {
							uni.showToast({
								title: "购买成功！",
								"icon":"none",
								success:function(){
									setTimeout(function(){
										uni.navigateTo({
											url:"/pages/parent/order/index?status=0"
										})
									},1000)
								}
							})
						},
						fail: (res) => {
							uni.showToast({
								title: "支付失败!",
								success:function(){
									uni.redirectTo({
										url:"/pages/parent/demand/index?status=0"
									})
								}
							})
						},
						complete: () => {
							this.loading = false;
						}
					})
					
				})
			},
		}
	}
</script>

<style scoped lang="scss">
	page{
		
	}
	.foot{
		display: flex;
		flex-wrap: nowrap;
		align-items: center;
		position: fixed;
		border-top: 1rpx solid #eee;
		left: 0;
		right: 0;
		bottom: 0;
		background: #fff;
		padding: 10rpx 20rpx;
		box-sizing: border-box;
		.left{
			width: 250rpx;
			display: flex;
			.fList{
				width: 100rpx;
				.icon{
					width: 50rpx;
					height: 50rpx;
					display: block;
					margin: 0 auto;
				}
				.ftoName{
					height: 30rpx;
					line-height: 30rpx;
					font-size: 25rpx;
					color: #555;
					text-align: center;
				}
			}
			
		}
		.btn{
			box-sizing: border-box;
			padding: 0 20rpx;
			width: 440rpx;
			height: 80rpx;
			line-height: 80rpx;
			border-radius: 40rpx;
			text-align: center;
			background-color: #00c65d;
			color: #fff;
		}
	}
.top{
	box-sizing: border-box;
	padding: 20rpx;
	background: #fff;
	.title{
		font-size: 28rpx;
		color: #333;
		line-height: 40rpx;
		letter-spacing: 3rpx;
	}
	.bto{
		padding: 20rpx 0;
		display: flex;
		flex-wrap: nowrap;
		align-items: center;
		justify-content: space-between;
		.price{
			font-size: 30rpx;
			color: red;
			font-weight: bold;
		}
		.num{
			font-size: 25rpx;
			color: #888;
			text-align: right;
		}	
	}
	.wrap{
		display: flex;
		flex-wrap: wrap;
		.imgs{
			width: 215rpx;
			height: 215rpx;
			border-radius: 20rpx;
			margin: 10rpx;
			display: block;
		}
	}
}

.content{
	background-color: #fff;
	.title{
		height: 90rpx;
		line-height: 90rpx;
		color: #333;
		font-size: 28rpx;
		text-align: center;
		font-weight: bold;
		border-bottom: 1rpx solid #eee;
	}
	.des{
		box-sizing: border-box;
		padding: 20rpx;
		font-size: 28rpx;
		color: #888;
		line-height: 40rpx;
		letter-spacing: 3rpx;
	}
}

</style>
