<template>
	<view class="u-p-30">
		<view class="pp">
			<view>{{data.categoryStr }} | {{data.levelStr }} </view>
			<text>{{data.typeStr }} </text>
			<u-icon name="arrow-right"></u-icon>
		</view>
		
		<block v-if="data.demandAccept">
			<view class="pt">
				<text>培训老师</text>
				<text >{{data.teacher?data.teacher.name :''}}</text>
			</view>
			
			<view class="pt" v-if="data.teacherDoneDate">
				<text>完成时间</text>
				<text >{{data.teacherDoneDate}}</text>
			</view>
		</block>
		<u-form :model="formData" :rules="rules" ref="score1" :errorType="['toast','border-bottom']">
			<u-form-item label="老师性格"  prop="name" label-width="200"  label-position="left">
				<u-rate v-model="formData.score1" size="48" :colors="colors" :icons="icons" inactive-icon="thumb-up"></u-rate>
			</u-form-item>
			<u-form-item label="教学质量"  prop="score2"  label-width="200" label-position="left">
				<u-rate v-model="formData.score2" size="48" :colors="colors" :icons="icons" inactive-icon="thumb-up"></u-rate>
			</u-form-item>
			<u-form-item label="老师是否准时" prop="score3" label-width="200"  label-position="left">
				<u-rate v-model="formData.score3" size="48" :colors="colors" :icons="icons" inactive-icon="thumb-up"></u-rate>
			</u-form-item>
			<u-form-item label="评价" prop="intro" label-width="200"  label-position="left">
				<u-input v-model="formData.content"/>
			</u-form-item>
			
		</u-form>
		<u-button type="success" @click="submit" style="margin-top: 30rpx;" :loading="loading">保存</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				loading: false,
				formData: {
					score1:0,
					score2:0,
					score3:0,
					content:''
				},
				data:{},
				icons: ['thumb-down-fill', 'thumb-down-fill', 'thumb-up-fill', 'thumb-up-fill'],
				value:0,
				colors: ['#ffc454', '#ffb409', '#ff9500'],
				rules: {
					intro: [
						{
							min: 5, 
							message: '说说的的学习感受吧！！！', 
							trigger: 'change'
						}
					]
					
				}
			}
		},
		onReady() {
			this.$refs.uForm.setRules(this.rules);
			this.formData = {
				...this.formData
			};
			
		},
		onLoad(options) {
			var _self = this
			_self.code = options?options.code:''
			this.userData = this.user();
			this.ajax({
				url: "/demand/findData",
				data:{
					code:_self.code
				}
			}).then(res => {
				var data = res.data
				if(data.demandAccept){
					_self.ajax({
						url: "/user/findData",
						data:{
							code:data.demandAccept.user
						}
					}).then(result => {
						
						data.teacher = result.data
						_self.data = data
					});
				}
				
			});
		},
		methods: {
			
			submit() {
				var _self = this
				this.formData.type = 3
				this.formData.user = this.user().code
				this.formData.target = this.code
				this.ajax({
					url: "/comment/insert",
					data: this.formData
				}).then(res => {
					if(res.code == '0000'){
						_self.ajax({
							url: "/demand/update",
							data: {
								"code":_self.code,
								"state":7
							}
						}).then(res => {
							uni.showToast({
								'icon':'none',
								'title':'评论成功',
								success:function(res){
									uni.switchTab({
										url:'/pages/parent/order/order'
									})
								}
							})
						});
					}
				});
			}
		}
	}
</script>

<style>
	.tc image{float: left; width: 100rpx; height:100rpx; margin-right: 20rpx;}
	.tc .txt{ float: left; width: calc(100% - 100px);}
	.tc .txt .h{font-size: 28rpx;}
	.tc .txt .p{font-size: 24rpx; display: flex; justify-content: space-between; margin-top: 20rpx; color: #999;}
	.tc{clear: both; overflow: hidden; padding: 12px; border-bottom: 1px solid #f9f9f9;}
	.space{height: 8rpx; background-color: #f1f1f1;}
	.pp{ font-size: 24rpx; padding-bottom: 28rpx; border-bottom: 1rpx solid #f1f1f1; color: #999; position: relative;}
	.pp text{display: block;}
	.pp view{font-size: 16px; color: #333; margin-bottom: 4px;}
	.pp .u-icon{ position: absolute; right: 3%; top:28px; }
	.pt{display: flex; justify-content: space-between; font-size: 24rpx; padding: 28rpx 0; border-bottom: 1rpx solid #f1f1f1; color: #999;}
	.c{color: #19BE6B;}
	.b{color: #999;}
</style>
