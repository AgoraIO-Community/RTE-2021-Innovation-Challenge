<template>
	<view class="content">
		<view class="pp">
			<view>{{data.categoryStr }} | {{data.levelStr }} | {{data.typeStr }}</view>
			<text>￥{{data.price}}</text>
		</view>
		<view class="pt">
			<u-icon name="map" color="#333" size="28" class="uicon"></u-icon>{{data.address}}
		</view>
		<view class="pt">
			<u-image class="f1" width="30%" height="300rpx" :src="`${baseURL}${v.code}`" v-for="(v,i) in data.attaches" :key="i"></u-image>
		</view>
		<view class="space"></view>
		<view class="tit">其他要求</view>
		<view class="cont">
			{{data.content || '无'}}
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				icons: ['thumb-down-fill', 'thumb-down-fill', 'thumb-up-fill', 'thumb-up-fill'],
				value:0,
				colors: ['#ffc454', '#ffb409', '#ff9500'],
				data:{},
				baseURL:'http://114.55.252.249:8085/attach/download/'
			}
		},
		methods:{
			
		},
		onLoad(options){
			this.code = options.code
		},
		mounted() {
			var _self = this
			this.userData = this.user();
			this.ajax({
				url: "/demand/findData",
				data:{
					code:_self.code
				}
			}).then(res => {
				var data = res.data
				if(data.demandAccept){
					_self.ajax({
						url: "/user/findData",
						data:{
							code:data.demandAccept.user
						}
					}).then(result => {
						
						data.teacher = result.data
						_self.data = data
					});
				}else{
					_self.data = data
				}
				
			});
		}
	}
</script>
<style>
	.tc image{float: left; width: 100rpx; height:100rpx; margin-right: 20rpx;}
	.tc .txt{ float: left; width: calc(100% - 100px);}
	.tc .txt .h{font-size: 28rpx;}
	.tc .txt .p{font-size: 24rpx; display: flex; justify-content: space-between; margin-top: 20rpx; color: #999;}
	.tc{clear: both; overflow: hidden; padding: 12px; border-bottom: 1px solid #f9f9f9;}
	.space{height: 8rpx; background-color: #f1f1f1;}
	.pp{ font-size: 24rpx; padding: 28rpx 3%;  color: #999; position: relative;}
	.pp text{display: block; color: #FA3534; font-size: 20px; margin-top: 10px;}
	.pp view{font-size: 16px; color: #333; margin-bottom: 4px;}
	.pp .u-icon{ position: absolute; right: 3%; top:28px; }
	.pt{ font-size: 24rpx; padding: 0 3%; }
	.c{color: #19BE6B;}
	.b{color: #999;}
	.space{background-color: #f1f1f1; height: 8px; margin-top: 10px;}
	.tit{font-size: 18px; text-align: center; border-bottom: 1px solid #f1f1f1; line-height: 2.5;}
	.cont{padding: 8px 3%; font-size: 16px; line-height: 1.8;}
	.pt .u-image{float: left; margin-top: 10px; margin-right: 8px;}
	.pt .u-image img{width: 100%;}
	.pt{clear: both; overflow: hidden;}
</style>
