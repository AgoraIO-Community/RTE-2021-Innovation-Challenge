<template>
	<view class="content">
		<view class="pt">
			<text>{{data.categoryStr || '七年级数学'}} | {{data.wayStr || '习题试卷'}} </text>
			<u-icon name="arrow-right"></u-icon>
		</view>
		<view class="pt">
			<text>订单号</text>
			<text>{{data.code}}</text>
		</view>
		<view class="pt">
			<text>支付金额</text>
			<text >￥{{data.price}}</text>
		</view>
		<view class="pt">
			<text>核销码</text>
			<text >{{data.comsumeCode || '202105062365'}}</text>
		</view>
		
		<view class="pt">
			<text>培训老师</text>
			<text >{{data.teacher || '陈敏清'}}</text>
		</view>
		<view class="pt">
			<text>老师地址</text>
			<text >{{data.address || '深圳市龙华区龙华大厦'}}</text>
		</view>
		 <view class="pt">
			<text>下单时间</text>
			<text >{{data.createTime || '2021-04-02 12：00：00'}}</text>
		</view>
		<view class="pt">
			<text>接单时间</text>
			<text >{{data.acceptTime || '2021-04-02 15：00：00'}}</text>
		</view>
		<view class="pt">
			<text>完成时间</text>
			<text >{{data.completeTime || '2021-04-02 18：00：00'}}</text>
		</view>
		<!--<view class="pt">
			<text>年级</text>
			<text >{{data.level}}</text>
		</view>
		
		<view class="pt">
			<text>上课课时</text>
			<text >{{data.times}}</text>
		</view>
		<view class="pt">
			<text>老师要求</text>
			<text >{{data.times}}</text>
		</view>
		<view class="pt">
			<text>院校经验</text>
			<text >{{data.trainExperience}}</text>
		</view>
		<view class="pt">
			<text>上课地址</text>
			<text >{{data.address}}</text>
		</view>
		<view class="pt">
			<text>上课时间</text>
			<text>{{data.classDate}}</text>
		</view>
		
		<view class="pt">
			<text>订单生成时间</text>
			<text>2021-12-21 12:12:21</text>
		</view> -->
	
	</view>
</template>

<script>
	export default {
		data() {
			return {
				icons: ['thumb-down-fill', 'thumb-down-fill', 'thumb-up-fill', 'thumb-up-fill'],
				value:0,
				colors: ['#ffc454', '#ffb409', '#ff9500'],
				data:{}
			}
		},
		methods:{
			
		},
		onLoad(options){
			this.code = options.code
		},
		mounted() {
			var _self = this
			this.userData = this.user();
			this.ajax({
				url: "/demand/findData",
				data:{
					code:_self.code
				}
			}).then(res => {
				_self.data = res.data
				console.log(res.data)
			});
		}
	}
</script>
<style>
	.tc image{float: left; width: 100rpx; height:100rpx; margin-right: 20rpx;}
	.tc .txt{ float: left; width: calc(100% - 100px);}
	.tc .txt .h{font-size: 28rpx;}
	.tc .txt .p{font-size: 24rpx; display: flex; justify-content: space-between; margin-top: 20rpx; color: #999;}
	.tc{clear: both; overflow: hidden; padding: 12px; border-bottom: 1px solid #f9f9f9;}
	.space{height: 8rpx; background-color: #f1f1f1;}

	.pt{display: flex; justify-content: space-between; font-size: 24rpx; padding: 28rpx 3%; border-bottom: 1rpx solid #f1f1f1; color: #999;}
	.c{color: #19BE6B;}
	.b{color: #999;}
</style>
