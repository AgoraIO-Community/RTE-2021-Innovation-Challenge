<template>
	 <view class="content">
		 <view class="nav">
			 <view class="nav-item" @click="changeItem" data-id="0">
			 	全部
			 	<view class="sp" v-if="status == 0"></view>
			 </view>
		 	<view class="nav-item" @click="changeItem" data-id="1">
		 		待接单
		 		<view class="sp" v-if="status == 1"></view>
		 	</view>
		 	<view class="nav-item" @click="changeItem" data-id="2">
		 		待上课
		 		<view class="sp" v-if="status == 2"></view>
		 	</view>
			<view class="nav-item" @click="changeItem" data-id="4">
				待完成
				<view class="sp" v-if="status == 4"></view>
			</view>
		 	<view class="nav-item" @click="changeItem" data-id="6">
				待评价
		 		<view class="sp" v-if="status == 6"></view>
		 	</view>
			
		 </view>
		 <view v-if="!see" style="position:relative;height: 100px;width:100%;">
			<web-view class="agora_web_view" :src="agoraroom" style="width: 100%;height: 100%;"></web-view>
		 </view>
		<view class="list">
			<view class="card" v-for="(item,index) in list">
				<view class="tc" @click="$common.jumpurl('/pages/parent/demand/order_detail?code='+item.code)">
					<view class="txt">
						<view class="p">
							<text>需求科目：{{item.categoryStr}}</text>
							<text>年级：{{item.levelStr}}</text>
						</view>
						<view class="p">
							<text>院校经验：{{item.trainExperienceStr}}</text>
							<text v-if="item.sex == 0">老师性别：女老师</text>
							<text v-if="item.sex == 1">老师性别：男老师</text>
							<text v-if="item.sex == 2">老师性别：不限</text>
						</view>
						<view class="p">期待上课时间：{{item.classDate}}</view>
						<view class="p">课时数量：{{item.times}}个课时（每个课时50分钟）</view>
						<view class="p">
							<view>
								<u-icon name="map" color="#333" size="28" class="uicon"></u-icon>
								{{item.address}}
								<text class="primary">{{item.distance/1000 }}km</text>
							</view>
						</view>
						<view class="pos">
							￥{{item.price}}
						</view>
						
					</view>
				</view>
				<view class="bc">
					<view class="fl" v-if="item.refund == 2">
						已发起退款，退款比例为 {{item.refundRatio*100}}%,待老师确认
					</view>
					<view class="fl" v-if="item.refund ==1">
						老师已确认，退款比例为{{item.refundRatio*100}}%
					</view>
					<view class="fr">
						<u-button size="mini" v-if="item.state==2" @click="room(item.code)">AgoraRoom</u-button>
						<u-button size="mini" @click="confirm(item.code,item.teacherDoneDate)" v-if="item.state == 4 && !item.parentDoneDate">确认完成</u-button>
						<u-button size="mini" @click="$common.jumpurl('/pages/parent/demand/comment?code='+item.code)" v-if="item.state == 6">立即评价</u-button>
						<u-button size="mini" @click="$common.jumpurl('/pages/parent/demand/refund?code='+item.code)" v-if="item.state != 0 && item.state < 6 && item.refund == 0">申请退款</u-button>
						<u-button size="mini" @click="$common.jumpurl('/pages/parent/demand/order_detail?code='+item.code)" >详情</u-button>
						<u-button size="mini" @click="pay(item.order_.code)" v-if="item.state == 0">立即支付</u-button>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				status:0,
				list:[],
				pageNum:0,
				total:0,
				agoraroom:"https://new.ofcourse.io/home/page/19046ca72dec43aa8926bdde668e658a",
				see: true
			}
		},
		onLoad(option) {
			this.status = option.status?option.status:0
			this.getData()
			
		},
		onReachBottom() {
			console.log(this.list.length)
			if(this.total <= this.list.length) {
				return uni.showToast({
					icon: 'none',
					title:'已经加载全部了'
				})
			}
			this.pageNum = ++ this.pageNum
			this.getData()
		},
		methods:{
			getData:function(){
				var status = this.status
				var _self = this
				var userData = this.user();
				console.log(userData)
				
				if(status == 0){
					var obj = {
						'user':userData.code,
						pageNum: this.pageNum,
						pageSize: this.pageSize
						
					}
				}else{
					var obj = {
						'user':userData.code,
						"state":status,
						'states':'',
						pageNum: this.pageNum,
						pageSize: this.pageSize
					}
				}
				this.ajax({
					url: "/demand/pageData",
					data:obj
				}).then(res => {
					_self.list = _self.list.concat(res.data.records)
					_self.total = res.data.total
				});
			},
			changeItem:function(e){
				var status = e.currentTarget.dataset.id
				this.status = status
				this.list = [];
				this.getData()
				
			},
			room(orderid){
				console.log(orderid)
				this.see = false
				this.agoraroom ="https://new.ofcourse.io/home/page/19046ca72dec43aa8926bdde668e658a?agoraroom="+orderid
			},
			pay(orderid){
				console.log(orderid)
				this.ajax({
					url: '/pay/prepay',
					data: { 
						code:orderid,
						totalFee:100,
						body:'ces'
					}
				}).then(res => {
					var orderInfo=res.data;
					console.log( {
							"appid": orderInfo.appId,  // 微信开放平台 - 应用 - AppId，注意和微信小程序、公众号 AppId 可能不一致
							"noncestr":orderInfo.nonceStr, // 随机字符串
							"package": "Sign=WXPay",        // 固定值
							"partnerid": orderInfo.partnerId,      // 微信支付商户号
							"prepayid": orderInfo.prepayId, // 统一下单订单号 
							"timestamp": orderInfo.timeStamp,        // 时间戳（单位：秒）
							"sign": orderInfo.sign // 签名，这里用的 MD5 签名
						})
					
					uni.requestPayment({
						"provider": "wxpay", 
						"orderInfo": {
								"appid": orderInfo.appId,  // 微信开放平台 - 应用 - AppId，注意和微信小程序、公众号 AppId 可能不一致
								"noncestr":orderInfo.nonceStr, // 随机字符串
								"package": "Sign=WXPay",        // 固定值
								"partnerid": orderInfo.partnerId,      // 微信支付商户号
								"prepayid": orderInfo.prepayId, // 统一下单订单号 
								"timestamp": orderInfo.timeStamp,        // 时间戳（单位：秒）
								"sign": orderInfo.sign // 签名，这里用的 MD5 签名
							},
						success: (res) => {
							uni.showToast({
								title: "支付成功!",
								success:function(){
									uni.redirectTo({
										url:"/pages/parent/demand/index?status=0"
									})
								}
							})
						},
						fail: (res) => {
							uni.showToast({
								title: "支付失败!",
								success:function(){
									uni.redirectTo({
										url:"/pages/parent/demand/index?status=0"
									})
								}
							})
							
						},
						complete: () => {
							this.loading = false;
						}
					})
				})
			},
			changeState:function(code){
				var _self = this
				this.ajax({
					url: "/demand/update",
					data:{
						'code':code,
						"state":1
					}
				}).then(res => {
					uni.showToast({
						title: '操作成功',
						
					})
					_self.list = [];
					_self.getData()
				});
			},
			confirm:function(code,status){
				var _self = this
				var myDate = new Date();
				var dstr = myDate.getFullYear()+"-"+(myDate.getMonth()+1)+"-"+myDate.getDate()+" "+myDate.getHours()+":"+myDate.getMinutes()+":"+myDate.getSeconds()
				if(status){
					this.ajax({
						url: "/demand/update",
						data:{
							'code':code,
							"state":6,
							"parentDoneDate":dstr,
							"teacherDoneDate":dstr
						}
					}).then(res => {
						uni.showToast({
							title: '操作成功',
							
						})
						_self.list = [];
						_self.getData()
					});
				}else{
					this.ajax({
						url: "/demand/update",
						data:{
							'code':code,
							"state":6,
							"parentDoneDate":dstr,
							"teacherDoneDate":dstr
						}
					}).then(res => {
						uni.showToast({
							title: '操作成功',
							
						})
						_self.list = [];
						_self.getData()
					});
				}
				
			}
			
		}
		
	}
</script>

<style>
	body{
		background-color: #f0f0f0;
	}
	.content {
		font-size: 14px;
		color: #333;
		line-height: 1.5;
		height: 100%;
	}
	.fl{float: left;}
	.fr{float: right;}
	.clear{clear:both; overflow: hidden;}
	.header{height:36px; line-height: 36px; border: 1px solid #dcdcdc; border-radius: 8px; width: 98%; margin: 0 auto; font-size: 14px;  background-color: #f1f1f1; text-align: center;}
	.header picker{position: absolute; right: 0px; top: 0px;  height: 46px; width: 100%;}
	.header picker image{width: 20px; height: 20px; position: absolute; right: 10px; top: 10px;}
	.nav{clear: both; overflow: hidden;  background-color: rgb(0, 198, 93); border-top: 1px solid rgb(0, 198, 93);}
	.nav .nav-item{float: left; width: 20%; text-align: center; line-height: 30px; padding-top: 5px;  color: white; padding-bottom: 10px;}
	.nav .nav-item .sp{height: 4px; width: 20%; border-radius: 4px; background-color: white; margin: 0 auto;}
	
	.list .card{background-color: white; position: relative; width: 96%; border-radius: 6px; margin: 0 auto; box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.2); margin-top: 10px;}
	.list .card .tc image{float: left; width: 100rpx; height:100rpx; margin-right: 20rpx;}
	/* .list .card .tc .txt{ float: left; width: calc(100% - 100px);} */
	.list .card .tc .txt .h{font-size: 28rpx;}
	.list .card .tc .txt .p{font-size: 24rpx; width: 100%; display: flex; justify-content: space-between; margin-top: 20rpx; color: #999;}
	.list .card .tc{clear: both; overflow: hidden; padding: 12px; border-bottom: 1px solid #f9f9f9;}
	.list .card .tc .txt .p view{color: #333;}
	.list .card .tc .txt{position: relative; }
	.list .card .tc .txt .pos{position: absolute; top: 65px; right:3%; font-size: 28px; color: #2B85E4;}
	.primary{color: #2B85E4;}
	.list .card .bc{clear: both; overflow: hidden; padding:8px 12px; line-height: 30px; border-top: 1px solid #f9f9f9;}
	.list .card button{margin-right: 4px; }
	.button-sp-area{height: 30px;}
	.list .card .circle{width: 4px; height: 4px; border-radius: 50%; display: inline-block; background-color: red; position: absolute; right: 8px; top: 8px;}
	
	
	
</style>
