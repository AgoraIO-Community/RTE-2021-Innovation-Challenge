<template>
	<view class="lesson-index">
		<!-- <text>家长-优选课堂</text> -->
		<view class="search">
			<u-search placeholder="输入关键词直接查找课程" v-model="keyword" :action-style="actionStyle" @search="search"></u-search>
		</view>
		
		<!-- 宫格区域 -->
		<view class="grid">
			<u-grid :col="4" :border="false">
				<u-grid-item v-for="(v,i) in typeList.filter(e => e.grid)" :key="i" @click="handlerClickGrid(v)">
					<u-icon :name="v.icon" :size="46"></u-icon>
					<view class="grid-text">{{v.name}}</view>
				</u-grid-item>
			</u-grid>
		</view>
		
		<!-- 筛选 -->
		<u-sticky :enable="stickyEnable">
			<view class="filter-box">
				<view class="filter-content">
					<view class="filter-item dropdown" @click="handleShowFilter('distance')">
						距离最近
					</view>
					<view class="filter-item dropdown" @click="handleShowFilter('level')">
						{{levelStr === '不限' ? '学生年级' : levelStr || '学生年级'}}
					</view>
					<view class="filter-item dropdown text-overflow" @click="handleShowFilter('category')">
						{{typeStr === '不限' ? '教学课程' : typeStr || '教学课程'}}
					</view>
					<view class="filter-item dropdown text-overflow" @click="handleShowFilter('provide')">
						{{provideStr === '不限' ? '省份筛选' : provideStr || '省份筛选'}}
					</view>
					<view class="filter-item dropdown text-overflow" @click="isShowLesson = true">
						{{categoryStr === '不限' ? '学科筛选' : categoryStr || '学科筛选'}}
					</view>
				</view>

				<!-- 筛选列选择器 -->
				<u-select v-model="isShowFilter" :list="filterList" label-name="name" value-name="code" @confirm="handlerConfirm"></u-select>
				
				<!-- 学科筛选	 -->
				<u-select v-model="isShowLesson" mode="mutil-column-auto" :list="typeList" label-name="name" value-name="code" @confirm="handlerConfirmLesson"></u-select>
				
				<!-- 精准筛选弹窗 -->
				<u-popup v-model="isShowPopup" mode="right" width="560" :safe-area-inset-bottom="true">
					<view class="popup-content">
						<view class="popup-hd">
							<view class="popup-title">筛选</view>
				
							<view class="popup-item" v-for="(v,i) in 3" :key="i">
								<view class="popup-item-title">
									一级类目
								</view>
								<view class="popup-card">
									<view class="card-item card-item-active">
										不限
									</view>
									<view class="card-item" v-for="(v,i) in 7" :key="i">
										语文数学外语
									</view>
								</view>
							</view>
						</view>
						<view class="popup-btn" @click="isShowPopup = false">
							关闭
						</view>
					</view>
				
				</u-popup>
			</view>
		</u-sticky>
		<!-- 显示列表 -->

		<view class="lesson-box">
			<view class="lesson-item" v-for="(v,i) in lessonList" :key="i" @click="handleToDetail(v.code)">
				<!-- <view class="img-box">
					<u-image width="100%" height="170rpx" :src="imgPath + v.iconPath"></u-image>
				</view>
				<view class="item-express">
					<view class="item-title">
						{{v.title}}
					</view>
					<view class="item-desc">
						<view class="item-price">
							¥{{v.price}}
						</view>
						<view class="item-selling">
							已售{{v.sell}}件
						</view>
					</view>
					<view class="item-bd">
						<view class="item-teacher">
							老师：{{v.teacher_.name}}
						</view>
						<view class="item-abort">
							评论：暂无
						</view>
					</view>
				</view> -->
				
				<view class="d-flex top">
					<view class="title">{{v.categoryStr}}</view>
					<view class="nj">年级:{{v.price}}</view>
				</view>
				<view class="keyWord">关键词: {{v.keyword}}</view>
				<view class="keyWord">课时数量: {{v.levelstr}}</view>
				<view class="keyWord" @tap.stop="navTo(v.teacher_.code)">老师: {{v.teacher_.name}}</view>
				<view class="keyWord">位置: {{v.longitude||'暂无信息'}}</view>
			</view>
		</view>
		<!-- <u-back-top :scroll-top="scrollTop"></u-back-top> -->
		<u-tabbar :list="list" :mid-button="false" active-color="#00c65d"></u-tabbar>
	</view>
</template>

<script>
	const BASICICON = '/static/'
	
	export default {
		data() {
			return {
				list: getApp().globalData.parent,
				// 列选择器数据
				filterList: [],
				// 是否显示筛选列选择器
				isShowFilter: false,
				// 是否展示精准筛选弹窗
				isShowPopup: false,
				// 当前页
				pageNum: 1,
				// 每页显示数量
				pageSize: 10,
				// 课程数据列表
				lessonList: [],
				// 图片前缀
				imgPath: '',
				stickyEnable: false,
				// 总条数
				total: 0,
				selectType: '',
				// 搜索框右侧样式
				actionStyle: {
					width: '143rpx',
					height: '56rpx',
					lineHeight: '56rpx',
					border: '1rpx solid #fff',
					color: '#fff',
					borderRadius: '20rpx'
				},
				form: {
					level: '',
					category: '',
					provide: '',
					type: '',
				},
				distanceList: [],
				levelList: [],
				levelStr: '',
				typeList: [],
				typeStr: '',
				provideList: [],
				provideStr: '',
				categoryList: [],
				categoryStr: '',
				lessonStr:'',
				keyword: '',
				isShowLesson: false
			}
		},
		created() {
			this.imgPath = getApp().globalData.imgPath
		},
		mounted() {
			this.getLessonList()
			this.stickyEnable = true
			this.getAreaList()
			this.getCate()
			this.getLevelList()
			this.getLessonType()
			
		},
		onHide() {
			this.stickyEnable = false
		},
		onReachBottom() {
			// console.log(1)
			if(this.total === this.lessonList.length) {
				return uni.showToast({
					icon: 'none',
					title:'已经加载全部了'
				})
			}
			this.pageNum = ++ this.pageNum
			this.getLessonList()
		},
		methods: {
			// 展示筛选列选择器
			handleShowFilter(type) {
				console.log(type)
				this.filterList = []
				if (type === 'distance') {
					this.filterList = this.$u.deepClone(this.distanceList)
				}
				if(type === 'level') {
					this.filterList = this.$u.deepClone(this.levelList)
				}
				
				if(type === 'category') {
					this.filterList = this.$u.deepClone(this.categoryList)
				}
				
				if(type === 'provide') {
					this.filterList = this.$u.deepClone(this.provideList)
				}
				this.selectType = type
				this.isShowFilter = true
			},
			navTo(e){
				console.log(e)
				uni.navigateTo({
					url:"/pages/parent/teacherDetail/index?code="+e
				})
			},
			handlerConfirm(v) {
				this.lessonList = []
				switch(this.selectType) {
					case 'level':
							this.form.level = v[0].value
							this.levelStr = v[0].label
							break;
					case 'category': 
							this.form.type =  v[0].value
							this.typeStr = v[0].label
							break;
					case 'provide': 
							this.form.provide = v[0].label
							this.provideStr = v[0].label
							break;
				}
				this.getLessonList()
			},
			handlerConfirmLesson(v) {
				this.form.category = v[1].value
				this.categoryStr = v[1].label
				this.lessonList = []
				this.getLessonList()
			},
			// 获取字典数据
			getData(params) {
				return new Promise((resolve, reject) => {
					this.ajax({
						url: '/const/listData',
						data: params
					}).then(res => {
						resolve(res)
					})
				})
			},
			
			// 教学课程
			getCate() {
				this.getData({
					type: 4
				}).then(res => {
					const params = {
						value: '',
						label: '不限',
						name: '不限',
						code: ''
					}
					res.data.unshift(params)
					this.categoryList = res.data
				})
			},
			
			// 获取学科分类
			getLessonType() {
				const params = {
					type: 1
				}
				this.getData(params).then(res => {
					// res.data.forEach(e => {
						
					// })
					res.data.forEach(e => {
						e.icon = BASICICON + e.icon,
						e.grid = true
					})
					const params = {
						name: '不限',
						code: '',
						gird: false,
						children: [
							{
								name: '不限',
								code: ''
							}
						]
					}
					res.data.unshift(params)
					this.typeList = this.delChildren(res.data)
					
				})
			},
			
			// 年级
			getLevelList() {
				this.getData({type: 5}).then(res => {
					res.data.forEach(e => {
						e.value = e.code
						e.label = e.name
					})
					this.levelList = res.data
				})
			},
			
			// 区域
			getAreaList() {
				this.ajax({
					url: '/area/listData',
					method: 'post',
					data: {
						parent: 0
					}
				}).then(res => {
					this.provideList = res.data
				})
			},
			
			// 删除空的children
			delChildren(temp) {
				temp.forEach(e => {
					if (e.children && e.children.length !== 0) {
						this.delChildren(e.children)
					}
					if (e.children && e.children.length === 0) {
						delete e.children
					}
				})
				return temp
			},
			// 获取课程列表
			getLessonList() {
				const params = {
					pageNum: this.pageNum,
					pageSize: this.pageSize,
					...this.form,
					keyword: this.keyword,
					provide: this.form.provide === '不限' ? '' : this.form.provide
				}
				this.ajax({
					url: '/lesson/pageData',
					data: params
				}).then(res => {
					this.lessonList = this.lessonList.concat(res.data.records)
					this.total = res.data.total
				})
			},
			// 课程详情
			handleToDetail(code) {
				uni.navigateTo({
					url: `../lesssonDetail/index?code=${code}`
				})
			},
			search() {
				if(!this.keyword) return uni.showToast({
					icon: 'none',
					title: '请输入搜索内容'
				})
				this.lessonList = []
				this.getLessonList()
			},
			handlerClickGrid(v) {
				this.form.category = v.code
				this.categoryStr = v.name
				this.lessonList = []
				this.getLessonList()
			}
		}
	}
</script>


<style lang="scss" scoped>
	.d-flex{
		display: flex;
		flex-wrap: nowrap;
		align-items: center;
		justify-content: space-between;
		padding: 20rpx 0;
		.title{
			font-size: 30rpx;
			color: #333;
			font-weight: bold;
			flex: 1;
		}
		
	}
	.nj{
		font-size: 25rpx;
		color: #888;
	}
	.keyWord{
		padding-bottom: 14rpx;
		font-size: 25rpx;
		color: #888;
	}
	.lesson-index {
		::v-deep.u-mask,
		::v-deep.u-drawer {
			bottom: 100rpx;
		}
	}
	.search {
		padding: 30rpx 10rpx;
		// padding: 10rpx;
		background-color: #00c65d;
	}
	.filter-item {
		flex: 1;
		// max-width: 120rpx;
	}
	
	.text-overflow {
			overflow: hidden;
			text-overflow: ellipsis;
			white-space: nowrap;
	}

	.filter-box {
		height: 70rpx;
		line-height: 70rpx;
		font-size: 28rpx;

		.filter-content {
			display: flex;
			justify-content: space-between;
			padding: 0 10rpx;
			background-color: #fff;
			border-bottom: 2rpx solid #F1F1F1;

			.dropdown {
				position: relative;
				
				&::after {
					position: absolute;
					top: 40%;
					display: inline-block;
					content: '';
					margin-left: 5rpx;
					width: 12rpx;
					height: 12rpx;
					border-right: 2rpx solid #ccc;
					border-bottom: 2rpx solid #ccc;
					transform: rotate(45deg) translateY(-4rpx);
				}
			}
		}
	}

	.lesson-box {
		background-color: #f2f3f4;
		box-sizing: border-box;
		padding: 20rpx;
		.lesson-item {
			box-sizing: border-box;
			padding: 20rpx;
			background-color: #fff;
			margin-bottom: 20rpx;
			border-radius: 20rpx;
			box-shadow: 0 1rpx 2rpx rgba(0,0,0,.2);

			.img-box {
				margin-right: 20rpx;
				width: 170rpx;
				height: 170rpx;
				background-color: #000000;

			}

			.item-express {
				display: flex;
				flex-direction: column;

				.item-title {
					font-weight: 600;
					font-size: 30rpx;
				}

				.item-desc {
					display: flex;
					margin-top: 10rpx;
					.item-price {
						width: 170rpx;
						color: red;
						font-size: 28rpx;
					}

					.item-selling {
						color: #ccc;
					}
				}

				.item-bd {
					display: flex;
					margin-top: 20rpx;
					color: #ccc;

					.item-teacher {
						width: 270rpx;
					}
				}
			}
		}
	}
	
	.popup-content {
		display: flex;
		flex-direction: column;
		height: 100%;
	
		.popup-hd {
			flex: 1;
		}
	
		.popup-btn {
			height: 70rpx;
			line-height: 70rpx;
			text-align: center;
			color: #999;
			background-color: #eee;
		}
	}
	
	.popup-title {
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		border-bottom: 1rpx solid #f2f3f4;
	}
	
	.popup-item {
		padding: 0 10rpx;
		min-height: 322rpx;
	}
	
	.popup-item-title {
		height: 70rpx;
		line-height: 70rpx;
		color: #000;
		font-size: 30rpx;
		font-weight: 600;
	}
	
	.popup-card {
		display: flex;
		flex-wrap: wrap;
	}
	
	.card-item {
		margin-right: 12rpx;
		margin-bottom: 20rpx;
		width: 160rpx;
		height: 64rpx;
		line-height: 64rpx;
		text-align: center;
		background-color: #f6f6f6;
		border: 1rpx solid #f6f6f6;
		border-radius: 10rpx;
	}
	
	.card-item-active {
		border: 1rpx solid #00c65d;
		background-color: #cff4e0;
	}
</style>
