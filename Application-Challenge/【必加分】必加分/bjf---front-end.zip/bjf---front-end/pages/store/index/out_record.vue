<template>
	<view class="content">
		<view class="list">
			<view class="li" @click="$common.jumpurl('/pages/store/index/out_detail')">
				<view class="icon">微</view>
				<view class="txt">
					<view class="p">
						<text>2021-12-21 12:12:21</text>
						<text class="c">已到账</text>
					</view>
					<view class="p">
						<text>微信：50元</text>
						<text class="b">详情</text>
					</view>
					
				</view>
			</view>
			<view class="li" @click="$common.jumpurl('/pages/store/index/out_detail')">
				<view class="icon">支</view>
				<view class="txt">
					<view class="p">
						<text>2021-12-21 12:12:21</text>
						<text class="c">已到账</text>
					</view>
					<view class="p">
						<text>支付宝：50元</text>
						<text class="b">详情</text>
					</view>
					
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods:{
			
		}
		
	}
</script>
<style>
	.list .li{padding: 28rpx 3%; border-bottom: 1rpx solid #f1f1f1; clear: both; overflow: hidden;}
	.list .li .icon{width: 100rpx; height: 100rpx; margin-right: 20rpx; border-radius: 10rpx; float: left; background-color: #18B566; text-align: center; line-height: 100rpx; color: white; font-size: 32rpx;}
	.list .li .txt{font-size: 26rpx; line-height: 50rpx; color: #333; float: left; width: calc(100% - 120rpx); }
	.list .li .txt .p{display: flex; justify-content: space-between;}
	.c{color: #19BE6B;}
	.b{color: #999;}
</style>
