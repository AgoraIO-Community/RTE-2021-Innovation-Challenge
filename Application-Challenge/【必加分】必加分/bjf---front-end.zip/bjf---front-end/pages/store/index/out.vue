<template>
	<view class="content">
		<view class="pack">
			<view class="t">
				<view class="p">
					待提现金额
				</view>
				<view class="e">
					500元
				</view>
				<u-button type="primary" size="mini" @click="$common.jumpurl('/pages/store/index/out_record')">提现记录</u-button>
			</view>
		</view>
		<view class="space"></view>
		<view class="pack">
			<view class="t">
				<view class="p">
					请选择提现方式
				</view>
				<view class="n">
					<view class="btn">
						<u-icon name="weixin-fill" color="#2979ff" size="36"></u-icon>
						微信
					</view>
					<view class="btn">
						<u-icon name="zhifubao" color="#2979ff" size="36"></u-icon>
						支付宝
					</view>
				</view>
			</view>
		</view>
		<view class="space"></view>
		<view class="pack">
			<view class="t">
				<view class="p">
					请选择提现金额
				</view>
				<view class="n">
					<view class="btn">
						50
					</view>
					<view class="btn">
						100
					</view>
					<view class="btn">
						200
					</view>
					<view class="btn">
						300
					</view>
				</view>
			</view>
		</view>
		
		<view class="space"></view>
		<view class="pack">
			<view class="t">
				<view class="p">
					注意事项
				</view>
				<view class="tn">
					Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.
					Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.
					
				</view>
			</view>
		</view>
		<u-button type="primary" class="fixbtn">提现</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods:{
			
		}
		
	}
</script>
<style>
	.space{height: 16rpx; background-color: #f1f1f1;}
	.pack{ background-color: white;  border-radius: 10rpx; padding: 20rpx 3%; }
	.pack .t .p{font-size: 28rpx; padding-left: 20rpx; border-left:4rpx solid #18B566}
	.pack .t .e{font-size: 40rpx; color: #18B566; margin-top:18rpx;}
	.pack .t{position: relative;}
	.pack button{position: absolute; right: 0px; top: 26rpx;}
	.pack .n .btn{float: left; width: 45%; margin: 0 2.5%; margin-bottom: 20rpx; border-radius: 8rpx; border:1rpx solid #999; text-align: center; padding: 20rpx 0px; font-size: 30rpx;}
	.pack .n .btn .u-icon{margin-right: 10rpx;}
	.pack .n{clear: both; overflow: hidden; margin-top: 28rpx;}
	.pack .tn{font-size: 26rpx; line-height: 1.5; margin-top: 18rpx;}
	.fixbtn{position: fixed; bottom: 0; left: 0; width: 100%; border-radius: 0;}
	.content{padding-bottom: 44px;}
</style>
