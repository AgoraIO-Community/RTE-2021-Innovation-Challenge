<template>
	<view class="content">
		<view class="big">
			<view class="cir">微</view>
			<view class="ht">微信提现</view>
			<view class="pt">50元</view>
		</view>
		<view class="space"></view>
		<view class="p">
			<text>实际到账</text>
			<text >50元</text>
		</view>
		<view class="p">
			<text>申请时间</text>
			<text>2021-12-21 12:12:21</text>
		</view>
		<view class="p">
			<text>到账时间</text>
			<text>2021-12-21 12:12:21</text>
		</view>
		<view class="p">
			<text>到账状态</text>
			<text class="c">已到账</text>
		</view>
		

	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods:{
			
		}
		
	}
</script>
<style>
	.big{text-align: center; font-size: 34rpx; padding-bottom: 30rpx;}
	.big .cir{width: 100rpx; height: 100rpx; border-radius: 50%; background-color: #19BE6B; text-align: center; line-height: 100rpx; margin:0rpx auto; margin-top: 30rpx; color: white; font-size: 34rpx;}
	.space{height: 8rpx; background-color: #f1f1f1;}
	.ht{margin: 12rpx 0px; font-size: 30rpx;}
	.pt{font-weight: 700;}
	.p{display: flex; justify-content: space-between; font-size: 24rpx; padding: 28rpx 3%; border-bottom: 1rpx solid #f1f1f1; color: #999;}
	.c{color: #19BE6B;}
	.b{color: #999;}
</style>
