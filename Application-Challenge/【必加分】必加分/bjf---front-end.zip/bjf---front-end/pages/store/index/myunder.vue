<template>
	<view>
		<view class="user">
			<view class="icon">上司<u-tag :text="storeData.typeStr" type="success" size="mini"/></view>
			<view class="txt">
				<view class="p">{{storeData.name}} </view>
				<view class="t">到期时间：{{storeData.expire}}</view>
				<view class="t">已获取收益：￥{{storeData.amount}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	
	export default {
		data() {
			return {
				parentcode:'',
				storeData:{}
			}
		},
		onLoad(options){
			console.log(options)
			this.parentcode = options.id!='undefined'?options.id:'deabf070793c42e5be437d84475a264d'
		},
		methods:{
			
		},
		mounted() {
			var _self = this
			this.ajax({
				url: "distribution/findData",
				data:{
					user:_self.parentcode
				}
			}).then(res => {
				_self.storeData = res.data
			});
		}
		
	}
</script>
<style>
	.user image{float: left; width: 100rpx; height: 100rpx; border-radius: 50%; margin-right: 20rpx; border-radius: 50%; border: 6rpx solid rgba(255,255,255,0.4);}
	.user .p{font-size: 38rpx; margin-top: 10rpx;}
	.user .t{font-size: 28rpx; color: #999; margin-top: 8rpx; color: white;}
	.user{clear: both; overflow: hidden; color: white; background: rgb(0, 198, 93); padding:30rpx 3%; padding-bottom: 100rpx;}
	.user .txt{position: relative; text-align: center;}
	.user .txt button{position:absolute; right: 0px; top: 20rpx; }
	.icon{width:120rpx; height: 120rpx; position: relative; margin: 0 auto; background-color: white; border-radius: 50%; line-height: 120rpx; text-align: center; color: #333;}
	.icon .u-tag{position: absolute; bottom: 0px; right:-40px;}
</style>
