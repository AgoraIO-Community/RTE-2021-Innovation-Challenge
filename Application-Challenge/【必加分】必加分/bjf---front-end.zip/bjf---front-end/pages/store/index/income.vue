<template>
	<view>
		<view class="pack">
			<view class="t">
				<view class="p">
					待提现金额
				</view>
				<view class="e">
					{{storeData.money}}元
				</view>
				<u-button type="primary" size="mini" @click="$common.jumpurl('/pages/store/index/out')">提现</u-button>
			</view>
			<view class="b">
				<view class="col">
					<view class="p">今日日收入</view>
					<view class="m">20元</view>
				</view>
				<view class="col">
					<view class="p">累计收入</view>
					<view class="m">{{storeData.amount}}元</view>
				</view>
			</view>
		</view>
		<view class="space"></view>
		<view class="list">
			<view class="li" v-for="(item,index) in list">
				<view class="t">
					<text class="p_1">{{item.userName}}</text><text class="p_2">{{item.money}}元</text>
				</view>
				<view class="b">
					<text class="p_3">{{item.content}}</text><text class="p_3">{{item.createTime}}</text>
				</view>
				
			</view>
			
			<view class="txt">只显示最近3天的数据</view>
			
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list:[],
				storeData:{}
			}
		},
		methods:{
			
		},
		mounted() {
			var _self = this
			this.userData = this.user();
			this.ajax({
				url: "distribution/money/listData",
				data:{
					user:this.userData.code
				}
			}).then(res => {
				_self.list = res.data
			});
			
			this.ajax({
				url: "distribution/findData",
				data:{
					user:this.userData.code
				}
			}).then(res => {
				_self.storeData = res.data
			});
		}
		
	}
</script>
<style>
	.space{height: 16rpx; background-color: #f1f1f1;}
	.pack{ background-color: white;  border-radius: 10rpx; padding: 20rpx 3%; }
	.pack .t .p{font-size: 30rpx;}
	.pack .t .e{font-size: 40rpx; color: #18B566; margin-top:18rpx;}
	.pack .t{position: relative;}
	.pack button{position: absolute; right: 0px; top: 26rpx;}
	.pack .b .col{float: left; width: 50%; text-align: center; border-right: 1rpx solid #333;}
	.pack .b .col:last-child{border:0}
	.pack .b{clear: both; overflow: hidden; padding-top:40rpx;}
	.list .li{padding: 28rpx 3%;}
	.list .li .t,.list .li .b{display: flex; justify-content: space-between;}
	.list .li .p_1{font-size: 30rpx; }
	.list .li .p_2{font-size: 40rpx; color: #19BE6B;}
	.list .li .p_3{font-size: 24rpx; color: #666;}
	.list .li .b{margin-top: 6rpx;}
	.list .li{border-bottom: 1rpx solid #f1f1f1;}
	.txt{font-size: 22rpx; color: #999; text-align: center; margin-top: 20rpx;}
</style>
