<template>
	<view>
		<view class="user" v-if="storeData.name">
			<image :src="iconPath"></image>
			<view class="txt">
				<view class="p">{{storeData.name}} <u-tag :text="storeData.typeStr" type="success" size="mini"/>
				<u-tag :text="storeData.levelStr" type="success" size="mini"/></view>
				<view class="t">到期时间：{{storeData.expire || '待申请'}}</view>
				<u-button type="info" size="mini" v-if="storeData.expire">续费</u-button>
			</view>
		</view>
		<view class="user" v-if="!storeData.name" style="font-size: 20px; text-align: center;">
			<!-- <view class="t" style="font-size: 20px; text-align: center;">分销待申请</view> -->
			<u-button type="primary"  size="mini" @click="$common.jumpurl('/pages/store/apply/index')">点击申请分销</u-button>
		</view>
		<view class="pack">
			<view class="t">
				<view class="p">
					待提现金额
				</view>
				<view class="e" v-if="storeData.money == ''">
					{{storeData.money}}元
				</view>
				<view class="e" v-if="storeData.money != ''">
					-
				</view>
				<u-button type="primary" v-if="storeData.expire" size="mini" @click="$common.jumpurl('/pages/store/index/out')">提现</u-button>
			</view>
			<view class="b">
				<view class="col">
					<view class="p">今日日收入</view>
					
					<view class="m" v-if="storeData.todayAmount == ''">{{storeData.todayAmount}}元</view>
					<view class="m" v-if="storeData.todayAmount != ''">-</view>
				</view>
				<view class="col">
					<view class="p">累计收入</view>
					<view class="m" v-if="storeData.amount == ''">{{storeData.amount}}元</view>
					<view class="m" v-if="storeData.amount != ''">-</view>
					
				</view>
			</view>
		</view>
		<view class="list">
			<view class="col" @click="$common.jumpurl('/pages/store/index/income')">
				<image src="../../../static/icon1.png" mode="widthFix"></image>
				<view class="p">收益统计</view>
			</view>
			<view class="col" @click="$common.jumpurl('/pages/store/index/poster')">
				<image src="../../../static/icon2.png" mode="widthFix"></image>
				<view class="p">我的海报</view>
			</view>
			<view class="col" @click="$common.jumpurl('/pages/store/index/myparent?id='+storeData.parentuser)">
				<image src="../../../static/icon3.png" mode="widthFix"></image>
				<view class="p">我的上司</view>
			</view>
			<view class="col" @click="$common.jumpurl('/pages/store/index/myunder?id='+storeData.parentuser)">
				<image src="../../../static/icon3.png" mode="widthFix"></image>
				<view class="p">我的会员</view>
			</view>
			<view class="col" @click="$common.jumpurl('/pages/store/apply/index')" v-if="storeData.type < 0 || !storeData.type">
				<image src="../../../static/icon4.png" mode="widthFix"></image>
				<view class="p">网络代理</view>
			</view>
			<view class="col" @click="$common.jumpurl('/pages/store/apply/school')" v-if="storeData.type <1 || !storeData.type">
				<image src="../../../static/icon5.png" mode="widthFix"></image>
				<view class="p">高校代理</view>
			</view>
			<view class="col" @click="$common.jumpurl('/pages/store/apply/city')" v-if="storeData.type < 2 || !storeData.type">
				<image src="../../../static/icon4.png" mode="widthFix"></image>
				<view class="p">城市代理</view>
			</view>
			
		</view>
	</view>
</template>

<script>
	
	export default {
		data() {
			return {
				userData:{},
				storeData:{},
				iconPath:''
			}
		},
		onLoad(){
			console.log(this.storeData)
		},
		methods:{
			
		},
		mounted() {
			var _self = this
			this.userData = this.user();
			this.iconPath = getApp().globalData.baseUrl + "/attach/download/" + this.userData.iconPath
			this.ajax({
				url: "distribution/findData",
				data:{
					user:this.userData.code
				}
			}).then(res => {
				_self.storeData = res.data
			});
		}
		
	}
</script>
<style>
	.user image{float: left; width: 100rpx; height: 100rpx; border-radius: 50%; margin-right: 20rpx; border-radius: 50%; border: 6rpx solid rgba(255,255,255,0.4);}
	.user .p{font-size: 26rpx; margin-top: 10rpx;}
	.user .t{font-size: 22rpx; color: #999; margin-top: 8rpx; color: white;}
	.user{clear: both; overflow: hidden; color: white; background: rgb(0, 198, 93); padding:30rpx 3%; padding-bottom: 100rpx;}
	.user .txt{float: left; width: calc(100% - 132rpx); position: relative;}
	.user .txt button{position:absolute; right: 0px; top: 20rpx; }
	.pack{width: 90%; margin: 0 auto; background-color: white; margin-top: -60rpx; border-radius: 10rpx; padding: 20rpx 3%; box-shadow: 2px 2px 6px rgba(0,0,0,0.1);}
	.pack .t .p{font-size: 30rpx;}
	.pack .t .e{font-size: 40rpx; color: #18B566; margin-top:18rpx;}
	.pack .t{position: relative;}
	.pack button{position: absolute; right: 0px; top: 26rpx;}
	.pack .b .col{float: left; width: 50%; text-align: center; border-right: 1rpx solid #333;}
	.pack .b .col:last-child{border:0}
	.pack .b{clear: both; overflow: hidden; padding-top:40rpx;}
	.list .col{float: left; width: 33.333%; text-align: center; margin-bottom: 40rpx;}
	.list .col image{width: 30%; margin-bottom: 10rpx;}
	.list{margin-top: 80rpx;}
	.u-tag{margin-left:8rpx}
</style>
