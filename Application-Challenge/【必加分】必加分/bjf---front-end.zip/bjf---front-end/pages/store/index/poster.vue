<template>
	<view>
		<image src="../../../static/img.png" mode="widthFix"></image>
		<u-button type="primary" size="default" @click="savePhoto">保存</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				img:'crm.shtcyun.com/formwork.xlsx',
				url:"https://img-blog.csdnimg.cn/20200408135811398.png",
				userData:{}
			}
		},
		methods:{
			savePhoto:function(){
				var url = this.url
				uni.downloadFile({
					url:  "/distribution/poster/"+this.userData.code, // 这里是你接口地址 若要传参 直接 url拼接参数即可
					header:{
						'Authentication': 'bearer '+this.userData.token
					},
					methods: 'GET',
					success: (res) => {
						console.log(res,'res')
						var tempFilePath = res.tempFilePath; // 这里拿到后端返回的图片路径
						uni.saveImageToPhotosAlbum({  // 然后调用这个方法
							filePath: tempFilePath,
							success : (res) => {
								uni.showToast({title : '图片已保存'})
							}
						})
					},
					fail: () => {
						uni.hideLoading();
					}
				});
				
			}
		},
		mounted(){
			var _self = this
			var userData = this.userData = this.user();
			this.ajax({
				url: "/distribution/poster/"+userData.code,
				data:{}
			}).then(res => {
				console.log(1)
				// _self.img = res.data
			});
		}
		
	}
</script>
<style>
	image{width: 80%; display: block; margin: 50rpx auto; margin-top: 50rpx;}
	button{margin: 0 auto; display: block; width: 80%;}
</style>
