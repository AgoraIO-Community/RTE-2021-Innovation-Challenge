<template>
	<view class="u-p-30">
		<u-form :model="formData" :rules="rules" ref="uForm" :errorType="['toast','border-bottom']">
			<u-form-item label="姓名" label-width="150" prop="name" required>
				<u-input placeholder="请输入姓名" type="text" v-model="formData.name"></u-input>
			</u-form-item>
			<u-form-item label="职业" label-width="150" prop="position" required>
				<u-input placeholder="请输入职业" type="text" v-model="formData.position"></u-input>
			</u-form-item>
			<u-form-item label="手机号" label-width="150" prop="phone" required>
				<u-input placeholder="请输入手机号" type="text" v-model="formData.phone"></u-input>
			</u-form-item>
			<u-form-item label-position="top" label="身份证正面" required>
				<u-upload ref="uUpload" max-count="1" width="160" height="160" :action="upLoadAction" :fileList="upLoadFileList"
				 :show-progress="false" @on-success="handleSuccessIdcardLPath" @on-remove="fileRemove">
				</u-upload>
			</u-form-item>
			<u-form-item label-position="top" label="身份证反面" required>
				<u-upload ref="uUpload" max-count="1" width="160" height="160" :action="upLoadAction1" :fileList="upLoadFileList1"
				 :show-progress="false"  @on-success="handleSuccessIdcardRPath" @on-remove="fileRemove1">
				</u-upload>
			</u-form-item>
		</u-form>
		<u-button type="success" @click="submit" style="margin-top: 30rpx;" :loading="loading">保存</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				loading: false,
				upLoadAction: "",
				upLoadFileList: [],
				upLoadAction1: "",
				upLoadFileList1: [],
				formData: {},
				rules: {
					name: [{
						required: true,
						message: "请输入姓名",
						trigger: ["blur", "change"]
					}],
					position: [{
						required: true,
						message: "请选择职位",
						trigger: ["blur", "change"]
					}],
					phone: [{
						required: true,
						message: "请选择手机号",
						trigger: ["blur", "change"]
					}]
					
				}
			}
		},
		onReady() {
			this.user()
			this.$refs.uForm.setRules(this.rules);
			this.formData = {
				
				...this.formData,
				...this.user()
			};
			this.upLoadAction = getApp().globalData.baseUrl + "/attach/upload";
			this.upLoadAction1 = getApp().globalData.baseUrl + "/attach/upload";
		},
		methods: {
			fileRemove() {
				this.formData.iconPath = "";
			},
			handleSuccessIdcardLPath(data, index, lists, name) {
				console.log(data, index, lists, name)
				this.formData.idcardL = data.data.code
			},
			handleSuccessIdcardRPath(data, index, lists, name) {
				console.log(data, index, lists, name)
				this.formData.idcardR = data.data.code
			},
			submit() {
				this.formData.type = 0
				this.formData.user = ''
				this.formData.duty = 1
				this.$refs.uForm.validate(valid => {
					if (valid) {
						this.ajax({
							url: "distribution/insert",
							data: this.formData
						}).then(res => {
							console.log(res)
						});
					}
				});
			}
		}
	}
</script>

<style>
</style>
