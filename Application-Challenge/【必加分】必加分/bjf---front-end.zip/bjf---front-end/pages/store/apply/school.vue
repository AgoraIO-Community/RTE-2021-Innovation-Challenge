<template>
	<view class="u-p-30">
		<u-form :model="formData" :rules="rules" ref="uForm" :errorType="['toast','border-bottom']">
			<u-form-item label="高校名称" label-width="150" prop="school" required>
				<u-input placeholder="请输入高校名称" type="text" v-model="formData.school"></u-input>
			</u-form-item>
			
			<u-form-item label-position="top" label="高校证明" required>
				<u-upload ref="uUpload" max-count="1" width="160" height="160" :action="upLoadAction" :fileList="upLoadFileList"
				 :show-progress="false" @on-remove="fileRemove">
				</u-upload>
			</u-form-item>
		</u-form>
		<u-button type="success" @click="submit" style="margin-top: 30rpx;" :loading="loading">保存</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				loading: false,
				upLoadAction: "",
				upLoadFileList: [],
				formData: {},
				userData:{},
				rules: {
					school: [{
						required: true,
						message: "请输入高校名称",
						trigger: ["blur", "change"]
					}],
					
				}
			}
		},
		onReady() {
			this.userData = this.user()
			this.$refs.uForm.setRules(this.rules);
			this.formData = {
				...this.formData
				
			};
			if (null != this.formData.iconPath)
				this.upLoadFileList.push({
					url: getApp().globalData.baseUrl + "/attach/download/" + this.formData.iconPath
				});
			this.upLoadAction = getApp().globalData.baseUrl + "/attach/upload";
		},
		methods: {
			fileRemove() {
				this.formData.iconPath = "";
			},
			submit() {
				this.$refs.uUpload.lists.forEach(i => {
					if (null != i.response)
						this.formData.iconPath = i.response.data.code;
				});
				console.log(this.formData)
				this.formData['type'] = "1"
				this.formData['code'] = "9fdeb6024b7546a988e3826e9476a092"
				this.$refs.uForm.validate(valid => {
					if (valid) {
						this.ajax({
							url: "/distribution/update",
							data: this.formData
						}).then(res => {
							console.log(res)
						});
					}
				});
			}
		}
	}
</script>

<style>
</style>
