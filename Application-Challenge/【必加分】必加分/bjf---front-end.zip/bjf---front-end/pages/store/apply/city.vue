<template>
	<view class="u-p-30">
		<u-form :model="formData" :rules="rules" ref="uForm" :errorType="['toast','border-bottom']">
			<u-form-item label="所在地区" label-width="150" prop="area">
				<u-input placeholder="请选择地区" type="select" v-model="formData.area" @click="placeFlag=true"></u-input>
				<u-picker v-model="placeFlag" mode="region" @confirm="placeChoose"></u-picker>
			</u-form-item>
			
			
		</u-form>
		<u-button type="success" @click="submit" style="margin-top: 30rpx;" :loading="loading">保存</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				loading: false,
				upLoadAction: "",
				upLoadFileList: [],
				formData: {},
				placeFlag: false,
				rules: {
					name: [{
						required: true,
						message: "请输入姓名",
						trigger: ["blur", "change"]
					}],
					position: [{
						required: true,
						message: "请选择职位",
						trigger: ["blur", "change"]
					}],
					phone: [{
						required: true,
						message: "请选择手机号",
						trigger: ["blur", "change"]
					}],
					phone: [{
						required: true,
						message: "请选择手机号",
						trigger: ["blur", "change"]
					}]
				}
			}
		},
		onReady() {
			this.$refs.uForm.setRules(this.rules);
			this.formData = {
				...this.formData
			};
			
		},
		methods: {
			fileRemove() {
				this.formData.iconPath = "";
			},
			submit() {
				
				console.log(this.formData)
				this.formData['type'] = "2"
				this.formData['code'] = "9fdeb6024b7546a988e3826e9476a092"
				this.$refs.uForm.validate(valid => {
					if (valid) {
						this.ajax({
							url: "/distribution/update",
							data: this.formData
						}).then(res => {
							console.log(res)
						});
					}
				});
			},
			placeChoose(e) {
				let area = e.province.label + "-" + e.city.label + "-" + e.area.label;
				this.formData.area = area;
			}
		}
	}
</script>
