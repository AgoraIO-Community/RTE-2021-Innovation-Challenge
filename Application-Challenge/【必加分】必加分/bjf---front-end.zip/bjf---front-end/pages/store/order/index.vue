<template>
	 <view class="content">
		
		 <view class="nav">
		 	<view class="nav-item" @click="changeItem" data-id="1">
		 		待付款
		 		<view class="sp" v-if="status == 1"></view>
		 	</view>
		 	<view class="nav-item" @click="changeItem" data-id="2">
		 		待上课
		 		<view class="sp" v-if="status == 2"></view>
		 	</view>
		 	<view class="nav-item" @click="changeItem" data-id="3">
				评价
		 		<view class="sp" v-if="status == 3"></view>
		 	</view>
		 </view>
		<view class="list">
			<view class="card" >
				<view class="tc" @click="$common.jumpurl('/pages/store/order/order_detail')">
					<image src="../../../static/logo.png"></image>
					<view class="txt">
						<view class="h">编程-java基础</view>
						<view class="p">
							<text>￥1000</text>
							<text>距离33.33km</text>
							<text>王老师</text>
						</view>
					</view>
				</view>
				<view class="mc" @click="$common.jumpurl('/pages/store/order/order_detail')">
					
					<view class="p"><u-icon name="map" color="#333" size="28" class="uicon"></u-icon>长沙徐汇区三西路888号</view>
					<view class="p"><u-icon name="bag" color="#333" size="28" class="uicon"></u-icon>上课时间：2021年4月11日13:07:41</view>
				</view>
				<view class="bc">
					<view class="fr">
						<u-button size="mini" @click="$common.jumpurl('/pages/store/order/refund')">申请退款</u-button>
						<u-button size="mini" @click="$common.jumpurl('/pages/store/order/order_detail')">详情</u-button>
						<u-button size="mini">付款</u-button>
						
					</view>
				</view>
				
			</view>
			<view class="card" >
				<view class="tc" >
					<image src="../../../static/logo.png"></image>
					<view class="txt">
						<view class="h">编程-java基础</view>
						<view class="p">
							<text>￥1000</text>
							<text>距离33.33km</text>
							<text>王老师</text>
						</view>
					</view>
				</view>
				<view class="mc" >
					
					<view class="p"><u-icon name="map" color="#333" size="28" class="uicon"></u-icon>长沙徐汇区三西路888号</view>
					<view class="p"><u-icon name="bag" color="#333" size="28" class="uicon"></u-icon>上课时间：2021年4月11日13:07:41</view>
				</view>
				<view class="bc">
					<view class="fr">
						<u-button size="mini">申请退款</u-button>
						<u-button size="mini">详情</u-button>
						<u-button size="mini">付款</u-button>
						<u-button size="mini">立即评价</u-button>
						
					</view>
				</view>
				
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				status :1 
				 
			}
		},
		onLoad(option) {
			
			
		},
		methods:{
			changeItem:function(e){
				var status = e.currentTarget.dataset.id
				this.status = status
				
			}
		}
		
	}
</script>

<style>
	body{
		background-color: #f0f0f0;
	}
	.content {
		font-size: 14px;
		color: #333;
		line-height: 1.5;
		height: 100%;
	}
	.fl{float: left;}
	.fr{float: right;}
	.clear{clear:both; overflow: hidden;}
	.header{height:36px; line-height: 36px; border: 1px solid #dcdcdc; border-radius: 8px; width: 98%; margin: 0 auto; font-size: 14px;  background-color: #f1f1f1; text-align: center;}
	.header picker{position: absolute; right: 0px; top: 0px;  height: 46px; width: 100%;}
	.header picker image{width: 20px; height: 20px; position: absolute; right: 10px; top: 10px;}
	.nav{clear: both; overflow: hidden;  background-color: rgb(0, 198, 93); border-top: 1px solid rgb(0, 198, 93);}
	.nav .nav-item{float: left; width: 33.333%; text-align: center; line-height: 30px; padding-top: 5px;  color: white; padding-bottom: 10px;}
	.nav .nav-item .sp{height: 4px; width: 20%; border-radius: 4px; background-color: white; margin: 0 auto;}
	
	.list .card{background-color: white; position: relative; width: 96%; border-radius: 6px; margin: 0 auto; box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.2); margin-top: 10px;}
	.list .card .tc image{float: left; width: 100rpx; height:100rpx; margin-right: 20rpx;}
	.list .card .tc .txt{ float: left; width: calc(100% - 100px);}
	.list .card .tc .txt .h{font-size: 28rpx;}
	.list .card .tc .txt .p{font-size: 24rpx; display: flex; justify-content: space-between; margin-top: 20rpx; color: #999;}
	.list .card .tc{clear: both; overflow: hidden; padding: 12px; border-bottom: 1px solid #f9f9f9;}
	.list .card .mc{ padding: 12px;}
	.list .card .mc .p{font-size: 14px; color: #666; line-height: 40rpx;  margin-bottom: 10rpx; clear: both; overflow: hidden;}
	.list .card .mc .p .uicon{margin-right: 5rpx;}
	.list .card .bc{clear: both; overflow: hidden; padding:8px 12px; line-height: 30px; border-top: 1px solid #f9f9f9;}
	.list .card button{margin-right: 4px; }
	.button-sp-area{height: 30px;}
	.list .card .circle{width: 4px; height: 4px; border-radius: 50%; display: inline-block; background-color: red; position: absolute; right: 8px; top: 8px;}
	
	
	
</style>
