let common = {
	'jumpurl':jumpurl
}

function jumpurl(url){
	uni.navigateTo({
		url:url
	})
}

export default common