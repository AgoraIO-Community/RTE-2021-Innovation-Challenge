import Vue from 'vue'
import App from './App'

import uView from "uview-ui";
import { VueJsonp } from 'vue-jsonp/dist'

import common from './common'
Vue.use(VueJsonp)

Vue.use(uView);

Vue.config.productionTip = false


Vue.prototype.$common = common

App.mpType = 'app'

const app = new Vue({
	...App
})
app.$mount()

/**
 * @param {string} url 请求地址 
 * @param {string} method 请求方法 
 * @param {object} data 请求参数数据 
 */
const ajax = ({
	url,
	method = "post",
	data,
	showMessage = true
}, last = () => {}) => {
	const user = uni.getStorageSync('user') ? JSON.parse(uni.getStorageSync('user')) : ''
	return new Promise((resolve, reject) => {
		uni.request({
			url: getApp().globalData.baseUrl + url,
			//url: "http://127.0.0.1:8085/" + url,
			method,
			data,
			header: {
				'Authentication': user.token ? `bearer ${user.token}` : ''
			},
			success: (res) => {
				// console.log(res);
				if (res.data.code == "4000") {
					uni.showModal({
						title: "登录信息失效，请重新登录",
						showCancel: false,
						success: () => {
							uni.reLaunch({
								url: "/pages/login/login"
							})
						}
					})
				} else if (res.data.code != "0000") {
					if (showMessage)
						tips({
							title: res.data.message
						});
					reject(res.data);
				} else {
					resolve(res.data);
				}
			},
			fail: (e) => {
				console.log(e);
				reject(null == e.data ? {
					message: "网络错误"
				} : e.data)
			},
			complete() {
				last();
			}
		})
	})
}

Vue.prototype.ajax = ajax;

const user = () => {
	
	return JSON.parse(uni.getStorageSync("user"));
}

Vue.prototype.user = user;

const tips = ({
	title,
	duration = 2000,
	icon = "none",
	success = () => {}
}) => {
	uni.showToast({
		title,
		duration,
		icon,
		success
	})
}

Vue.prototype.tips = tips;
