<script>
	export default {
		globalData: {
			teacher: [{
					iconPath: "home",
					selectedIconPath: "home-fill",
					text: "老师接单",
					customIcon: false,
					pagePath: "/pages/teacher/accept/accept"
				},
				{
					iconPath: "photo",
					selectedIconPath: "photo-fill",
					text: "发布课堂",
					customIcon: false,
					pagePath: "/pages/teacher/lesson/lesson"
				},
				{
					iconPath: "file-text",
					selectedIconPath: "file-text-fill",
					text: "在线订单",
					customIcon: false,
					pagePath: "/pages/teacher/order/order"
				},
				{
					iconPath: "play-right",
					selectedIconPath: "play-right-fill",
					text: "在线课堂",
					customIcon: false,
					pagePath: "/pages/teacher/online/online"
				},
				{
					iconPath: "account",
					selectedIconPath: "account-fill",
					text: "我的页面",
					customIcon: false,
					pagePath: "/pages/mine/mine"
				},
			],
			parent: [{
					iconPath: "home",
					selectedIconPath: "home-fill",
					text: "选择老师",
					customIcon: false,
					pagePath: "/pages/parent/teacher/teacher"
				},
				{
					iconPath: "photo",
					selectedIconPath: "photo-fill",
					text: "选择课程",
					customIcon: false,
					pagePath: "/pages/parent/lesson/lesson"
				},
				{
					iconPath: "file-text",
					selectedIconPath: "file-text-fill",
					text: "在线订单",
					customIcon: false,
					pagePath: "/pages/parent/order/order"
				},
				{
					iconPath: "play-right",
					selectedIconPath: "play-right-fill",
					text: "在线课堂",
					customIcon: false,
					pagePath: "/pages/parent/online/online"
				},
				{
					iconPath: "account",
					selectedIconPath: "account-fill",
					text: "我的页面",
					customIcon: false,
					pagePath: "/pages/mine/mine"
				},
			],
			// 请求地址
			baseUrl: 'http://114.55.252.249:8085/',
			//baseUrl: 'http://127.0.0.1:8085/',
			// 图片展示地址
			imgPath: 'http://114.55.252.249:8085/attach/download/'
		},
		onLaunch: function() {
			let pages = getCurrentPages();
			let page = pages[pages.length - 1];
			const user = uni.getStorageSync("user")
			if ("" == user) {
				uni.reLaunch({
					url: "/pages/login/login"
				})
			}
		},
		onShow: function() {

		},
		onHide: function() {

		},
		methods: {
			updateAddress() {
				const temp = uni.getStorageSync('user')
				if(!temp) return
				const data = JSON.parse(temp)
				uni.getLocation({
					type: 'gcj02',
					success: (e) => {
						this.latitude = e.latitude,
							this.longitude = e.longitude
							const params = {
								code: data.code,
								latitude: e.latitude,
								longitude: e.longitude,
								type: data.type
							}
							this.ajax({
								url: 'user/location',
								method: 'post',
								data: params
							}).then(res => {
								console.log(res,'address')
							})
					},
					complete(e) {
						console.log(e,'error')
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	@import "uview-ui/index.scss";
	@import url(./assets/css/index.css)
</style>
