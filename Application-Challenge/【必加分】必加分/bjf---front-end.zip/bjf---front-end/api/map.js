// 高德地图web服务key
const key = '5d7cb37f1080dd5738113c73dba8b96a'

/** 逆地理编码
 * @param {String} location  经纬度坐标
 */
export const mapAPI = (location) => {
	const data = {
		key,
		location
	}
	return new Promise((resolve,reject) => {
		uni.request({
			method: 'GET',
			url: 'https://restapi.amap.com/v3/geocode/regeo',
			data,
			success(e) {
					
				resolve(e)
				
			},
			fail(e) {
				reject(e)
			}
		})
	})
}

/**
 * 关键词搜索
 * @param {type} FN_PARAMS 
 */

export const mapKeyWord = (keywords) => {
	const data = {
		key,
		keywords
	}
	
	return new Promise((resolve, reject) => {
		uni.request({
			method: 'GET',
			url: 'https://restapi.amap.com/v3/place/text',
			data,
			success(e) {
				resolve(e)
			},
			fail(e) {
				reject(e)
			}
		})
	})
}