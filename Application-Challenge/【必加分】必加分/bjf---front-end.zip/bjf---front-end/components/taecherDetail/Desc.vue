<template name="teacher-desc">
	<view class="desc">
		<view class="desc-item">
			<view class="desc-name">
				最高学历：
			</view>
			<view class="desc-express">
				{{item ? item.educationStr || '暂无' : '暂无'}}
			</view>
		</view>
		
		<view class="desc-item">
			<view class="desc-name">
				籍贯：
			</view>
			<view class="desc-express">
				{{ item ? item.address || '暂无' : '暂无'}}
			</view>
		</view>
		
		<view class="desc-item">
			<view class="desc-name">
				老师性别：
			</view>
			<view class="desc-express">
				{{ item ? item.sexStr + '老师' : '暂无'}}
			</view>
		</view>
		
		<view class="desc-item">
			<view class="desc-name">
				老师介绍：
			</view>
			<view class="desc-express">
				{{item ? item.summary || '暂无' : '暂无'}}
			</view>
		</view>
		
		<view class="desc-item">
			<view class="desc-name">
				图片展示：
			</view>
			<view class="desc-express">
				<view class="img-box" v-for="v in item && item.attaches" :key='v.id'>
				<u-image width="100%" height="250rpx" :src="imgPath+v.code" ></u-image>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'teacher-desc',
		props: {
			item: {
				type: Object,
				required: true
			}
		},
		data()  {
			return {
				// 图片展示地址
				imgPath: ''
			}
		},
		created() {
			this.imgPath = getApp().globalData.imgPath
		}
	}
</script>

<style lang="scss" scoped>
	.desc {
		font-size: 26rpx;
		
		.desc-item {
			
			display: flex;
			margin-top: 10rpx;
			.desc-name {
				width: 180rpx;
				min-height: 44rpx;
				line-height: 44rpx;
			}
			
			.desc-express {
				flex: 1;
				display: flex;
				flex-wrap: wrap;
				min-height: 44rpx;
				line-height: 44rpx;
				.img-box {
					margin-top: 10rpx;
					margin-right: 10rpx;
					width: 250rpx;
					height: 250rpx;
					// background-color: #000000;
				}
			}
		}
	}
</style>
