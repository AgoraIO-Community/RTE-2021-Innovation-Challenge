<template>
	<view class="map">
		<mi-map ref="miMap" tipText="当前位置" @updateAddress="updateAddress">
		</mi-map>
	</view>
</template>

<script>
	import miMap from '../../components/mi-map/mi-map.vue'
	import { mapAPI } from '../../api/map.js'
	export default {
		components: {
			miMap
		},
		data() {
			return {
				mapShow: true,
				positionObj: {},
			}
		},
		methods: {
			updateAddress(addressObj) {
				this.mapShow = false
				this.positionObj = addressObj
				const ad = [addressObj.longitude, addressObj.latitude]
				const temp = ad.map(e => e.toFixed(3))
				mapAPI(temp).then(res => {
					const params = {
						longitude: addressObj.longitude,
						latitude: addressObj.latitude,
						address: res.data.regeocode.formatted_address
					}
					this.positionObj = params
					this.$emit('save-address', this.positionObj)
				})
			}
		}
	}
</script>

<style lang="scss" scoped>

</style>
