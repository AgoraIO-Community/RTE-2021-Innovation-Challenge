# ShowDocs

#### 简介
项目名：秀(en:Show)
团队名：lchyyds

####  Agora SDK 使用
极速直播SDK

#### 设计与实现
详见《线上演出平台“秀”的设计与实现.pdf》
