const SERVER_ADDRESS = '124.71.166.237:50000';

export const getServerAddress = () => SERVER_ADDRESS;