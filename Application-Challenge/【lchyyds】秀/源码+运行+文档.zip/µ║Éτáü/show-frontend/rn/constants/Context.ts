import React from 'react';

// export const WSContext = React.createContext<any>({ ws: undefined });