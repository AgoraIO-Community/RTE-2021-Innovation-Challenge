export enum TabNav {
  Home = '首页',
  Purchased = '已购',
  Publish = '发布',
  Mine = '我的',
};

export enum HomeStackNav {
  AllShows = '全部演出',
  ShowChannel = '演出',
};