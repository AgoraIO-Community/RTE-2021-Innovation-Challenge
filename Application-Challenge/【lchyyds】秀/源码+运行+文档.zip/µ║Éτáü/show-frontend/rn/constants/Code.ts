export enum Code {
  RequestNoToken = 1,
  RequestNoUserId = 2,
  TokenInvalid = 3,
};