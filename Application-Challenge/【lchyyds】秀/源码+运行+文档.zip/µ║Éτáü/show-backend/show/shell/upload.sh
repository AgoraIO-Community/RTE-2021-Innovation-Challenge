#./mvnw clean package
spawn scp target/show-1.0.jar root@124.71.166.237:/root/show-app
expect "*assword:*"
send "Ldlch2018\n"
interact