spawn ssh root@124.71.166.237 "cd show-app && ./start.sh"
expect "*assword:*"
send "Ldlch2018\n"
interact