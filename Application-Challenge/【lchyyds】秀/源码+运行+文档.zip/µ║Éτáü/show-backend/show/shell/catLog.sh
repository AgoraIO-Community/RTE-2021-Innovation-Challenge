spawn ssh root@124.71.166.237 "cd show-app && cat error.log"
expect "*assword:*"
send "Ldlch2018\n"
interact

spawn ssh root@124.71.166.237 "cd show-app && cat info.log"
expect "*assword:*"
send "Ldlch2018\n"
interact