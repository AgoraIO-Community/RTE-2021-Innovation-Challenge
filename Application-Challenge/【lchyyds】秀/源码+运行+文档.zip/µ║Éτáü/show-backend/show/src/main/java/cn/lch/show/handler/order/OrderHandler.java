package cn.lch.show.handler.order;

import cn.lch.show.handler.ResVO;
import cn.lch.show.handler.order.form.PayForm;
import cn.lch.show.handler.order.vo.OrderVO;
import cn.lch.show.model.order.OrderModel;
import cn.lch.show.model.order.OrderRepository;
import cn.lch.show.service.order.OrderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/order")
@Api("订单")
public class OrderHandler {
    @Autowired
    OrderRepository orderRepository;
    @Autowired
    OrderService orderService;

    @ApiOperation("支付")
    @PostMapping("/pay")
    public ResVO<String> pay(@RequestBody PayForm payForm) {
        OrderModel model = orderRepository.findByShowIdAndUserId(payForm.getShowId(), payForm.getUserId());
        if (model != null) {
            return ResVO.<String>builder().success(false).msg("用户已经为改演出支付").build();
        }
        model = OrderModel.builder().payTime(LocalDateTime.now()).build();
        BeanUtils.copyProperties(payForm, model);
        orderRepository.save(model);
        return ResVO.<String>builder().success(true).build();
    }

    @ApiOperation("查看用户所有order")
    @GetMapping("/query/{userId}")
    public ResVO<List<OrderVO>> queryAllOrder(@PathVariable("userId") String userId) {
        return ResVO.<List<OrderVO>>builder()
                .success(true)
                .data(orderService.queryOrderByUserId(userId))
                .build();
    }

    @ApiOperation("查看用户对于某个show是否支付")
    @GetMapping("/paid/{userId}/{showId}")
    public ResVO<Boolean> isPaid(@PathVariable("userId") String userId, @PathVariable("showId") String showId) {
        return ResVO.<Boolean>builder().success(true).data(orderService.isPaid(userId, showId)).build();
    }
}
