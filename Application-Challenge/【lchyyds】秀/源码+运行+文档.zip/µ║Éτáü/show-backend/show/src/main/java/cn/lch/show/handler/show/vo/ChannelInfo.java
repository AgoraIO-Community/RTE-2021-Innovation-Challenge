package cn.lch.show.handler.show.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@ApiModel
public class ChannelInfo {
    @ApiModelProperty("show状态")
    /**
     * @see ShowState
     */
    int showState;

    @ApiModelProperty("show id")
    String showId;

    @ApiModelProperty("channel meta")
    ChannelMetaVO channelMetaVO;

    @ApiModelProperty("用户对于该show是否支付")
    boolean purchased;

    public enum ShowState {
        NotYet,  //未开始
        Showing,  //进行中
        End  //结束
    }

}
