package cn.lch.show.handler.show.channelmanage;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class User {
    //该用户加入频道的时间戳，Unix 时间戳，单位为秒。当 in_channel 的值为 true 时，才会返回此字段。
    long join;

    /**
     *该用户是否在频道内：
     *
     * true：该用户在频道内
     * false: 该用户不在频道内
     */
    boolean in_channel;

    /**
     * 该用户在频道内的角色:
     *
     * 0: 未知
     * 1：通信场景的用户
     * 2：直播场景的主播
     * 3：直播场景的观众
     * 当 in_channel 的值为 true 时，才会返回此字段
     */
    int role;
}
