package cn.lch.show.service.security;

import com.alibaba.fastjson.JSONObject;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.util.Date;

public class TokenService {
    //过期天数
    private static final int expiredDays = 7;
    //过期天数对应毫秒数
    private static final long expiredMillis = expiredDays * 24 * 60 * 60 * 1000;

    private static final String secret = "showappdetokenjiancemiyao";

    /**
     * 根据userId生成token
     * @param userId
     * @return
     */
    public static String generateToken(String userId) {
        Date now = new Date();
        return Jwts.builder()
                .setHeaderParam("typ", "JWT")
                .setSubject("show-app-token")
                .setAudience(userId)
                .setIssuedAt(now)
                .setExpiration(new Date(now.getTime() + expiredMillis))
                .signWith(SignatureAlgorithm.HS512, secret)
                .compact();
    }
    /**
     * 获取 Token 中注册信息
     * @param token
     * @return
     */
    public static Claims getTokenClaim(String token) {
        try {
            return Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
        } catch (ExpiredJwtException e) {
            //说明token过期
            return null;
        } catch (Exception e) {
            //其他问题认为token无效
            return null;
        }
    }

    /**
     * 判断token是否有效
     * @param token
     * @param userId
     * @return true->有效, false->无效
     */
    public static boolean isTokenEffective(String token, String userId) {
        Claims claims = getTokenClaim(token);
        if (claims == null) return false;
        String audience = claims.getAudience();
        if (userId == null || !userId.equals(audience)) {
            return false;
        }
        return true;
    }
}
