package cn.lch.show.service.show;

import com.alibaba.fastjson.JSONObject;

import java.net.URI;
import java.net.http.HttpRequest;
import java.util.Base64;

/**
 * 调用声网restful api的基本配置
 */
public class AgoraRestful {
    public static final String clientKey = "3f4a2d8d35024ad28566a4296f2f0a44"; //客户id
    public static final String clientSecret = "6b84d7fcb0b44ad3bcb36aefb5951775"; //客户密钥
    public static String authorizationHeader = "Basic " + new String(Base64.getEncoder().encode((clientKey + ":" + clientSecret).getBytes())); //用于认证


    public static HttpRequest getRequest(String url) {
        // 创建 HTTP 请求对象
        return HttpRequest.newBuilder()
                .uri(URI.create(url))
                .GET()
                .header("Authorization", AgoraRestful.authorizationHeader)
                .header("Content-Type", "application/json;charset=utf-8")
                .build();
    }

    public static HttpRequest postRequest(String url, JSONObject body) {
        // 创建 HTTP 请求对象
        return HttpRequest.newBuilder()
                .uri(URI.create(url))
                .POST(HttpRequest.BodyPublishers.ofString(body.toJSONString()))
                .header("Authorization", AgoraRestful.authorizationHeader)
                .header("Content-Type", "application/json;charset=utf-8")
                .build();
    }

    /**
     * 调用声网频道管理的基本方式
     */
//    // 基于 Java 实现的 HTTP 基本认证示例，使用 RTC 的服务端 RESTful API
//    public static class Base64Encoding {
//        public static void main(String[] args) throws IOException, InterruptedException {
//
//            // 客户 ID
//            final String customerKey = "Your customer key";
//            // 客户密钥
//            final String customerSecret = "Your customer secret";
//
//            // 拼接客户 ID 和客户密钥并使用 base64 编码
//            String plainCredentials = customerKey + ":" + customerSecret;
//            String base64Credentials = new String(Base64.getEncoder().encode(plainCredentials.getBytes()));
//            // 创建 authorization header
//            String authorizationHeader = "Basic " + base64Credentials;
//
//            HttpClient client = HttpClient.newHttpClient();
//
//            // 创建 HTTP 请求对象
//            HttpRequest request = HttpRequest.newBuilder()
//                    .uri(URI.create("https://api.agora.io/dev/v1/projects"))
//                    .GET()
//                    .header("Authorization", authorizationHeader)
//                    .header("Content-Type", "application/json")
//                    .build();
//            // 发送 HTTP 请求
//            HttpResponse<String> response = client.send(request,
//                    HttpResponse.BodyHandlers.ofString());
//
//            System.out.println(response.body());
//        }
//    }
}
