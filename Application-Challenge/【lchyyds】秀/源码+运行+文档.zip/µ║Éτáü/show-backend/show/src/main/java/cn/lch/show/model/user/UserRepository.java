package cn.lch.show.model.user;

import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends CrudRepository<UserModel, String> {
    UserModel findByPhone(String phone);
    UserModel findByUid(int uid);
}
