package cn.lch.show.handler.order.vo;

import cn.lch.show.handler.show.vo.ShowVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@ApiModel
public class OrderVO {
    @ApiModelProperty("演出vo")
    ShowVO showVO;

    @ApiModelProperty("支付钱数")
    double amount;

    @ApiModelProperty("支付时间")
    LocalDateTime payTime;
}
