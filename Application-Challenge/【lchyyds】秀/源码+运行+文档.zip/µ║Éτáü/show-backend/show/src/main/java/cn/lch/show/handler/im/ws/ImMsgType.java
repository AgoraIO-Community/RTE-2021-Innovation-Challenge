package cn.lch.show.handler.im.ws;

public enum ImMsgType {
    JoinShow,   //加入show房间
    LeaveShow,  //离开show房间
    SendMsg,    //在show房间发送消息
    ReceiveMsg;  //在show房间收到消息

    public static ImMsgType getImMsgTypeByInt(int type) {
        for (ImMsgType value : ImMsgType.values()) {
            if (value.ordinal() == type) return value;
        }
        return null;
    }
}
