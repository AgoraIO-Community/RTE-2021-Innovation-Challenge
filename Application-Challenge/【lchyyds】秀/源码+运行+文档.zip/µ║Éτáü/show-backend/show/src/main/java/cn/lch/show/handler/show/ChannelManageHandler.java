package cn.lch.show.handler.show;

import cn.lch.show.handler.show.channelmanage.Channel;
import cn.lch.show.handler.show.channelmanage.Project;
import cn.lch.show.handler.show.channelmanage.User;
import cn.lch.show.model.user.UserRepository;
import cn.lch.show.service.show.ChannelManageService;
import cn.lch.show.service.show.TokenBuilder;
import cn.lch.show.util.TimeUtil;
import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/channelmanage")
@Api("频道管理")
public class ChannelManageHandler {

    @Autowired
    ChannelManageService channelManageService;
    @Autowired
    UserRepository userRepository;

    @ApiOperation("查看本project所有的channel信息")
    @GetMapping("/all")
    public String allInfo() {
        StringBuilder res = new StringBuilder();
        List<String> channelNameList = new ArrayList<>();
        res.append("只查看直播的情况</br></br>");
        String t = "&nbsp;&nbsp;&nbsp;&nbsp;";
        /**
         * 先查看project info
         */
        res.append("Project info:</br>");
        Project projectInfo = channelManageService.getProjectInfo(TokenBuilder.appId);
        res.append(String.format("%s一共有channel%s个</br>", t, projectInfo.getTotal_size()));
        for (Project.Channel channel : projectInfo.getChannels()) {
            res.append(String.format("%schannelName = %s, userCount = %s</br>", t, channel.getChannel_name(), channel.getUser_count()));
            channelNameList.add(channel.getChannel_name());
        }
        /**
         * 再查看channel的信息
         */
        res.append("</br></br>Channel info:</br>");
        for (String channelName : channelNameList) {
            Channel channelInfo = channelManageService.getChannelInfo(TokenBuilder.appId, channelName);
            res.append(String.format("%s%s</br>", t, channelInfo.toString()));
            /**
             * 查看主播和观众
             */
            res.append(t + "主播:</br>");
            for (Integer broadcaster : channelInfo.getBroadcasters()) {
                User broadcasterInfo = channelManageService.getUserInfo(TokenBuilder.appId, broadcaster, channelName);
                JSONObject formatUser = formatUser(broadcasterInfo, broadcaster);
                res.append(String.format("%s%s</br>", (t + t), formatUser));
            }
            res.append(t + "观众:</br>");
            for (Integer audience : channelInfo.getAudience()) {
                User audienceInfo = channelManageService.getUserInfo(TokenBuilder.appId, audience, channelName);
                JSONObject formatUser = formatUser(audienceInfo, audience);
                res.append(String.format("%s%s</br>", (t + t), formatUser));
            }
            res.append("</br>");
        }
        return res.toString();
    }

    private JSONObject formatUser(User user, int uid) {
        JSONObject formatUser = new JSONObject();
        formatUser.put("加入时间", TimeUtil.formatLocalDateTime(TimeUtil.getLocalDateTimeBySeconds(user.getJoin()), null));
        formatUser.put("角色", user.getRole() == 2 ? "主播": (user.getRole() == 3 ? "观众": "未知"));
        formatUser.put("手机号", userRepository.findByUid(uid).getPhone());
        return formatUser;
    }
}
