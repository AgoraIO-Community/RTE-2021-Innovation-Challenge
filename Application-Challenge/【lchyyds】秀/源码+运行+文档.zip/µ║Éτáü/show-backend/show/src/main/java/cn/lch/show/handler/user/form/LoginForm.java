package cn.lch.show.handler.user.form;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@ApiModel
public class LoginForm {
    @ApiModelProperty("电话号码")
    String phone;

    @ApiModelProperty("昵称")
    String nickname;

    @ApiModelProperty("头像图片url")
    String avatar; //头像图片
}
