package cn.lch.show.handler.show.channelmanage;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Project {
    /**
     * 频道列表
     */
    List<Channel> channels;

    /**
     * 频道总数
     */
    int total_size;

    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class Channel {
        /**
         * 频道名
         */
        String channel_name;
        /**
         * 用户数量
         */
        int user_count;
    }
}
