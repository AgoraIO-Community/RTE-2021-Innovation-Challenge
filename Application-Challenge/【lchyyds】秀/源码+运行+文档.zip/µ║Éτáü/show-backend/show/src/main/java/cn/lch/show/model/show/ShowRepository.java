package cn.lch.show.model.show;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface ShowRepository extends CrudRepository<ShowModel, String> {
    List<ShowModel> findByTitleLikeAndShowTimeEndGreaterThan(String pattern, LocalDateTime time);

    List<ShowModel> findByDescriptionLikeAndShowTimeEndGreaterThan(String pattern, LocalDateTime time);

    @Query(value = "select s from ShowModel s, UserModel u where s.showTimeEnd > ?2 and s.userId = u.id and u.nickname like ?1")
    List<ShowModel> findByUserNickName(String pattern, LocalDateTime time);
}
