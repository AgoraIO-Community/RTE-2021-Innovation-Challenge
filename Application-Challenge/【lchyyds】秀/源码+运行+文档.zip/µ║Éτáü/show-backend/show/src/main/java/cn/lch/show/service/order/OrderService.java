package cn.lch.show.service.order;

import cn.lch.show.handler.order.vo.OrderVO;
import cn.lch.show.handler.show.vo.ShowVO;
import cn.lch.show.model.order.OrderModel;
import cn.lch.show.model.order.OrderRepository;
import cn.lch.show.service.show.ShowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class OrderService {
    @Autowired
    OrderRepository orderRepository;
    @Autowired
    ShowService showService;

    public List<OrderVO> queryOrderByUserId(String userId) {
        List<OrderModel> orderModelList = orderRepository.findByUserId(userId);
        List<OrderVO> resList = new ArrayList<>(orderModelList.size());

        Map<String, ShowVO> showIdVOMap = showService.getShowVOByIds(orderModelList.stream().map(e -> e.getShowId()).collect(Collectors.toList()));

        for (OrderModel model : orderModelList) {
            OrderVO orderVO = OrderVO.builder()
                    .amount(model.getAmount())
                    .payTime(model.getPayTime())
                    .showVO(showIdVOMap.get(model.getShowId()))
                    .build();
            resList.add(orderVO);
        }
        return resList;
    }

    public boolean isPaid(String userId, String showId) {
        OrderModel orderModel = orderRepository.findByShowIdAndUserId(showId, userId);
        if (orderModel != null) return true;
        return false;
    }
}
