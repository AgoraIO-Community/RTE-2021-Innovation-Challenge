package cn.lch.show.util;

/**
 * 参考文章: https://blog.csdn.net/Soinice/article/details/97052030
 */
/**
 * \033[*;*;*m    颜色、背景颜色、样式
 * 样式
 *  0 空样式
 *  1 粗体
 *  4 下划线
 *  7 反色
 *
 * 颜色1：
 *  30白色
 *  31红色
 *  32绿色
 *  33黄色
 *  34蓝色
 *  35紫色
 *  36浅蓝
 *  37灰色
 *
 * 背景颜色：
 *  40-47 和颜色顺序相同
 *
 * 颜色2：
 *  90-97比颜色1更鲜艳一些
 */
public class ColorPrint {
    public static void defaultColorPrint(String content) {
        System.out.println(String.format("%s%s%s", "\033[96m", content, "\033[0m"));
    }
}
