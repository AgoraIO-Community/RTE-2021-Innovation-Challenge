package cn.lch.show.service.schedulingtasks;

import cn.lch.show.service.im.UserWsPool;
import cn.lch.show.service.im.showchat.ShowRoom;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
@Slf4j
public class WsTask {

//    @Scheduled(fixedRate = 10000) //毫秒数
//    public void closeSession() {
//        UserWsPool.userIdSessionMap.forEach((userId, session) -> {
//            try {
//                session.close();
//                ShowRoom.loseConnect(userId);
//                log.info("close " + userId);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        });
//    }
}
