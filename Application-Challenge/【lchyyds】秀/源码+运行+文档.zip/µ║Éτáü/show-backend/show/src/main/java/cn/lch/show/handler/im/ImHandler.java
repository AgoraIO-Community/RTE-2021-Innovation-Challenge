package cn.lch.show.handler.im;

import cn.lch.show.handler.im.ws.ImDTO;
import cn.lch.show.handler.im.ws.ImMsgType;
import cn.lch.show.service.im.ImService;
import cn.lch.show.service.im.ImServiceTag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class ImHandler {
    private static final Map<Integer, ImService> msgTypeServiceMap = new HashMap<>();

    public static void action(ImDTO imDTO, String userId) {
        ImService imService = msgTypeServiceMap.get(imDTO.getType());
        if (imService != null) {
            imService.action(imDTO, userId);
        } else {
            log.warn(String.format("未定义ImMsgType<%s>的处理方法", imDTO.getType()));
        }
    }

    @Autowired
    public ImHandler(ApplicationContext applicationContext) {
        /**
         * 解析所有的方法，注册所有ImService
         */
        Map<String, Object> beansWithAnnotation = applicationContext.getBeansWithAnnotation(ImServiceTag.class);
        beansWithAnnotation.forEach((beanName, bean) -> {
            ImServiceTag annotation = bean.getClass().getAnnotation(ImServiceTag.class);
            ImMsgType type = annotation.type();
            if (msgTypeServiceMap.get(type.ordinal()) != null) {
                int code = SpringApplication.exit(applicationContext, () -> {
                    log.error(String.format("有重复的ImMsgType定义, 重复的type为<%s>", type));
                    return -1;
                });
                System.exit(code);
            }
            msgTypeServiceMap.put(type.ordinal(), (ImService) bean);
        });
    }
}
