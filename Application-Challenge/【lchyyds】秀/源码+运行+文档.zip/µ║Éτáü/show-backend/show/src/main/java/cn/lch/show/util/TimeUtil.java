package cn.lch.show.util;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

public class TimeUtil {
    public static final String defaultPattern = "yyyy-MM-dd HH:mm:ss";

    /**
     * 秒级时间戳 获取 LocalDateTime
     * @param seconds
     * @return
     */
    public static LocalDateTime getLocalDateTimeBySeconds(long seconds) {
        return LocalDateTime.ofEpochSecond(seconds, 0, ZoneOffset.of("+8"));
    }

    public static String formatLocalDateTime(LocalDateTime localDateTime, String pattern) {
        if (pattern == null) {
            pattern = defaultPattern;
        }
        return localDateTime.format(DateTimeFormatter.ofPattern(pattern));
    }

    /**
     * 获取毫秒级时间戳
     * @param localDateTime
     * @return
     */
    public static long getTimeStamp(LocalDateTime localDateTime) {
        return localDateTime.toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }
}
