package cn.lch.show.service.show;

import cn.lch.show.handler.show.vo.ChannelInfo;
import cn.lch.show.handler.show.vo.ShowVO;
import cn.lch.show.handler.user.vo.UserVO;
import cn.lch.show.model.order.OrderModel;
import cn.lch.show.model.order.OrderRepository;
import cn.lch.show.model.show.ShowModel;
import cn.lch.show.model.show.ShowRepository;
import cn.lch.show.service.user.UserService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ShowService {
    @Autowired
    ShowRepository showRepository;
    @Autowired
    UserService userService;
    @Autowired
    OrderRepository orderRepository;

    public ShowVO copyFromModel(ShowModel model, UserVO userVO) {
        if (model != null) {
            ShowVO showVO = ShowVO.builder().showId(model.getId()).showCreator(userVO).build();
            BeanUtils.copyProperties(model, showVO);
            showVO.setReplayList(model.getReplayUrlList());
            return showVO;
        }
        return null;
    }

    public List<ShowVO> getAllShow() {
        Iterable<ShowModel> all = showRepository.findAll();
        List<String> userIdList = new ArrayList<>();
        for (ShowModel model : all) {
            userIdList.add(model.getUserId());
        }
        Map<String, UserVO> userIdUserVOMap = userService.findUserVOByUserId(userIdList);

        List<ShowVO> resList = new ArrayList<>();
        for (ShowModel model : all) {
            resList.add(copyFromModel(model, userIdUserVOMap.get(model.getUserId())));
        }
        return resList;
    }

    public Map<String, ShowVO> getShowVOByIds(List<String> showIds) {
        Iterable<ShowModel> all = showRepository.findAllById(showIds);
        List<String> userIdList = new ArrayList<>();
        for (ShowModel model : all) {
            userIdList.add(model.getUserId());
        }
        Map<String, UserVO> userIdUserVOMap = userService.findUserVOByUserId(userIdList);

        List<ShowVO> resList = new ArrayList<>();
        for (ShowModel model : all) {
            resList.add(copyFromModel(model, userIdUserVOMap.get(model.getUserId())));
        }
        return resList.stream().collect(Collectors.toMap(e -> e.getShowId(), e -> e));
    }

    public ChannelInfo.ShowState judgeShowState(ShowModel showModel) {
        /**
         * 判断show的状态
         */
        LocalDateTime now = LocalDateTime.now();

        if (now.isBefore(showModel.getShowTimeStart())) {  //早于开始时间
            return ChannelInfo.ShowState.NotYet;
        }
        else if (now.isAfter(showModel.getShowTimeEnd())) {  //晚于结束时间
            return ChannelInfo.ShowState.End;
        }
        else {  //开始时间-结束时间 之间
            return ChannelInfo.ShowState.Showing;
        }
    }

    /**
     * 搜索
     *  定义搜索规则：
     *      1.show title中包含keyword
     *      2.创建者nickname包含keyword
     *      3.show description包含keyword
     *  返回顺序也按照规则顺序
     * @param keyword
     * @return
     */
    public List<ShowVO> searchShow(String keyword) {
        List<ShowModel> showModelList = new ArrayList<>();
        List<ShowModel> tmp;
        Set<String> existShowIdSet = new HashSet<>(); //用于记录已经加入的id, 避免重复加入
        /**
         * 搜索
         */
        String pattern = "%" + keyword + "%";
        //show title中包含keyword
        tmp = showRepository.findByTitleLikeAndShowTimeEndGreaterThan(pattern, LocalDateTime.MIN);
        sortByShowStartTime(tmp);
        existShowIdSet.addAll(tmp.stream().map(e->e.getId()).collect(Collectors.toSet()));
        showModelList.addAll(tmp);
        //创建者nickname包含keyword
        tmp = showRepository.findByUserNickName(pattern, LocalDateTime.MIN);
        tmp = tmp.stream().filter(e -> !existShowIdSet.contains(e.getId())).collect(Collectors.toList());
        sortByShowStartTime(tmp);
        existShowIdSet.addAll(tmp.stream().map(e->e.getId()).collect(Collectors.toSet()));
        showModelList.addAll(tmp);
        //show description包含keyword
        tmp = showRepository.findByDescriptionLikeAndShowTimeEndGreaterThan(pattern, LocalDateTime.MIN);
        tmp = tmp.stream().filter(e -> !existShowIdSet.contains(e.getId())).collect(Collectors.toList());
        sortByShowStartTime(tmp);
        existShowIdSet.addAll(tmp.stream().map(e->e.getId()).collect(Collectors.toSet()));
        showModelList.addAll(tmp);
        /**
         * show model排序
         */
        sortByShowStartTime(showModelList);
        /**
         * 生成VO
         */
        List<String> userIdList = new ArrayList<>();
        for (ShowModel model : showModelList) {
            userIdList.add(model.getUserId());
        }
        Map<String, UserVO> userIdUserVOMap = userService.findUserVOByUserId(userIdList);

        List<ShowVO> resList = new ArrayList<>();
        for (ShowModel model : showModelList) {
            resList.add(copyFromModel(model, userIdUserVOMap.get(model.getUserId())));
        }
        return resList;
    }

    /**
     * 根据showTimeStart排序,大的排在前面
     *
     * @param showModelList
     */
    private void sortByShowStartTime(List<ShowModel> showModelList) {
        showModelList.sort(Comparator.comparing(ShowModel::getShowTimeStart).reversed());
    }

    public List<ShowVO> getPaidShow(String userId) {
        List<OrderModel> orderModelList = orderRepository.findByUserId(userId);
        Iterable<ShowModel> showModels = showRepository.findAllById(orderModelList.stream().map(e -> e.getShowId()).collect(Collectors.toList()));
        UserVO userVO = userService.findUserVOByUserId(userId);

        List<ShowVO> res = new ArrayList<>();
        showModels.forEach(showModel -> {
            res.add(copyFromModel(showModel, userVO));
        });
        return res;
    }
}
