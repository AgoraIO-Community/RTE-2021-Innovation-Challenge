package cn.lch.show.service.im.impl;

import cn.lch.show.handler.im.ws.ImDTO;
import cn.lch.show.handler.im.ws.ImMsgType;
import cn.lch.show.handler.user.vo.UserVO;
import cn.lch.show.service.im.ImService;
import cn.lch.show.service.im.ImServiceTag;
import cn.lch.show.service.im.showchat.ShowRoom;
import cn.lch.show.service.user.UserService;
import cn.lch.show.util.TimeUtil;
import com.alibaba.fastjson.JSONObject;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.Time;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

/**
 * 客户端发送消息处理:
 *  1.给所有人转发
 */
@ImServiceTag(type = ImMsgType.SendMsg)
public class SendMsg implements ImService {
    @Autowired
    UserService userService;
    @Override
    public void action(ImDTO data, String userId) {
        SendMsgForm sendMsgForm = JSONObject.parseObject(data.getData(), SendMsgForm.class);
        //查询发送者的userVO
        //先封装好vo
        SendMsgVO sendMsgVO = SendMsgVO.builder()
                .senderUserVO(userService.findUserVOByUserId(userId))
                .showId(sendMsgForm.getShowId())
                .content(sendMsgForm.getContent())
                .sendTime(TimeUtil.getTimeStamp(LocalDateTime.now()))
                .mid(generateMid(userId))
                .build();
        //封装好ImDTO
        ImDTO sendData = ImDTO.builder()
                .type(ImMsgType.ReceiveMsg.ordinal())
                .voData(sendMsgVO)
                .build();
        //转发给同一个showId下的所有user
        ShowRoom.forwardMsgByShowId(sendMsgForm.getShowId(), sendData);
    }

    private String generateMid(String userId) {
        return TimeUtil.getTimeStamp(LocalDateTime.now()) + userId;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class SendMsgForm {
        String showId;   //发送消息的直播间
        String content;  //发送的文本消息
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class SendMsgVO {
        UserVO senderUserVO; //消息发送者的userVO
        String showId;       //消息发送的目标show id
        String content;      //发送的文本消息
        long sendTime;       //发送消息时的时间戳，毫秒
        String mid;          //保证唯一的msg id
    }
}
