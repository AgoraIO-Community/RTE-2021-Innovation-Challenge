package cn.lch.show.service.errorcode;

import cn.lch.show.handler.errorcode.vo.ErrorCodeVO;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ErrorCodeService {

    private Map<String, List<ErrorCodeVO>> errorCodeCache = new HashMap<>();

    /**
     *
     * @return
     */
    public List<ErrorCodeVO> getRnErrorCode() {
        String key = "rn";
        //查询缓存
        List<ErrorCodeVO> res = errorCodeCache.get(key);
        if (res != null) return res;

        res = new ArrayList<>();
        //解析声网网页
        try {
            Document document = Jsoup.connect("https://docs.agora.io/cn/Interactive%20Broadcast/error_rtc?platform=React%20Native#%E5%9F%BA%E7%A1%80%E9%94%99%E8%AF%AF%E7%A0%81").get();
            Elements tables = document.getElementsByTag("table");
            for (Element table : tables) {
                //table为<table>
                Elements trList = table.getElementsByTag("tbody").first().getElementsByTag("tr");
                for (Element tr : trList) {
                    //tr就是一行
                      //tdList应该有两个td, 第一个获取code、第二个获取文本描述
                    Elements tdList = tr.getAllElements();

                    String code = tdList.get(2).text();
                    String description = tdList.get(3).text();

                    res.add(ErrorCodeVO.builder()
                            .errorCode(Integer.parseInt(code))
                            .description(description)
                            .build());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        errorCodeCache.put("rn", res);
        return res;
    }
}
