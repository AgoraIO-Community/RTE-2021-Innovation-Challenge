package cn.lch.show.handler.user.vo;

import cn.lch.show.model.user.UserRole;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@ApiModel
public class UserVO {
    @ApiModelProperty("userId")
    String userId;

    @ApiModelProperty("电话号码")
    String phone;

    @ApiModelProperty("昵称")
    String nickname;

    @ApiModelProperty("头像url")
    String avatar;

    /**
     * 使用枚举的ordinal
     * @see UserRole
     */
    @ApiModelProperty("角色类别, 见UserRole")
    int role;
}
