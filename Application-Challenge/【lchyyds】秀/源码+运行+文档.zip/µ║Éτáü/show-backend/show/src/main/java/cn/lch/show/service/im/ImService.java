package cn.lch.show.service.im;

import cn.lch.show.handler.im.ws.ImDTO;

public interface ImService {
    void action(ImDTO data, String userId);
}