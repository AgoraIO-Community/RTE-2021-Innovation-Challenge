package cn.lch.show.service.im.showchat;

import cn.lch.show.handler.im.ws.ImDTO;
import cn.lch.show.service.im.UserWsPool;
import com.alibaba.fastjson.JSONObject;

import javax.websocket.Session;
import java.io.IOException;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;

public class ShowRoom {
    /**
     * show id -> 在该show中的所有userId set
     */
    public static final Map<String, Set<String>> showIdUserIdsMap = new ConcurrentHashMap<>();

    /**
     * userId -> 该user进入的show id，一个userId同一时刻只能进入一个show
     */
    public static final Map<String, String> userIdShowIdMap = new ConcurrentHashMap<>();


    /**
     * 用户失去连接时的处理
     * @param userId
     */
    public static void loseConnect(String userId) {
        String joinShowId = userIdShowIdMap.remove(userId);
        if (joinShowId != null) {
            Set<String> userIdSet = showIdUserIdsMap.get(joinShowId);
            if (userIdSet != null) {
                userIdSet.remove(userId);
            }
        }
    }

    /**
     * 用户加入show
     */
    public static void joinShow(String userId, String showId) {
        //先判断是否原来加入了show
        String joinedShowId = userIdShowIdMap.get(userId);
        if (joinedShowId != null) {
            //清除原来的user-show数据
            loseConnect(userId);
        }
        //加入show
        userIdShowIdMap.put(userId, showId);
        Set<String> userIdSet = showIdUserIdsMap.get(showId);
        if (userIdSet == null) {
            userIdSet = new ConcurrentSkipListSet<>();
            showIdUserIdsMap.put(showId, userIdSet);
        }
        userIdSet.add(userId);
    }

    /**
     * 离开show
     * @param userId
     * @param showId
     */
    public static void leaveShow(String userId, String showId) {
        String joinedShowId = userIdShowIdMap.get(userId);
        //只有加入的showId 和 要退出的showId 一致时才进行 写
        if (joinedShowId != null && joinedShowId.equals(showId)) {
            userIdShowIdMap.remove(userId);
            Set<String> userIdSet = showIdUserIdsMap.get(joinedShowId);
            userIdSet.remove(userId);
        }
    }

    /**
     * 转发给showId下的所有user
     * @param showId
     * @param data
     */
    public static void forwardMsgByShowId(String showId, ImDTO data) {
        Set<String> userSet = showIdUserIdsMap.get(showId);
        userSet.forEach(userId -> {
            Session session = UserWsPool.userIdSessionMap.get(userId);
            try {
                session.getBasicRemote().sendText(JSONObject.toJSONString(data));
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}
