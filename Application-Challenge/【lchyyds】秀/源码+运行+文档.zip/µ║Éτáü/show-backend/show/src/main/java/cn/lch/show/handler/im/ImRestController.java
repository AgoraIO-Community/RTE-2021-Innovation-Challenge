package cn.lch.show.handler.im;

import cn.lch.show.handler.ResVO;
import cn.lch.show.handler.user.vo.UserVO;
import cn.lch.show.service.im.UserWsPool;
import cn.lch.show.service.im.showchat.ShowRoom;
import cn.lch.show.service.user.UserService;
import cn.lch.show.util.TimeUtil;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/im")
public class ImRestController {

    @Autowired
    UserService userService;

    @ApiOperation("查看所有连接ws的用户")
    @GetMapping("/user/all")
    public ResVO<List<UserConnectStas>> getConnectedUser() {
        List<UserConnectStas> res = new ArrayList<>();
        Map<String, UserVO> userVOByUserId = userService.findUserVOByUserId(new ArrayList<>(UserWsPool.userIdSessionMap.keySet()));
        userVOByUserId.forEach((userId, userVO) -> {
            res.add(UserConnectStas.builder()
                    .count(res.size() + 1)
                    .userId(userId)
                    .phone(userVO.getPhone())
                    .nickname(userVO.getNickname())
                    .connectTime(TimeUtil.formatLocalDateTime(UserWsPool.userIdConnectTimeMap.get(userId), null))
                    .build());
        });
        return ResVO.<List<UserConnectStas>>builder().success(true).data(res).build();
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class UserConnectStas {
        int count;
        String userId;
        String phone;
        String nickname;
        String connectTime; //连接时间
    }

    @ApiOperation("查看user和show的映射关系")
    @GetMapping("/usershow/map")
    public ResVO<Map<String, String>> getUserShowMap() {
        return ResVO.<Map<String, String>>builder().success(true).data(ShowRoom.userIdShowIdMap).build();
    }

    @ApiOperation("查看每一个show中加入的users")
    @GetMapping("/showuser/map")
    public ResVO<Map<String, Set<String>>> getShowUserMap() {
        return ResVO.<Map<String, Set<String>>>builder().success(true).data(ShowRoom.showIdUserIdsMap).build();
    }
}
