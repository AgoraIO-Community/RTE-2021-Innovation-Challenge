package cn.lch.show.handler.show.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@ApiModel
public class SearchVO {
    @ApiModelProperty("")
    List<ShowVO> showVOList;
    @ApiModelProperty("是否还有下一页, true->有下一页；false->没下一页")
    boolean hasNext;
}
