package cn.lch.show.handler.user;

import cn.lch.show.handler.ResVO;
import cn.lch.show.handler.show.channelmanage.User;
import cn.lch.show.handler.user.form.CertificationForm;
import cn.lch.show.handler.user.form.LoginForm;
import cn.lch.show.handler.user.form.UpdateForm;
import cn.lch.show.handler.user.vo.LoginVO;
import cn.lch.show.handler.user.vo.UserVO;
import cn.lch.show.model.user.UserModel;
import cn.lch.show.model.user.UserRepository;
import cn.lch.show.model.user.UserRole;
import cn.lch.show.service.security.TokenService;
import cn.lch.show.service.user.UserService;
import cn.lch.show.util.ObjectUtil;
import cn.lch.show.util.UuidUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Field;

@RestController
@RequestMapping("/user")
@Api("用户")
public class UserHandler {
    @Autowired
    UserRepository userRepository;
    @Autowired
    UserService userService;

    @ApiOperation("登录")
    @PostMapping("/login")
    public ResVO<LoginVO> login(@RequestBody LoginForm loginForm) {
        UserModel model = userRepository.findByPhone(loginForm.getPhone());
        if (model == null) {
            model = UserModel.builder()
                    .nickname(loginForm.getNickname() == null ? loginForm.getPhone() : loginForm.getNickname())
                    .phone(loginForm.getPhone())
                    .avatar("https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fwww.17qq.com%2Fimg_qqtouxiang%2F10861289.jpeg&refer=http%3A%2F%2Fwww.17qq.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1622533982&t=5ae22e7b1ebecbab91f15f133bf34b60")
                    .role(UserRole.Audience) //默认为观众
                    .build();
            userRepository.save(model);
            //设置uid
            model.setUid(UuidUtil.uuidToInt(model.getId()));
            userRepository.save(model);
        }
        LoginVO loginVO = LoginVO.builder()
                .userId(model.getId())
                .token(TokenService.generateToken(model.getId()))
                .build();
        return ResVO.<LoginVO>builder().success(true).data(loginVO).build();
    }

    @ApiOperation("认证")
    @PostMapping("/certification")
    public ResVO<UserVO> certification(@RequestBody CertificationForm certificationForm) {
        if (Strings.isNotBlank(certificationForm.getPhone()) && Strings.isNotBlank(certificationForm.getIdNumber())) {
            UserModel model = userRepository.findByPhone(certificationForm.getPhone());
            model.setRole(UserRole.Merchant);
            userRepository.save(model);
            UserVO userVO = userService.copyFromModel(model);
            return ResVO.<UserVO>builder().success(true).data(userVO).build();
        }
        return ResVO.<UserVO>builder().success(false).msg("信息不完整").build();
    }

    @ApiOperation("用手机号获取user信息")
    @GetMapping("/info/{phone}")
    public ResVO<UserVO> getUserInfo(@PathVariable("phone") String phone) {
        UserVO userVO = userService.findUserVOByPhone(phone);
        if (userVO != null) {
            return ResVO.<UserVO>builder().success(true).data(userVO).build();
        }
        return ResVO.<UserVO>builder().success(false).msg(String.format("手机号<%s>, 查无此人", phone)).build();
    }

    @ApiOperation("用userId获取userVO")
    @GetMapping("/info/id/{userId}")
    public ResVO<UserVO> getUserInfoById(@PathVariable("userId") String userId) {
        UserVO userVO = userService.findUserVOByUserId(userId);
        if (userVO != null) {
            return ResVO.<UserVO>builder().success(true).data(userVO).build();
        }
        return ResVO.<UserVO>builder().success(false).msg(String.format("userId<%s>, 查无此人", userId)).build();
    }

    @ApiOperation("修改user信息")
    @PostMapping("/info/update/{userId}")
    public ResVO updateUserInfo(@PathVariable("userId") String userId, @RequestBody UpdateForm updateForm) {
        UserModel model = userRepository.findById(userId).orElse(null);
        if (model == null) {
            return ResVO.builder().success(false).msg(String.format("userId<%s>, 查无此人", userId)).build();
        }
        BeanUtils.copyProperties(updateForm, model, ObjectUtil.getNullPropertyNames(updateForm));
        userRepository.save(model);
        return ResVO.builder().success(true).build();
    }
}
