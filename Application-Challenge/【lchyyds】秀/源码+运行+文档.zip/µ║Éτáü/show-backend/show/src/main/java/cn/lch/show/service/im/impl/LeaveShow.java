package cn.lch.show.service.im.impl;

import cn.lch.show.handler.im.ws.ImDTO;
import cn.lch.show.handler.im.ws.ImMsgType;
import cn.lch.show.service.im.ImService;
import cn.lch.show.service.im.ImServiceTag;
import cn.lch.show.service.im.showchat.ShowRoom;
import com.alibaba.fastjson.JSONObject;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ImServiceTag(type = ImMsgType.LeaveShow)
public class LeaveShow implements ImService {
    @Override
    public void action(ImDTO data, String userId) {
        LeaveShowForm leaveShowForm = JSONObject.parseObject(data.getData(), LeaveShowForm.class);
        ShowRoom.leaveShow(userId, leaveShowForm.getShowId());
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class LeaveShowForm {
        String showId;
    }
}
