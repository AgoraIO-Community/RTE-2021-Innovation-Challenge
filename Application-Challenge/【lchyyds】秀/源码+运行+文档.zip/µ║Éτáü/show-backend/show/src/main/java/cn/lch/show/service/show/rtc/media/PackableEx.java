package cn.lch.show.service.show.rtc.media;

public interface PackableEx extends Packable {
    void unmarshal(ByteBuf in);
}
