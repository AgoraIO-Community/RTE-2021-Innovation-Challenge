package cn.lch.show.handler;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
@AllArgsConstructor
@ApiModel
public class ResVO<T> {
    @ApiModelProperty("期望操作是否成功")
    boolean success;
    @ApiModelProperty("可能的返回信息")
    String msg;
    @ApiModelProperty("数据")
    T data;
    @ApiModelProperty("code, success=false时区分错误类型")
    int code;
}
