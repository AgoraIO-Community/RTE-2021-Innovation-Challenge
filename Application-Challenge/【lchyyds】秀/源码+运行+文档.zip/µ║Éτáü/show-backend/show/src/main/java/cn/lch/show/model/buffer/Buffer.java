package cn.lch.show.model.buffer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Buffer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;

    String k;

    @Column(length = 2048)
    String v;

    public static String generateKey(String serviceName, String identify) {
        return serviceName + "-" + identify;
    }
    //从key中反解出 identify
    public String decodeIdentify() {
        return k.split("-")[1];
    }
}
