package cn.lch.show.service.show;


import cn.lch.show.service.show.rtc.media.RtcTokenBuilder;

/**
 * 声网极速直播sdk, token生成
 */
public class TokenBuilder {
    public static final String appId = "b4aab4a4e5bb47868cb7f71a0b5f3813";
    private static final String appCertificate = "0b109c8cee894681822a86147a96572d";
    private static final int expirationTimeInSeconds = 24 * 60 * 60; //时间过期秒数

    public static String generateToken(int uid, String channelName, RtcTokenBuilder.Role role) {
        int timestamp = (int)(System.currentTimeMillis() / 1000 + expirationTimeInSeconds);
        RtcTokenBuilder rtcTokenBuilder = new RtcTokenBuilder();
        String token = rtcTokenBuilder.buildTokenWithUid(appId, appCertificate, channelName, uid, role, timestamp);
        return token;
    }
}
