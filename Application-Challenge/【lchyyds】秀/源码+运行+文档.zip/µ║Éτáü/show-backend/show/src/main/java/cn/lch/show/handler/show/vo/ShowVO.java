package cn.lch.show.handler.show.vo;

import cn.lch.show.handler.user.vo.UserVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@ApiModel
public class ShowVO {
    @ApiModelProperty("演出id")
    String showId;

    @ApiModelProperty("演出title")
    String title;

    @ApiModelProperty("演出简介")
    String description;

    @ApiModelProperty("海报")
    String poster;

    @ApiModelProperty("预告片")
    String preview;

    @ApiModelProperty("回放地址")
    List<String> replayList;

    @ApiModelProperty("演出开始时间")
    LocalDateTime showTimeStart;

    @ApiModelProperty("演出结束时间")
    LocalDateTime showTimeEnd;

    @ApiModelProperty("售票开始时间")
    LocalDateTime ticketTimeStart;

    @ApiModelProperty("售票结束时间")
    LocalDateTime ticketTimeEnd;

    @ApiModelProperty("票单价")
    double ticketPrice;

    @ApiModelProperty("创建商户的userInfo")
    UserVO showCreator;
}
