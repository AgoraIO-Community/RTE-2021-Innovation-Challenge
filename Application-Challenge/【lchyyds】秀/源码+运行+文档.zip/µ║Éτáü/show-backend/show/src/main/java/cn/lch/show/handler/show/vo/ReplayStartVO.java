package cn.lch.show.handler.show.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@ApiModel
public class ReplayStartVO {
    @ApiModelProperty("调用stop录制方法时需要传入")
    String resourceId;
    @ApiModelProperty("调用stop录制方法时需要传入")
    String sid;
    @ApiModelProperty("调用stop录制方法时需要传入")
    String mode;
}
