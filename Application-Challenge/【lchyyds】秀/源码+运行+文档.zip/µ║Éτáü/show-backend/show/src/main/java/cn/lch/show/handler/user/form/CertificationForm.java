package cn.lch.show.handler.user.form;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@ApiModel
public class CertificationForm {
    @ApiModelProperty("电话号码")
    String phone;

    @ApiModelProperty("身份证号")
    String idNumber;
}
