package cn.lch.show.service.show;

import cn.lch.show.handler.show.channelmanage.Channel;
import cn.lch.show.handler.show.channelmanage.Project;
import cn.lch.show.handler.show.channelmanage.User;
import com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

@Service
public class ChannelManageService {
    /**
     * 获取整个项目的状态
     */
    public Project getProjectInfo(String appId) {
        HttpClient client = HttpClient.newHttpClient();
        String url = String.format("https://api.agora.io/dev/v1/channel/%s", appId);
        HttpRequest request = AgoraRestful.getRequest(url);
        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            JSONObject jsonObject = JSONObject.parseObject(response.body());
            jsonObject = jsonObject.getJSONObject("data");
            return JSONObject.parseObject(jsonObject.toJSONString(), Project.class);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取某个channel的状态
     */
    public Channel getChannelInfo(String appId, String channelName) {
        HttpClient client = HttpClient.newHttpClient();
        String url = String.format("https://api.agora.io/dev/v1/channel/user/%s/%s", appId, channelName);
        HttpRequest request = AgoraRestful.getRequest(url);

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            JSONObject jsonObject = JSONObject.parseObject(response.body());
            jsonObject = jsonObject.getJSONObject("data");
            return JSONObject.parseObject(jsonObject.toJSONString(), Channel.class);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取频道中某个user的状态
     */
    public User getUserInfo(String appId, int uid, String channelName) {
        HttpClient client = HttpClient.newHttpClient();
        String url = String.format("https://api.agora.io/dev/v1/channel/user/property/%s/%s/%s", appId, uid, channelName);
        HttpRequest request = AgoraRestful.getRequest(url);

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            JSONObject jsonObject = JSONObject.parseObject(response.body());
            jsonObject = jsonObject.getJSONObject("data");
            return JSONObject.parseObject(jsonObject.toJSONString(), User.class);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

}
