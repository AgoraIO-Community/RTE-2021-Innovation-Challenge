package cn.lch.show.service.schedulingtasks;

import cn.lch.show.handler.show.channelmanage.Project;
import cn.lch.show.model.buffer.Buffer;
import cn.lch.show.model.buffer.BufferRepository;
import cn.lch.show.service.show.ChannelManageService;
import cn.lch.show.service.show.ReplayService;
import cn.lch.show.service.show.TokenBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

@Component
@Slf4j
public class ReplayTask {
    private static final int timeGap = 10 * (60 * 1000); //10分钟的间隔

    @Autowired
    BufferRepository bufferRepository;
    @Autowired
    ChannelManageService channelManageService;
    @Autowired
    ReplayService replayService;

    /**
     * TODO: 由于oss流量费用略贵, 因此先关闭回放功能
     */
    /**
     * 对于开始录制的channel，如果由于前端的问题没有调用stop，则会出现空录制这样的情况
     * 解决策略：
     *  1.每隔一段时间，查看buffer表中所有数据,buffer中记录着 start但还没有stop的所有录制
     *  2.调用声网接口查看进行中的channel
     *  3.如果buffer中的某个channel，没有出现在声网返回的channel中，则调用结束录制接口
     */
//    @Scheduled(fixedRate = ReplayTask.timeGap) //毫秒数
//    public void dealUnstopShow() {
//        /**
//         * 查询声网接口
//         */
//        Project project = channelManageService.getProjectInfo(TokenBuilder.appId);
//        Set<String> onlineChannelName = new HashSet<>();
//        project.getChannels().forEach(channel -> {
//            onlineChannelName.add(channel.getChannel_name());
//        });
//        /**
//         * 查询buffer
//         */
//        Iterable<Buffer> all = bufferRepository.findAll();
//        Set<String> bufferChannelName = new HashSet<>();
//        all.forEach(buffer -> {
//            bufferChannelName.add(buffer.decodeIdentify());
//        });
//        /**
//         * 比对
//         */
//        bufferChannelName.removeAll(onlineChannelName);
//        //剩下的就是没有调用stop的异常channel, 需要stop
//        bufferChannelName.forEach(channelName -> {
//            log.warn(String.format("channel<%s>在buffer存在, 但线上不存在, 推测未正常调用录制stop接口, 现自动stop", channelName));
//            replayService.stop(channelName);
//        });
//    }
}
