package cn.lch.show.handler.user.form;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@ApiModel
public class UpdateForm {
    @ApiModelProperty("昵称")
    String nickname;

    @ApiModelProperty("头像地址")
    String avatar;
}
