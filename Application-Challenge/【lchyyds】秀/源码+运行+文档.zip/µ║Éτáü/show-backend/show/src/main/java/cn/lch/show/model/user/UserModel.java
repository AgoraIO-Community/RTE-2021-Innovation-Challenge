package cn.lch.show.model.user;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class UserModel {
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    String id;
    /**
     * 电话号码
     */
    String phone;
    /**
     * 昵称
     */
    String nickname;
    /**
     * 头像url
     */
    @Column(length = 1024)
    String avatar;
    /**
     * 角色类别
     */
    UserRole role;
    /**
     * id字段的hash
     */
    int uid;
}
