package cn.lch.show.handler.show.vo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@ApiModel
public class ChannelMetaVO {
    @ApiModelProperty("进入者自己的uid")
    int uid;

    @ApiModelProperty("进入的show的主播的uid")
    int publisherUid;

    @ApiModelProperty("channel name, 值为show id")
    String channelName;

    @ApiModelProperty("连接的token")
    String token;

    @ApiModelProperty("appId")
    String appId;

    @ApiModelProperty("传入角色的role")
    /**
     * @see cn.lch.show.service.show.rtc.media.RtcTokenBuilder.Role
     */
    int role;
}
