package cn.lch.show.handler.show;

import cn.lch.show.handler.ResVO;
import cn.lch.show.service.show.ReplayService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * TODO: 由于oss流量费用略贵, 因此先关闭回放功能
 */

//@RestController
//@RequestMapping("/show/replay")
//public class ReplayHandler {
//    @Autowired
//    ReplayService replayService;
//
//    @PostMapping("/start/{channelName}")
//    @ApiOperation("开始录制，主播开播时调用此接口")
//    public ResVO<String> start(@PathVariable("channelName") String channelName) {
//        return replayService.start(channelName);
//    }
//
//    @PostMapping("/stop/{channelName}")
//    @ApiOperation("结束录制，主播下播时调用此接口")
//    public ResVO<List<String>> stop(@PathVariable("channelName") String channelName) {
//        return replayService.stop(channelName);
//    }
//
//    @GetMapping("/query/{channelName}")
//    public String query(@PathVariable("channelName") String channelName) {
//        return replayService.query(channelName);
//    }
//}
