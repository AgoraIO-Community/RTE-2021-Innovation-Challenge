package cn.lch.show.handler.errorcode;

import cn.lch.show.handler.ResVO;
import cn.lch.show.handler.errorcode.vo.ErrorCodeVO;
import cn.lch.show.service.errorcode.ErrorCodeService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/errorcode")
public class ErrorCodeHandler {
    @Autowired
    ErrorCodeService errorCodeService;

    @GetMapping("/rn")
    @ApiOperation("声网极速直播, react native错误码及说明")
    public ResVO<List<ErrorCodeVO>> getRnErrorCode() {
        return ResVO.<List<ErrorCodeVO>>builder().success(true).data(errorCodeService.getRnErrorCode()).build();
    }
}
