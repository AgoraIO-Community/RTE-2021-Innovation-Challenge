package cn.lch.show.model.user;


public enum UserRole {
    /**
     * 观众
     */
    Audience,
    /**
     * 商家
     */
    Merchant
}