package cn.lch.show.util;

public class UuidUtil {
    public static int uuidToInt(String uuid) {
        return Math.abs(uuid.hashCode());
    }
}
