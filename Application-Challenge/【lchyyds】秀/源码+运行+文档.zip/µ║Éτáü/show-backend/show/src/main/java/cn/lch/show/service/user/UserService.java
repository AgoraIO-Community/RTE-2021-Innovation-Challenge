package cn.lch.show.service.user;

import cn.lch.show.handler.user.vo.UserVO;
import cn.lch.show.model.user.UserModel;
import cn.lch.show.model.user.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    UserRepository userRepository;

    public UserVO findUserVOByUserId(String userId) {
        return copyFromModel(userRepository.findById(userId).orElse(null));
    }

    public UserVO findUserVOByPhone(String phone) {
        return copyFromModel(userRepository.findByPhone(phone));
    }

    public Map<String, UserVO> findUserVOByUserId(List<String> userId) {
        Iterable<UserModel> allById = userRepository.findAllById(userId);
        Map<String, UserVO> resMap = new HashMap<>();

        for (UserModel model : allById) {
            resMap.put(model.getId(), copyFromModel(model));
        }
        return resMap;
    }

    public UserVO copyFromModel(UserModel model) {
        if (model != null) {
            UserVO userVO = UserVO.builder()
                    .nickname(model.getNickname())
                    .phone(model.getPhone())
                    .userId(model.getId())
                    .avatar(model.getAvatar())
                    .role(model.getRole().ordinal())
                    .build();
            return userVO;
        }
        return null;
    }
}
