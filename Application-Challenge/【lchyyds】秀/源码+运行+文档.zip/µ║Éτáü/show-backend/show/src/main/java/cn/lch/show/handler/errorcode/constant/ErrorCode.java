package cn.lch.show.handler.errorcode.constant;

public enum ErrorCode {
    RequestNoToken(1, "请求未设值token"),
    RequestNoUserId(2, "请求未设值userId"),
    TokenInvalid(3, "token无效");

    public int value;
    public String description;

    ErrorCode(int value, String description) {
        this.value = value;
        this.description = description;
    }
}
