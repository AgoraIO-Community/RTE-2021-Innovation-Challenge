package cn.lch.show.handler.show.form;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@ApiModel
public class ShowForm {
    @ApiModelProperty("演出title")
    String title;

    @ApiModelProperty("演出简介")
    String description;

    @ApiModelProperty("海报")
    String poster;

    @ApiModelProperty("预告片")
    String preview;

    @ApiModelProperty("演出开始时间")
    LocalDateTime showTimeStart;

    @ApiModelProperty("演出结束时间")
    LocalDateTime showTimeEnd;

    @ApiModelProperty("售票开始时间")
    LocalDateTime ticketTimeStart;

    @ApiModelProperty("售票结束时间")
    LocalDateTime ticketTimeEnd;

    @ApiModelProperty("票单价")
    double ticketPrice;

    @ApiModelProperty("创建商户userId")
    String userId;
}
