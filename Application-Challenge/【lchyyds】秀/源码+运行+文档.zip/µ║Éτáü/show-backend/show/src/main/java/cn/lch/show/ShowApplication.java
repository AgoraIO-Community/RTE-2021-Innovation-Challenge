package cn.lch.show;

import cn.lch.show.util.ColorPrint;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class ShowApplication {
	public static void main(String[] args) {
		SpringApplication.run(ShowApplication.class, args);
	}

	@Bean
	public CommandLineRunner commandLineRunner() {
		return args -> {
			String logo = "\n" +
					" __        ______  __    __            _______. __    __    ______   ____    __    ____ \n" +
					"|  |      /      ||  |  |  |          /       ||  |  |  |  /  __  \\  \\   \\  /  \\  /   / \n" +
					"|  |     |  ,----'|  |__|  |  ______ |   (----`|  |__|  | |  |  |  |  \\   \\/    \\/   /  \n" +
					"|  |     |  |     |   __   | |______| \\   \\    |   __   | |  |  |  |   \\            /   \n" +
					"|  `----.|  `----.|  |  |  |      .----)   |   |  |  |  | |  `--'  |    \\    /\\    /    \n" +
					"|_______| \\______||__|  |__|      |_______/    |__|  |__|  \\______/      \\__/  \\__/     ";
			System.out.println(logo);
			ColorPrint.defaultColorPrint(":: Show App ::\t\t(v1.0)");
		};
	}
}