package cn.lch.show.model.show;

import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class ShowModel {
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    String id;
    /**
     * 演出title
     */
    String title;
    /**
     * 演出简介
     */
    String description;
    /**
     * 海报
     */
    @Column(length = 1024)
    String poster;
    /**
     * 预告片
     */
    @Column(length = 1024)
    String preview;
    /**
     * 回放:
     *  注意: 存储为 List<String>
     */
    @Column(length = 4096)
    String replay;
    /**
     * 演出开始时间
     */
    LocalDateTime showTimeStart;
    /**
     * 演出结束时间
     */
    LocalDateTime showTimeEnd;
    /**
     * 售票开始时间
     */
    LocalDateTime ticketTimeStart;
    /**
     * 售票结束时间
     */
    LocalDateTime ticketTimeEnd;
    /**
     * 票单价
     */
    double ticketPrice;
    /**
     * 创建商户userId
     */
    String userId;


    public List<String> getReplayUrlList() {
        return JSONObject.parseArray(replay, String.class);
    }

    public void setReplayUrlList(List<String> urlList) {
        this.replay = JSONObject.toJSONString(urlList);
    }
}
