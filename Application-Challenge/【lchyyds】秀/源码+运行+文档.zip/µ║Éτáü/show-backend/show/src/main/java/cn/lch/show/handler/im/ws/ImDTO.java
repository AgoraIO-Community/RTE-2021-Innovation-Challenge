package cn.lch.show.handler.im.ws;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ImDTO {
    /**
     * 消息类型, 为枚举顺序值
     * @see ImMsgType
     */
    int type;
    /**
     * token
     */
    String token;
    /**
     * 客户端请求的业务数据, json形式
     */
    String data;
    /**
     * 返回或推送的业务数据
     */
    Object voData;
}
