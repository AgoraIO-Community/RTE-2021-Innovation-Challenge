package cn.lch.show.service.im.impl;

import cn.lch.show.handler.im.ws.ImDTO;
import cn.lch.show.handler.im.ws.ImMsgType;
import cn.lch.show.service.im.ImService;
import cn.lch.show.service.im.ImServiceTag;
import cn.lch.show.service.im.showchat.ShowRoom;
import com.alibaba.fastjson.JSONObject;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ImServiceTag(type = ImMsgType.JoinShow)
public class JoinShow implements ImService {
    @Override
    public void action(ImDTO data, String userId) {
        JoinShowForm joinShowForm = JSONObject.parseObject(data.getData(), JoinShowForm.class);
        //将用户加入ShowRoom
        ShowRoom.joinShow(userId, joinShowForm.getShowId());
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class JoinShowForm {
        String showId;
    }
}
