package cn.lch.show.handler.im.ws;
import cn.lch.show.handler.ResVO;
import cn.lch.show.handler.errorcode.constant.ErrorCode;
import cn.lch.show.handler.im.ImHandler;
import cn.lch.show.service.im.UserWsPool;
import cn.lch.show.service.im.showchat.ShowRoom;
import cn.lch.show.service.security.TokenService;
import com.alibaba.fastjson.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.server.standard.SpringConfigurator;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;

@Component
@ServerEndpoint(value = "/im/{userId}")
public class ImWsServer {
    //建立连接成功调用
    @OnOpen
    public void onOpen(Session session, @PathParam(value = "userId") String userId){
        UserWsPool.connect(userId, session);
    }

    //关闭连接时调用
    @OnClose
    public void onClose(@PathParam(value = "userId") String userId){
        UserWsPool.loseConnect(userId);
        ShowRoom.loseConnect(userId);
    }

    //收到客户端信息
    @OnMessage
    public void onMessage(Session session, String message, @PathParam(value = "userId") String userId) throws IOException {
        ImDTO imDTO = JSONObject.parseObject(message, ImDTO.class);
        /**
         * 检测token
         */
        String token = imDTO.getToken();
        if (token == null) {
            ResVO<Object> resVO = ResVO.builder().success(false).code(ErrorCode.RequestNoToken.value).msg(ErrorCode.RequestNoToken.description).build();
            ImDTO response = ImDTO.builder()
                    .type(-1)
                    .voData(resVO)
                    .build();
            session.getBasicRemote().sendText(JSONObject.toJSONString(response));
        } else if (!TokenService.isTokenEffective(token, userId)) {
            ResVO<Object> resVO = ResVO.builder().success(false).code(ErrorCode.TokenInvalid.value).msg(ErrorCode.TokenInvalid.description).build();
            ImDTO response = ImDTO.builder()
                    .type(-1)
                    .voData(resVO)
                    .build();
            session.getBasicRemote().sendText(JSONObject.toJSONString(response));
        } else {
            //正常业务处理
            ImHandler.action(imDTO, userId);
        }
    }

    //错误时调用
    @OnError
    public void onError(Session session, @PathParam(value = "userId") String userId, Throwable throwable){
        UserWsPool.loseConnect(userId);
        ShowRoom.loseConnect(userId);
    }
}
