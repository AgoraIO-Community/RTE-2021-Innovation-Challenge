package cn.lch.show.service.show;

import cn.lch.show.handler.ResVO;
import cn.lch.show.handler.show.channelmanage.Channel;
import cn.lch.show.handler.show.vo.ReplayStartVO;
import cn.lch.show.model.buffer.Buffer;
import cn.lch.show.model.buffer.BufferRepository;
import cn.lch.show.model.show.ShowModel;
import cn.lch.show.model.show.ShowRepository;
import cn.lch.show.service.show.rtc.media.RtcTokenBuilder;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class ReplayService {
    @Autowired
    ShowRepository showRepository;
    @Autowired
    BufferRepository bufferRepository;
    /**
     * 字符串内容为云端录制服务在频道内使用的 UID，用于标识该录制服务，例如"527841"。需满足以下条件：
     * 取值范围 1 到 (232-1)，不可设置为 0。
     * 不能与当前频道内的任何 UID 重复。
     * 云端录制不支持 String 用户 ID（User Account），请确保该字段引号内为整型 UID，且频道内所有用户均使用整型 UID。
     */
    private static String replayServiceUid = "11";

    /**
     * oss链接地址前缀
     */
    private static String ossLinkPrefix = "https://show-app.oss-cn-hangzhou.aliyuncs.com/";

    public ResVO<String> start(String channelName) {
        /**
         * 在开始云端录制之前，你需要调用该方法获取一个 resource ID
         */
        HttpClient client = HttpClient.newHttpClient();
        String url = String.format("https://api.agora.io/v1/apps/%s/cloud_recording/acquire", TokenBuilder.appId);
        JSONObject body = new JSONObject();
            body.put("cname", channelName);
            body.put("uid", replayServiceUid);
            JSONObject clientRequest = new JSONObject();
            body.put("clientRequest", clientRequest);

        HttpRequest request = AgoraRestful.postRequest(url, body);

        String resourceId = null;
        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 200) {
                resourceId = JSONObject.parseObject(response.body()).getString("resourceId");
            } else {
                return ResVO.<String>builder().success(false).msg(response.body() + "    " + response.statusCode()).build();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        /**
         * 开始云端录制，获取 resource ID 后，调用该方法开始云端录制
         */
        String dir = String.format("[%s, %s, %s]", "\"replay\"", "\"" + channelName + "\"", "\"" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + "\"");
        String mode = "mix";
        url = String.format("https://api.agora.io/v1/apps/%s/cloud_recording/resourceid/%s/mode/%s/start", TokenBuilder.appId, resourceId, mode);
        body.clear();
            body.put("cname", channelName);
            body.put("uid", replayServiceUid);
                clientRequest.clear();
                clientRequest.put("token", TokenBuilder.generateToken(Integer.parseInt(replayServiceUid), channelName, RtcTokenBuilder.Role.Role_Subscriber));
//                clientRequest.put("appsCollection", JSONObject.parseObject(
//                        "{\"combinationPolicy\": \"postpone_transcoding\"}"
//                ));
                clientRequest.put("recordingConfig", JSONObject.parseObject(
                   "{\"channelType\": 1}"
                ));
                clientRequest.put("storageConfig", JSONObject.parseObject(
                   "{\"vendor\": 2, \"region\": 0, \"bucket\":\"show-app\", \"accessKey\": \"LTAI5t7jzYozbyKP1X1nb5AK\", \"secretKey\": \"2UAtDvv3pyDZXiFzkF0bNv2iOG6iUW\", \"fileNamePrefix\": " + dir + "}"
                ));
            body.put("clientRequest", clientRequest);

        request = AgoraRestful.postRequest(url, body);
        String sid = null;
        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 200) {
                sid = JSONObject.parseObject(response.body()).getString("sid");
            } else {
                return ResVO.<String>builder().success(false).msg(response.body() + "    " + response.statusCode()).build();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        ReplayStartVO vo = ReplayStartVO.builder()
                .resourceId(resourceId)
                .sid(sid)
                .mode(mode)
                .build();


        //将vo存入buffer, 不需要返回前端
        String key = Buffer.generateKey("replay", channelName);
        Buffer buffer = bufferRepository.findByK(key);
        if (buffer == null) {
            buffer = Buffer.builder().k(key).v(JSONObject.toJSONString(vo)).build();
        } else {
            buffer.setV(JSONObject.toJSONString(vo));
        }
        bufferRepository.save(buffer);

        return ResVO.<String>builder().success(true).msg("开始录制").build();
    }

    public ResVO<List<String>> stop(String channelName) {
        /**
         * 先在buffer中查询replayStartVO
         */
        Buffer replay = bufferRepository.findByK(Buffer.generateKey("replay", channelName));
        ReplayStartVO replayStartVO = JSONObject.parseObject(replay.getV(), ReplayStartVO.class);
        /**
         * 录制完成后，调用该方法离开频道，停止录制
         */
        HttpClient client = HttpClient.newHttpClient();
        String url = String.format("https://api.agora.io/v1/apps/%s/cloud_recording/resourceid/%s/sid/%s/mode/%s/stop"
                , TokenBuilder.appId, replayStartVO.getResourceId(), replayStartVO.getSid(), replayStartVO.getMode());
        JSONObject body = new JSONObject();
        body.put("cname", channelName);
        body.put("uid", replayServiceUid);
        body.put("clientRequest", new JSONObject());
        HttpRequest request = AgoraRestful.postRequest(url, body);
        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 200) {
                /**
                 * 解析出url地址, 存储show 的replay地址并返回这个url
                 */
                JSONObject res = JSONObject.parseObject(response.body());
                res = res.getJSONObject("serverResponse");
                String fileName = res.getString("fileList");
                String replayUrl = ossLinkPrefix + fileName;
                //存储 url
                ShowModel model = showRepository.findById(channelName).get();
                List<String> urlList = model.getReplayUrlList();
                if (urlList == null) urlList = new ArrayList<>();
                urlList.add(replayUrl);
                model.setReplayUrlList(urlList);
//                model.setReplay(replayUrl);
                showRepository.save(model);
                /**
                 * 删除buffer
                 */
                bufferRepository.delete(replay);

                return ResVO.<List<String>>builder().success(true).data(urlList).build();
            } else {
                return ResVO.<List<String>>builder().success(false).msg(response.body() + "    " + response.statusCode()).build();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String query(String channelName) {
        /**
         * 先在buffer中查询replayStartVO
         */
        Buffer replay = bufferRepository.findByK(Buffer.generateKey("replay", channelName));
        if (replay == null) {
            return String.format("channel<%s>已停止录制", channelName);
        }
        ReplayStartVO replayStartVO = JSONObject.parseObject(replay.getV(), ReplayStartVO.class);

        String url = String.format("https://api.agora.io/v1/apps/%s/cloud_recording/resourceid/%s/sid/%s/mode/%s/query"
        , TokenBuilder.appId, replayStartVO.getResourceId(), replayStartVO.getSid(), replayStartVO.getMode());

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = AgoraRestful.getRequest(url);

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            return response.body();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }
}
