package cn.lch.show.service.security;

import cn.lch.show.handler.ResVO;
import cn.lch.show.handler.errorcode.constant.ErrorCode;
import com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class TokenInterceptor implements HandlerInterceptor {
    /**
     * token检测
     * @param request
     * @param response
     * @param handler
     * @return
     * @throws Exception
     */
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String token = request.getHeader("token");
        String userId = request.getHeader("userId");
        if (token == null) {
            ResVO<Object> resVO = ResVO.builder().success(false).code(ErrorCode.RequestNoToken.value).msg(ErrorCode.RequestNoToken.description).build();
            response.setHeader("Content-type", "application/json;charset=UTF-8");
            response.getWriter().print(JSONObject.toJSONString(resVO));
            return false;
        }
        if (userId == null) {
            ResVO<Object> resVO = ResVO.builder().success(false).code(ErrorCode.RequestNoUserId.value).msg(ErrorCode.RequestNoUserId.description).build();
            response.setHeader("Content-type", "application/json;charset=UTF-8");
            response.getWriter().print(JSONObject.toJSONString(resVO));
            return false;
        }
        if (!TokenService.isTokenEffective(token, userId)) {
            ResVO<Object> resVO = ResVO.builder().success(false).code(ErrorCode.TokenInvalid.value).msg(ErrorCode.TokenInvalid.description).build();
            response.setHeader("Content-type", "application/json;charset=UTF-8");
            response.getWriter().print(JSONObject.toJSONString(resVO));
            return false;
        }
        return true;
    }
}
