package cn.lch.show.config;

import org.hibernate.dialect.MySQL55Dialect;
import org.springframework.stereotype.Component;

@Component
public class MysqlConf extends MySQL55Dialect {
    /**
     * 设置表编码为utf-8
     * @return
     */
    @Override
    public String getTableTypeString() {
        return "ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    }
}
