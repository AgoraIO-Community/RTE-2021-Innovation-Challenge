package cn.lch.show.model.order;

import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface OrderRepository extends CrudRepository<OrderModel, String> {
    OrderModel findByShowIdAndUserId(String showId, String userId);

    List<OrderModel> findByUserId(String userId);
}
