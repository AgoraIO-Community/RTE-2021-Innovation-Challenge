package cn.lch.show.service.file;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class FileService {

    final Path fileLocation;

    @Autowired
    public FileService(@Value("${file.upload-dir}") String uploadDir) {
        this.fileLocation = Paths.get(uploadDir).toAbsolutePath().normalize();
        try {
            Files.createDirectories(this.fileLocation);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


    /**
     * 存储文件到系统
     *
     * @param file 文件
     * @return 文件名
     */
    public String storeFile(MultipartFile file, String userId) {
        // Normalize file name
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        fileName = String.format("%s_%s_%s", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm:ss")), userId, fileName);
        try {
            // Check if the file's name contains invalid characters
            if(fileName.contains("..")) {
                log.error("Sorry! Filename contains invalid path sequence " + fileName);
                return null;
            }
            // Copy file to the target location (Replacing existing file with the same name)
            Path targetLocation = this.fileLocation.resolve(fileName);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

            return fileName;
        } catch (IOException ex) {
            log.error("Could not store file " + fileName + ". Please try again!");
            ex.printStackTrace();
        }
        return null;
    }

    /**
     * 加载文件
     * @param fileName 文件名
     * @return 文件
     */
    public Resource loadFileAsResource(String fileName) {
        try {
            Path filePath = this.fileLocation.resolve(fileName).normalize();
            Resource resource = new UrlResource(filePath.toUri());
            if(resource.exists()) {
                return resource;
            } else {
                log.error("File not found " + fileName);
            }
        } catch (MalformedURLException ex) {
            log.error("File not found " + fileName);
            ex.printStackTrace();
        }
        return null;
    }

    public List<String> all() {
        File rootDir = fileLocation.toAbsolutePath().toFile();
        List<String> res = new ArrayList<>();
        String prefix = null;
        try {
            prefix = String.format("http://%s:50000/downloadFile/", InetAddress.getLocalHost().getHostAddress());
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        for (File file : rootDir.listFiles()) {
            if (file.isFile()) {
                res.add(prefix + file.getName());
            }
        }
        return res;
    }
}
