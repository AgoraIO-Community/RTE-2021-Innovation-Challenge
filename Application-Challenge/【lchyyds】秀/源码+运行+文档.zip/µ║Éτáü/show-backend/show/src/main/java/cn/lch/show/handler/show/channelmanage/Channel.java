package cn.lch.show.handler.show.channelmanage;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Channel {
    //指定查询的频道是否存在
    boolean channel_exist;
    /**
     * 频道场景：
     * 1：通信场景
     * 2: 直播场景
     */
    int mode;

    //频道内的用户总人数。在通信场景 （mode 的值为 1）下，才会返回此字段
    int total;

    //频道内所有用户的 ID 列表。在通信场景 （mode 的值为 1）下，才会返回此字段
    List<Integer> users;

    //频道内所有主播的用户 ID 列表。在直播场景 （mode 的值为 2）下，才会返回此字段
    List<Integer> broadcasters;

    //频道内观众的 uid 列表，最多包含前 10,000 名观众。在直播场景 （mode 的值为 2）下，才会返回此字段
    List<Integer> audience;

    //频道内的观众总人数。在直播场景 （mode 的值为 2）下，才会返回此字段。
    int audience_total;
}
