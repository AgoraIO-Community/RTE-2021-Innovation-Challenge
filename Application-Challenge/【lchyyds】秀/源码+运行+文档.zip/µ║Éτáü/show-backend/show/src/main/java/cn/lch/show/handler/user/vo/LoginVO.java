package cn.lch.show.handler.user.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@ApiModel
public class LoginVO {
    @ApiModelProperty("userId")
    String userId;
    @ApiModelProperty("token")
    String token;
}
