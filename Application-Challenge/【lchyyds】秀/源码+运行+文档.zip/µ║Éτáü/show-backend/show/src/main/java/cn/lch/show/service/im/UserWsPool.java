package cn.lch.show.service.im;

import javax.websocket.Session;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class UserWsPool {
    /**
     * 存放user的session
     *  key为userId
     */
    public static final Map<String, Session> userIdSessionMap = new ConcurrentHashMap<>();

    /**
     * 记录用户连接的时间
     */
    public static final Map<String, LocalDateTime> userIdConnectTimeMap = new ConcurrentHashMap<>();


    public static void connect(String userId, Session session) {
        userIdSessionMap.put(userId, session);
        userIdConnectTimeMap.put(userId, LocalDateTime.now());
    }

    public static void loseConnect(String userId) {
        userIdSessionMap.remove(userId);
        userIdConnectTimeMap.remove(userId);
    }
}
