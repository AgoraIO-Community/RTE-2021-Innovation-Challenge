package cn.lch.show.handler.order.form;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@ApiModel
public class PayForm {
    @ApiModelProperty("show id")
    String showId;

    @ApiModelProperty("user id")
    String userId;

    @ApiModelProperty("支付钱数")
    double amount;

//    @ApiModelProperty("支付时间")
//    LocalDateTime payTime;
}
