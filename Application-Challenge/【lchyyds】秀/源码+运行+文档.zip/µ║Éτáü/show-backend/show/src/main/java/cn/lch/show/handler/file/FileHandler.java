package cn.lch.show.handler.file;

import cn.lch.show.handler.ResVO;
import cn.lch.show.service.file.FileService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;

@RestController
@Slf4j
@Api("文件管理")
public class FileHandler {
    @Autowired
    FileService fileService;

    @ApiOperation("上传单个文件")
    @PostMapping("/uploadFile/{userId}")
    public ResVO<String> uploadFile(@RequestParam("file") MultipartFile file, @PathVariable("userId") String userId){
        String fileName = fileService.storeFile(file, userId);

        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/downloadFile/")
                .path(fileName)
                .toUriString();

        return ResVO.<String>builder().success(true).data(fileDownloadUri).build();
    }

//    @ApiOperation("上传多个文件")
//    @PostMapping("/uploadMultipleFiles")
//    public ResVO<List<String>> uploadMultipleFiles(@RequestParam("files") MultipartFile[] files) {
//         List<ResVO<String>> res = Arrays.stream(files)
//                .map(this::uploadFile)
//                .collect(Collectors.toList());
//         return ResVO.<List<String>>builder().success(true)
//                 .data(res.stream().map(e -> e.getData()).collect(Collectors.toList()))
//                 .build();
//    }

    @ApiOperation("下载文件")
    @GetMapping("/downloadFile/{fileName}")
    public ResponseEntity<Resource> downloadFile(@PathVariable String fileName, HttpServletRequest request) {
        // Load file as Resource
        Resource resource = fileService.loadFileAsResource(fileName);
        // Try to determine file's content type
        String contentType = null;
        try {
            contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
        } catch (IOException ex) {
            log.info("Could not determine file type.");
        }
        // Fallback to the default content type if type could not be determined
        if(contentType == null) {
            contentType = "application/octet-stream";
        }

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
//                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }

    @ApiOperation("测试用, 查看上传的所有文件")
    @GetMapping("/file/all")
    public String all() {
        String html = "<!DOCTYPE html>\n" +
                "<html>\n" +
                "<head>\n" +
                "<meta charset=\"utf-8\">\n" +
                "<title>查看全部上传文件</title>\n" +
                "</head>\n" +
                "<body>\n" +
                "<div>\n" +
                "%s\n" +
                "</div>"+
                "   <div>\n" +
                "%s" +
                "   </div>\n" +
                "</body>\n" +
                "</html>";
        String fileA = "";
        List<String> all = fileService.all();
        for (String s : all) {
            fileA += String.format("<a href=\"%s\" style=\"display: block; text-decoration: none;\">%s</a>\n", s, s);
        }
        return String.format(html,"共有文件" + all.size() + "个", fileA);
    }
}
