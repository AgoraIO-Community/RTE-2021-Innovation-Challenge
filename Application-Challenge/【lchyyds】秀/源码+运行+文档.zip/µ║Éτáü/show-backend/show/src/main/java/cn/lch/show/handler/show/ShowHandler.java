package cn.lch.show.handler.show;

import cn.lch.show.handler.ResVO;
import cn.lch.show.handler.show.form.ShowForm;
import cn.lch.show.handler.show.vo.ChannelInfo;
import cn.lch.show.handler.show.vo.ChannelMetaVO;
import cn.lch.show.handler.show.vo.SearchVO;
import cn.lch.show.handler.show.vo.ShowVO;
import cn.lch.show.handler.user.vo.UserVO;
import cn.lch.show.model.show.ShowModel;
import cn.lch.show.model.show.ShowRepository;
import cn.lch.show.model.user.UserRole;
import cn.lch.show.service.order.OrderService;
import cn.lch.show.service.show.ShowService;
import cn.lch.show.service.show.TokenBuilder;
import cn.lch.show.service.show.rtc.media.RtcTokenBuilder;
import cn.lch.show.service.user.UserService;
import cn.lch.show.util.UuidUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/show")
@Api("show")
@Slf4j
public class ShowHandler {
    @Autowired
    ShowRepository showRepository;
    @Autowired
    UserService userService;
    @Autowired
    ShowService showService;
    @Autowired
    OrderService orderService;

    @ApiOperation("创建show")
    @PostMapping("/create")
    public ResVO<ShowVO> createShow(@RequestBody ShowForm showForm) {
        UserVO userVO = userService.findUserVOByUserId(showForm.getUserId());
        if (userVO == null) {
            return ResVO.<ShowVO>builder().success(false).msg(String.format("userId<%s>不存在", showForm.getUserId())).build();
        }
        if (userVO.getRole() != UserRole.Merchant.ordinal()) {
            return ResVO.<ShowVO>builder().success(false).msg(String.format("userId<%s>不为商家", showForm.getUserId())).build();
        }
        ShowModel model = ShowModel.builder().build();
        BeanUtils.copyProperties(showForm, model);
        showRepository.save(model);

        ShowVO showVO = ShowVO.builder().showId(model.getId()).showCreator(userVO).build();
        BeanUtils.copyProperties(model, showVO);

        return ResVO.<ShowVO>builder().success(true).data(showVO).build();
    }

    @ApiOperation("获取某一个showVO")
    @GetMapping("/info/{showId}")
    public ResVO<ShowVO> getShowInfo(@PathVariable("showId") String showId) {
        ShowModel model = showRepository.findById(showId).orElse(null);
        if (model == null) {
            return ResVO.<ShowVO>builder().success(false).msg(String.format("show id<%s>不存在", showId)).build();
        }
        ShowVO showVO = showService.copyFromModel(model, userService.findUserVOByUserId(model.getUserId()));
        return ResVO.<ShowVO>builder().success(true).data(showVO).build();
    }

    @ApiOperation("获取所有showVO")
    @GetMapping("/all")
    public ResVO<List<ShowVO>> getAllShow() {
        return ResVO.<List<ShowVO>>builder().success(true).data(showService.getAllShow()).build();
    }

//    @ApiOperation("获取channel meta")
//    @GetMapping("/channel/meta/{userId}/{showId}")
    public ResVO<ChannelMetaVO> getChannelMeta(@PathVariable("userId") String userId, @PathVariable("showId") String showId) {
        /**
         * user处理
         */
        UserVO userVO = userService.findUserVOByUserId(userId);
        if (userVO == null) {
            return ResVO.<ChannelMetaVO>builder().success(false).msg("user不存在").build();
        }
        int uid = UuidUtil.uuidToInt(userVO.getUserId());
        /**
         * show处理
         */
        ShowModel show = showRepository.findById(showId).orElse(null);
        if (show == null) {
            return ResVO.<ChannelMetaVO>builder().success(false).msg("show不存在").build();
        }
        String channelName = show.getId();
        //role判断, user在show中是 观众还是主播
          //只有user为show的创建者，才是主播
        RtcTokenBuilder.Role role;
        if (show.getUserId().equals(userVO.getUserId())) {
            role = RtcTokenBuilder.Role.Role_Publisher;
        }
        else {
            role = RtcTokenBuilder.Role.Role_Subscriber;
        }
        //生成token
        String token = TokenBuilder.generateToken(uid, channelName, role);

        ChannelMetaVO channelMetaVO = ChannelMetaVO.builder()
                .uid(uid)
                .channelName(channelName)
                .token(token)
                .appId(TokenBuilder.appId)
                .role(role.initValue)
                .publisherUid(UuidUtil.uuidToInt(show.getUserId())) //主播的uid
                .build();
        return ResVO.<ChannelMetaVO>builder().success(true).data(channelMetaVO).build();
    }

    @ApiOperation("获取channel的info")
    @GetMapping("/channel/info/{showId}/{userId}")
    public ResVO<ChannelInfo> getChannelInfo(@PathVariable("showId") String showId, @PathVariable("userId") String userId) {
        /**
         * show处理
         */
        ShowModel show = showRepository.findById(showId).orElse(null);
        if (show == null) {
            return ResVO.<ChannelInfo>builder().success(false).msg("show不存在").build();
        }
        /**
         * 获取meta
         */
        ChannelMetaVO channelMetaVO = getChannelMeta(userId, showId).getData();

        ChannelInfo info = ChannelInfo.builder()
                .showId(show.getId())
                .showState(showService.judgeShowState(show).ordinal())
                .channelMetaVO(channelMetaVO)
                .purchased(orderService.isPaid(userId, showId))
                .build();
        return ResVO.<ChannelInfo>builder().success(true).data(info).build();
    }

    @ApiOperation("通过关键字搜索; pageNumber从0开始")
    @GetMapping("/search")
    public ResVO<SearchVO> searchShow(@RequestParam(value = "keyword", defaultValue = "") String keyword,
                                      @RequestParam(value = "pageNumber", defaultValue = "0") int pageNumber,
                                      @RequestParam(value = "pageSize", defaultValue = "20") int pageSize) {
        List<ShowVO> allShowVO = showService.searchShow(keyword);
        int fromIndex = pageNumber * pageSize;
        if (fromIndex < 0 || fromIndex >= allShowVO.size()) {
            return ResVO.<SearchVO>builder().success(true).data(null)
                    .msg(String.format("keyword=%s, pageNumber=%s, pageSize=%s 查询没有show数据", keyword, pageNumber, pageSize))
                    .build();
        }

        int toIndex = fromIndex + pageSize;
        boolean hasNext = true;

        if (toIndex >= allShowVO.size()) {
            hasNext = false;
            toIndex = allShowVO.size();
        }
        List<ShowVO> res = allShowVO.subList(fromIndex, toIndex);

        return ResVO.<SearchVO>builder()
                .success(true)
                .data(SearchVO.builder().hasNext(hasNext).showVOList(res).build())
                .build();
    }

    @ApiOperation("查看user已经购买的show VO")
    @GetMapping("/paid/{userId}")
    public ResVO<List<ShowVO>> getPaidShow(@PathVariable("userId") String userId) {
        return ResVO.<List<ShowVO>>builder()
                .success(true)
                .data(showService.getPaidShow(userId))
                .build();
    }
}
