import Multiple from '../views/multiple/index.vue'

export default [{
  path: '/multiple',
  name: 'multiple',
  component: Multiple
}]
