export default {
    appid: '0d458a978abd454ebcaaa895121a0f12', // 请输入自己的appkey
}
