export default {
    appid: 'a6f187aee9e5446b8d56f18f229db2c7', // 请输入自己的appkey
}
