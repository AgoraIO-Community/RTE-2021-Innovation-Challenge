import Game from '../views/game/index.vue'

export default [{
  path: '/game',
  name: 'game',
  component: Game
}]
